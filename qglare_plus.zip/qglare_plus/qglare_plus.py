"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris '
__date__ = '2025-05-29'
__copyright__ = '(C) 2025 Brian S. Burnham'
__email__ = 'brian.burnham@abdn.ac.uk'

__revision__ = '$Format:%H$'

import os
import sys
import inspect
from qgis.core import QgsApplication
from .qglare_provider import QglarePlusProvider

cmd_folder = os.path.split(inspect.getfile(inspect.currentframe()))[0]

if cmd_folder not in sys.path:
    sys.path.insert(0, cmd_folder)

class QglarePlusPlugin(object):

    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initProcessing(self):
        """Init Processing provider for QGIS >= 3.8."""
        self.provider = QglarePlusProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

    def unload(self):
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

def classFactory(iface):
    return QglarePlusPlugin(iface)
      