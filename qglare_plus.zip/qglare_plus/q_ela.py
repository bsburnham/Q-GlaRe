"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : Q-ELA
Group : Q-ELA
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, traceback
from .qglare_base import QGlaReAlgorithmMixin
import numpy as np
import pandas as pd
from osgeo import gdal
import processing
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication, QUrl
from qgis.core import (Qgis,
                       QgsProcessing,
                       QgsMessageLog,
                       QgsRasterLayer,
                       QgsProcessingException,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterEnum,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorDestination,
                       QgsProcessingUtils)

# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_RASTER = Qgis.ProcessingSourceType.Raster
except AttributeError:                          # QGIS < 3.36
    _SOURCE_RASTER = QgsProcessing.TypeRaster

class QELA(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """Estimate a glacier's Equilibrium Line Altitude (ELA) from a surface DEM.

    Computes the ELA by the AABR (area-altitude balance ratio), AAR
    (accumulation-area ratio) or AA (area-altitude) method and draws a contour at
    that elevation. The ELA is the altitude where accumulation balances ablation.

    References:
        Osmaston, H., 1975. Models for the estimation of firnlines of present and
            Pleistocene glaciers. In: Peel, R.F., Chisholm, M.D.I., Haggett, P.
            (Eds.), Processes in Physical and Human Geography. Heinemann, London,
            218–245.
        Furbish, D.J., Andrews, J.T., 1984. The use of hypsometry to indicate
            long-term stability and response of valley glaciers to changes in mass
            transfer. Journal of Glaciology 30, 199–211.
        Oien, R.P., Rea, B.R., Spagnolo, M., Barr, I.D., Bingham, R.G., 2021.
            Testing the area-altitude balance ratio (AABR) and accumulation-area
            ratio (AAR) methods of calculating glacier equilibrium-line altitudes.
            Journal of Glaciology 68, 357–368.
    """

    N_STEPS = 4
    _log_tag = 'ELA Processing Log'

    glacier_surface = 'glacier_surface'
    aabr_ratio = 'AABR_ratio'
    aar_ratio = 'AAR_ratio'

    def name(self):
        """Internal algorithm id used by QGIS."""

        return 'Q-ELA'

    def displayName(self):
        """Name shown in the QGIS toolbox."""

        return '5. Q-ELA'

    def group(self):
        """Toolbox group this algorithm sits under."""

        return '\u200cQ-ELA'

    def groupId(self):
        """Unique id of the toolbox group."""
        
        return '2_q-ela'
          
    def tr(self, text):
        """Translate a string through Qt's localisation."""

        return QCoreApplication.translate("ELA", text)
    
    def setProgressText(self, text):
        """Print progress text when running outside the QGIS console."""

        print(text)

    def shortHelpString(self):
        """Help-panel text for the toolbox, with the tool icon as an HTML header."""

        # Add the tool icon to the top of the help text (rendered as HTML).
        icon_url = QUrl.fromLocalFile(
            os.path.join(os.path.dirname(__file__), 'icons', 'qela.png')).toString()
        header = ('<img src="%s" width="28" height="27"/>&nbsp;&nbsp;'
                  '<b>Q-ELA</b>\n\n' % icon_url)

        return header + self.tr(
            "This tool calculates the ELA based on the chosen AABR, AAR, or AA method. "
            "Please choose the method you would like to use from the drop-down list. "
            "A contour polyline is created at the calculated ELA.\n\n"
            "<b>AABR</b>: The Area-Altitude Balance Ratio method considers the distribution of all "
            "glacier elevations. The greatest weight is given to elevations furthest from "
            "the ELA. The AABR method is a more advanced and robust method "
            "(Osmaston, 1975; Furbish and Andrews, 1984; Oien et al., 2021). "
            "N.B. The recommended AABR value is set at the global median value of 1.56 in most "
            "instances (see Oien et al., 2021 for details).\n\n"
            "<b>AAR</b>: The Accumulation Area Ratio method is based on the simple calculation of the "
            "ratio between the glacier accumulation area and the total surface of the glacier. "
            "N.B. The tool requires the input of an area altitude ratio. In the absence of a "
            "regional/local value, it is recommended to use the global median and mean value "
            "of 0.58 (see Oien et al., 2021 for details).\n\n"
            "<b>AA</b>: The Area-Altitude method is a simplified version of the Area-Altitude Balance "
            "Ratio (AABR) method, with an area-altitude balance ratio of 1. The AA ELA of a "
            "glacier corresponds to its area-weighted median elevation.\n\n"
            "<b>References:</b>\n"
            "  - Osmaston, H., 1975. Models for the estimation of firnlines of present and "
            "Pleistocene Glaciers. In: Peel, R.F., Chisholm, M.D.I., Haggett, P. (Eds.), "
            "Processes in Physical and Human Geography, 1975. Bristol Essay, Heinemann, "
            "London, pp. 218–245.\n"
            "  - Furbish, D.J., Andrews, J.T., 1984. The use of hypsometry to indicate long-term "
            "stability and response of valley glaciers to changes in mass transfer. Journal of "
            "Glaciology 30, pp. 199–211.\n"
            "  - Oien, R.P., Rea, B.R., Spagnolo, M., Barr, I.D., Bingham, R.G., 2021. Testing the "
            "area–altitude balance ratio (AABR) and accumulation–area ratio (AAR) methods of "
            "calculating glacier equilibrium-line altitudes. Journal of Glaciology 68, pp. 357–368.")
    
    def icon(self):
        """Toolbox icon for this algorithm."""
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'qela.png')  # Ensure this is the correct filename

        return QIcon(icon_file)
    
    def createInstance(self):
        """Return a fresh instance for QGIS to run."""

        return QELA()

    def createCustomParametersWidget(self, parent=None):
        """
        Build the tool dialog with the icon at the top and the inputs grouped into
        collapsible sections; the AABR and AAR ratio boxes only show for their method.
        Falls back to the standard dialog if it cannot be built.
        """
        try:
            from .grouped_dialog import build_grouped_dialog
            DialogCls = build_grouped_dialog(
                os.path.dirname(__file__), "qela.png", "Q-ELA",
                sections=[
                    ("Inputs", False, ["glacier_surface", "ela_calculation_method"]),
                    ("Parameters", True, ["AABR_ratio", "AAR_ratio"]),
                    ("Output", False, ["ELA_Contour"]),
                ],
                conditionals=[
                    ("AABR_ratio", "ela_calculation_method", lambda v: v == 0),
                    ("AAR_ratio", "ela_calculation_method", lambda v: v == 1),
                ])
            return DialogCls(self, parent=parent)
        except Exception:
            return None
        
    def initAlgorithm(self, config=None):
        """Define the input parameters: glacier surface DEM, ELA method, ratios, contour output."""
        
        # Add input raster layer parameter
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.glacier_surface,
            self.tr("\nSelect glacier surface elevation (DSM/DTM) raster"),
            [_SOURCE_RASTER]))
        
        # Add choice parameter for ELA calculation method
        self.addParameter(QgsProcessingParameterEnum(
            'ela_calculation_method',
            self.tr('\nChoose ELA calculation method'),
            options=['AABR', 'AAR', 'AA'],
            defaultValue='AABR'))
        
        # Input for the area-altitude balance ratio
        self.addParameter(QgsProcessingParameterNumber(
        self.aabr_ratio,
        self.tr("\nAABR - Input balance ratio. (Recommended with the default ratio = 1.56"),
        QgsProcessingParameterNumber.Double, minValue=0.0, maxValue=10.0, defaultValue=1.56))

        # Input for the area-altitude ratio
        self.addParameter(QgsProcessingParameterNumber(
        self.aar_ratio,
        self.tr("\nAAR - Input area-altitude ratio. (between 0 and 1; default ratio = 0.58)"),
        QgsProcessingParameterNumber.Double, minValue=0.0, maxValue=1.0, defaultValue=0.58))

        # Add output vector layer parameter for ELA contour
        self.addParameter(QgsProcessingParameterVectorDestination(
            'ELA_Contour',
            self.tr('\nELA Contour Level'),
            createByDefault=True,
            defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        """Compute the ELA by the chosen method and add its contour to the project."""
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)

        try:
            self._init_logger('q_ela', feedback)

            # Preprocess input
            inputs = self.preprocess_inputs(parameters, context, feedback)
            dem = inputs['dem']
            ela_method = inputs['ela_method']
            crs_string = inputs['crs_string']

            # Log initialisation with the DEM and selected method
            self.log_initialization(feedback, dem, ela_method)
            self._log_run_header({
                'DEM':                f"{dem.name()} ({dem.source()})",
                'ELA Method':          ela_method,
                'CRS':                 crs_string,
            })
            self._log_layer_crs([
                ('DEM', dem),
            ])

            # Calculate ELA
            feedback.setProgressText(f"Calculating ELA using the {ela_method} method...\n")
            start_time = time.time()
            ela_value, ela_method, duration = self.calculate_ela(parameters, context, dem, ela_method, feedback)
            QgsMessageLog.logMessage(f"{ela_method} ELA calculated in {duration:.4f} seconds.",
                                    self._log_tag, level=3)
            if ela_value is None:
                raise QgsProcessingException(
                    f"The {ela_method} method could not determine an ELA for this glacier. "
                    "This can happen when the entire glacier surface is below (or above) the equilibrium line. "
                    "Check that the input raster is clipped to the glacier extent and contains valid elevation data."
                )
            feedback.pushInfo(f"The calculated {ela_method} ELA is: {ela_value:.2f}\n")

            # Create ELA contour layer
            feedback.setProgressText(f"Creating {ela_method} ELA contour layer...\n")
            self.create_ela_contour(parameters, context, feedback, dem, ela_value, ela_method)
            feedback.pushInfo(f"Added {ela_method} ELA contour to QGIS project.\n")
            feedback.setCurrentStep(2)
            if feedback.isCanceled():
                return {}

            # Final logging & return
            self.log_final_results(feedback, crs_string)
            self._log_success(feedback)
            return {"Status": "Complete"}

        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )

    def preprocess_inputs(self, parameters, context, feedback):
        """Read the ELA method choice and the glacier surface DEM, and validate them.

        Rejects a DEM that looks like a hillshade and checks it uses a projected
        CRS. Returns the DEM, method name and CRS string in a dict.
        """

        # Retrieve the selected ELA method.
        ela_calculation_method_index = self.parameterAsEnum(parameters, 'ela_calculation_method', context)
        ela_calculation_method_choices = ['AABR', 'AAR', 'AA']
        ela_method = ela_calculation_method_choices[ela_calculation_method_index]

        # Retrieve the DEM (glacier surface) layer.
        dem = self.parameterAsRasterLayer(parameters, self.glacier_surface, context)
        if dem is None or not dem.isValid():
            raise QgsProcessingException(
                "The glacier surface DEM layer could not be retrieved or is not valid. "
                "Please select a valid raster layer."
            )
        crs = dem.crs()
        crs_string = crs.authid() if crs.isValid() else "Unknown CRS"

        # Validate the DEM layer.
        if not self.validate_dem_input(dem):
            raise QgsProcessingException(
                "The selected raster layer does not appear to be a valid DEM.\n\n"
                "Please ensure you select a raster layer that represents elevations (e.g., not a Hillshade).\n"
            )
        
        # Validate that DEM uses projected CRS
        self.validate_projected_crs(dem, feedback)

        return {
            "dem": dem,
            "ela_method": ela_method,
            "crs_string": crs_string}

    def calculate_ela(self, parameters, context, dem, ela_method, feedback):
        """Dispatch to the AABR, AAR or AA calculation for the chosen method.

        Reads the method's ratio parameter from the dialog and returns
        (ela_value, ela_method, duration in seconds).
        """

        array = self.get_raster_array(dem)
        start_time = time.time()

        if ela_method == 'AABR':
            ratio = self.parameterAsDouble(parameters, 'AABR_ratio', context)
            ela_value = self.aabr_ela(array, ratio)
        elif ela_method == 'AAR':
            ratio = self.parameterAsDouble(parameters, 'AAR_ratio', context)
            ela_value = self.aar_ela(array, ratio)
        elif ela_method == 'AA':
            ela_value = self.aa_ela(array)
        else:
            raise ValueError("Invalid ELA calculation method")

        duration = time.time() - start_time
        return ela_value, ela_method, duration

    def create_ela_contour(self, parameters, context, feedback, dem, ela_value, ela_method):
        """Build the ELA contour layer at the calculated elevation."""

        self.create_contour_layer(
            input_layer=dem,
            output_layer=parameters['ELA_Contour'],
            ela_value=str(ela_value),
            ela_method=ela_method,
            context=context,
            feedback=feedback)


    def validate_dem_input(self, input_raster):
        """Return True if the raster looks like a DEM rather than a hillshade.

        Rejects it by name, or by a 0-255 value range with low standard deviation.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            return False

        # Check filename for hillshade keywords (name is already lowercased)
        hillshade_keywords = ["hillshade", "shaded_relief"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            return False

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            return False

        # If all checks pass, assume it's a valid DEM
        return True
    
    def log_initialization(self, feedback, dem, ela_calculation_method):
        """Write the ELA run's initialisation details to the feedback console."""

        feedback.pushInfo("-------------------------------------------------------------")
        feedback.pushInfo("Initialising ELA Calculation...")
        feedback.pushInfo("-------------------------------------------------------------")
        feedback.pushInfo("Input Parameters:")
        feedback.pushInfo(f"  - DEM: {dem.name()}")
        feedback.pushInfo(f"  - ELA Calculation Method: {ela_calculation_method}")
        feedback.pushInfo("-------------------------------------------------------------")
        feedback.setProgressText("Processing input data...\n")

    def get_raster_array(self, raster):
        """Read the DEM band into a flat numpy array of valid elevations.

        Drops nodata cells and any value <= 0, so only positive elevations reach
        the ELA statistics.
        """
        provider = raster.dataProvider()
        extent = raster.extent()
        width = raster.width()
        height = raster.height()
        
        # Read entire raster block
        block = provider.block(1, extent, width, height)
        
        # Pre-allocate list for valid values (more efficient than dynamic array)
        valid_values = []
        
        # Single loop with row/col calculation (faster than nested loops)
        total_pixels = height * width
        for i in range(total_pixels):
            row = i // width
            col = i % width
            
            if not block.isNoData(row, col):
                value = block.value(row, col)
                if value > 0:  # Only positive elevations
                    valid_values.append(value)
        
        return np.array(valid_values, dtype=np.float64)
        
    def aabr_ela(self, array, ratio):
        """Compute the ELA by the area-altitude balance ratio (AABR) method.

        Weights each altitude band's area by its elevation difference from a trial
        ELA, down-weighting the ablation area by ``ratio``, and returns the lowest
        altitude at which the balance turns negative.

        Args:
            array: DEM elevations in metres (flattened).
            ratio: area-altitude balance ratio (global median about 1.56).

        Returns:
            The AABR ELA in metres, or None if no balance point is found.
        """

        # Convert the array to integers
        array = array.astype(int)

        # Get unique values and their counts, filtered for positive altitudes
        unique_values, counts = np.unique(array[array > 0], return_counts=True)

        # Combine unique values and counts into a sorted array
        altitude_data = np.column_stack((unique_values, counts))

        # Extract altitudes and counts as separate arrays for vectorized computation
        altitudes = altitude_data[:, 0]
        counts = altitude_data[:, 1]

        # Initialise ELA value
        ela_value = None

        # Vectorized computation to evaluate the sum for each altitude
        for altitude in altitudes:
            differences = altitudes - altitude
            weighted_differences = np.where(differences >= 0, differences, differences * ratio)
            sum_val = np.sum(weighted_differences * counts)

            if sum_val < 0:
                ela_value = altitude
                break

        # Convert calculated ELA to int and return
        ela_int = int(ela_value) if ela_value is not None else None
        return ela_int

    def aar_ela(self, array, ratio):
        """Compute the ELA by the accumulation-area ratio (AAR) method.

        Accumulates band areas from the top down and returns the elevation at
        which the cumulative area reaches ``ratio`` of the total.

        Args:
            array: DEM elevations in metres (flattened).
            ratio: accumulation-area ratio between 0 and 1 (global median about
                0.58).

        Returns:
            The AAR ELA in metres, or None if the glacier has no valid pixels.
        """

        # Ensure values are positive integers (e.g., no nodata or negative elevations)
        array = array[array > 0].astype(int)
        if array.size == 0:
            return None

        # Count the number of pixels at each elevation
        unique_elevs, counts = np.unique(array, return_counts=True)

        # Sort elevations from high to low
        sorted_indices = np.argsort(unique_elevs)[::-1]
        elevs_desc = unique_elevs[sorted_indices]
        counts_desc = counts[sorted_indices]

        # Compute cumulative area from top down
        cumulative_area = np.cumsum(counts_desc)

        # Total glacier area in pixels
        total_area = cumulative_area[-1]

        # Compute cumulative ratio
        cumulative_ratio = cumulative_area / total_area

        # Find the elevation where the cumulative ratio is >= the AAR threshold.
        # np.argmax() returns 0 when no element matches, so use np.where instead.
        indices = np.where(cumulative_ratio >= ratio)[0]
        idx = indices[0] if len(indices) > 0 else len(elevs_desc) - 1
        ela = elevs_desc[idx]

        return int(ela)
        
    def aa_ela(self, array):
        """Compute the ELA by the area-altitude (AA) method.

        Returns the area-weighted mean elevation, equivalent to AABR with a
        balance ratio of 1.

        Args:
            array: DEM elevations in metres (flattened).

        Returns:
            The AA ELA in metres, or None if there are no valid pixels.
        """
        
        # Convert the array to integers and filter out negative values
        valid_array = array[array >= 0].astype(int)
        if valid_array.size == 0:
            return None
        unique_values, counts = np.unique(valid_array, return_counts=True)

        # Calculate the weighted sum of elevations
        weighted_sum = np.sum(unique_values * counts)

        # Calculate the total number of glacier pixels
        total_pixels = np.sum(counts)
        if total_pixels == 0:
            return None

        # Compute the area-weighted mean elevation
        ela_aa = weighted_sum / total_pixels

        # Return the ELA rounded to the nearest integer
        return int(round(ela_aa))
    
    def create_contour_layer(self, input_layer, output_layer, ela_value, ela_method, context, feedback=None):
        """Run gdal:contour to draw a single polyline at the ELA elevation.

        Names the output after the ELA method and warns if the contour is empty,
        which means the ELA lies outside the raster's elevation range.
        """


        # Prepare algorithm parameters
        alg_params = {
            'INPUT': input_layer,
            'BAND': 1,
            'INTERVAL': 0.0,
            'EXTRA': f'-fl {ela_value}',
            'FIELD_NAME': 'ELA_Elev',
            'IGNORE_NODATA': False,
            'NODATA': None,
            'OUTPUT': output_layer
        }

        # Run the contour algorithm
        contour_out = self._run_algorithm(
            'gdal:contour', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Create ELA contour layer'
        )
        ela_contour = contour_out['OUTPUT']

        # Warn if the contour layer is empty (ELA outside raster elevation range)
        contour_layer = QgsProcessingUtils.mapLayerFromString(ela_contour, context)
        if contour_layer and contour_layer.featureCount() == 0:
            feedback.pushWarning(
                f"The {ela_method} ELA contour layer is empty. "
                f"The calculated ELA ({ela_value} m) may lie outside the elevation range of the input raster. "
                "Check that the raster is clipped to the glacier extent.\n"
            )

        # Load the contour vector polyline into QGIS project, grouped under Q-ELA
        _details = context.layerToLoadOnCompletionDetails(ela_contour)
        _details.name = f"{ela_method} ELA Contour"
        self._set_layer_group(_details, "Q-ELA")

        return output_layer
    
    def postProcessAlgorithm(self, context, feedback):
        """Show a completion dialog once processing finishes."""
        
        # Display completion message using a QMessageBox
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle('ELA Calculation')
        msg_box.setText(f"Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)