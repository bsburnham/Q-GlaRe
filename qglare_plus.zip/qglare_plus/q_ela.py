"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : Q-ELA
Group : Q-ELA
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time
import numpy as np
import pandas as pd
from osgeo import gdal
import processing
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (QgsProject,
                       QgsVectorLayer,
                       QgsProcessing,
                       QgsMessageLog,
                       QgsRasterBandStats,
                       QgsProcessingException,
                       QgsProcessingAlgorithm, 
                       QgsProcessingParameterEnum,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorDestination)

class QELA(QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for calculating the Equilibrium Line Altitude (ELA) of glaciers.

    This tool estimates the ELA based on three widely used methods: AABR, AAR, and AA. The ELA 
    represents the elevation at which glacier mass gain (accumulation) equals mass loss (ablation), 
    and it is a critical metric in glaciology.

    Key Features:
    - Validates input DEM to ensure proper elevation data is provided.
    - Supports three ELA calculation methods:
        - AABR (Area-Altitude Balance Ratio): Accounts for glacier hypsometry with weighted elevation contributions.
        - AAR (Accumulation Area Ratio): Simple ratio-based approach using glacier accumulation area.
        - AA (Area-Altitude): Simplified version of AABR with an altitude balance ratio of 1.
    - Creates a contour layer at the calculated ELA elevation for easy visualization.

    Inputs:
    - DEM: Raster layer representing glacier surface elevation (DSM/DTM).
    - ELA calculation method: Selection of AABR, AAR, or AA.
    - Relevant ratios for the AABR and AAR methods.

    Outputs:
    - ELA contour vector layer for integration into QGIS projects.

    References:
    - Osmaston, H., 1975. Models for the estimation of firnlines of present and Pleistocene glaciers. 
      In: Peel, R.F., Chisholm, M.D.I., Haggett, P. (Eds.), Processes in Physical and Human Geography. 
      Bristol Essays, Heinemann, London, pp. 218-245.
    - Furbish, D.J., Andrews, J.T., 1984. The use of hypsometry to indicate long-term stability and response 
      of valley glaciers to changes in mass transfer. Journal of Glaciology, 30, pp. 199-211.
    - Oien, R.P., Rea, B.R., Spagnolo, M., Barr, I.D., Bingham, R.G., 2021. Testing the area-altitude balance 
      ratio (AABR) and accumulation-area ratio (AAR) methods of calculating glacier equilibrium-line altitudes. 
      Journal of Glaciology, 68, pp. 357-368.
    """

    glacier_surface = 'glacier_surface'
    aabr_ratio = 'AABR_ratio'
    aar_ratio = 'AAR_ratio'

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return 'Q-ELA'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """

        return '5. Q-ELA'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200cQ-ELA'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """
        
        return '2_q-ela'
          
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("ELA", text)
    
    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)

    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """

        return self.tr(
            "This tool calculates the ELA based on the chosen AABR, AAR, or AA method. "
            "Please choose the method you would like to use from the drop-down list. "
            "A contour polyline is created at the calculated ELA.\n\n"
            "AABR: The Area-Altitude Balance Ratio method considers the distribution of all "
            "glacier elevations. The greatest weight is given to elevations furthest from "
            "the ELA. The AABR method is a more advanced and robust method "
            "(Osmaston, 1975; Furbish and Andrews, 1984; Oien et al., 2021). "
            "N.B. The recommended AABR value is set at the global median value of 1.56 in most "
            "instances (see Oien et al., 2021 for details).\n\n"
            "AAR: The Accumulation Area Ratio method is based on the simple calculation of the "
            "ratio between the glacier accumulation area and the total surface of the glacier. "
            "N.B. The tool requires the input of an area altitude ratio. In the absence of a "
            "regional/local value, it is recommended to use the global median and mean value "
            "of 0.58 (see Oien et al., 2021 for details).\n\n"
            "AA: The Area-Altitude method is a simplified version of the Area-Altitude Balance "
            "Ratio (AABR) method, with an area-altitude balance ratio of 1. The AA ELA of a "
            "glacier corresponds to its area-weighted median elevation.\n\n"
            "References:\n"
            "  - Osmaston, H., 1975. Models for the estimation of firnlines of present and "
            "Pleistocene Glaciers. In: Peel, R.F., Chisholm, M.D.I., Haggett, P. (Eds.), "
            "Processes in Physical and Human Geography, 1975. Bristol Essay, Heinemann, "
            "London, pp. 218–245.\n"
            "  - Furbish, D.J., Andrews, J.T., 1984. The use of hypsometry to indicate long-term "
            "stability and response of valley glaciers to changes in mass transfer. Journal of "
            "Glaciology 30, pp. 199–211.\n"
            "  - Oien, R.P., Rea, B.R., Spagnolo, M., Barr, I.D., Bingham, R.G., 2021. Testing the "
            "area–altitude balance ratio (AABR) and accumulation–area ratio (AAR) methods of "
            "calculating glacier equilibrium-line altitudes. Journal of Glaciology 68, pp. 357–368.")
    
    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'qela.png')  # Ensure this is the correct filename

        return QIcon(icon_file)
    
    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            QELA: A new instance of the `QELA` class.
        """

        return QELA()
        
    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.

        Parameters:
            config (dict, optional): Configuration dictionary (default: None).

        Returns:
            None
        """
        
        # Add input raster layer parameter
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.glacier_surface,
            self.tr("\nSelect glacier surface elevation (DSM/DTM) raster"),
            [QgsProcessing.TypeRaster]))
        
        # Add choice parameter for ELA calculation method
        self.addParameter(QgsProcessingParameterEnum(
            'ela_calculation_method',
            self.tr('\nChoose ELA calculation method'),
            options=['AABR', 'AAR', 'AA'],
            defaultValue='AABR'))
        
        # Input for the area-altitude balance ratio
        self.addParameter(QgsProcessingParameterNumber(
        self.aabr_ratio,
        self.tr("\nAABR - Input balance ratio. (Recommended with the default ratio = 1.56"),
        QgsProcessingParameterNumber.Double, minValue=0.0, maxValue=10.0, defaultValue=1.56))      

        # Input for the area-altitude ratio
        self.addParameter(QgsProcessingParameterNumber(
        self.aar_ratio,
        self.tr("\nAAR - Input area-altitude ratio. (between 0 and 1; default ratio = 0.58)"),
        QgsProcessingParameterNumber.Double, minValue=0.0, maxValue=1.0, defaultValue=0.58))

        # Add output vector layer parameter for ELA contour
        self.addParameter(QgsProcessingParameterVectorDestination(
            'ELA_Contour',
            self.tr('\nELA Contour Level'),
            createByDefault=True,
            defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Processes the algorithm to calculate ELA (Equilibrium Line Altitude) based on the selected method.
        """
        feedback = QgsProcessingMultiStepFeedback(4, model_feedback)

        # Preprocess input
        inputs = self.preprocess_inputs(parameters, context, feedback)
        dem = inputs['dem']
        ela_method = inputs['ela_method']
        crs_string = inputs['crs_string']

        # Log initialization with the DEM and selected method
        self.log_initialization(feedback, dem, ela_method)

        # Calculate ELA
        feedback.setProgressText(f"Calculating ELA using the {ela_method} method...\n")
        start_time = time.time()
        ela_value, ela_method, duration = self.calculate_ela(parameters, context, dem, ela_method, feedback)
        QgsMessageLog.logMessage(f"{ela_method} ELA calculated in {duration:.4f} seconds.", 
                                "ELA Processing Log", level=3)
        feedback.pushInfo(f"The calculated {ela_method} ELA is: {ela_value:.2f}\n")

        # Create ELA contour layer
        feedback.setProgressText(f"Creating {ela_method} ELA contour layer...\n")
        self.create_ela_contour(parameters, context, feedback, dem, ela_value, ela_method)
        feedback.pushInfo(f"Added {ela_method} ELA contour to QGIS project.\n")
        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Final logging & return
        self.log_final_results(feedback, crs_string)
        return {"Status": "Complete"}

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieve and validate the input DEM and the selected ELA method.

        This function:
        - Retrieves the selected ELA calculation method from user parameters.
        - Loads the input DEM (glacier surface) layer.
        - Extracts the CRS from the DEM and creates a human-readable CRS string.
        - Validates that the DEM is appropriate (i.e., not a hillshade).

        Parameters:
            parameters (dict): Dictionary of parameter values provided to the algorithm.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): Object for logging messages and progress.

        Returns:
            dict: A dictionary with the following keys:
                - "dem" (QgsRasterLayer): The input DEM layer.
                - "ela_method" (str): The selected ELA calculation method (e.g., 'AABR', 'AAR', or 'AA').
                - "crs_string" (str): A human-readable CRS string.

        Raises:
            QgsProcessingException: If the DEM fails validation.
        """

        # Retrieve the selected ELA method.
        ela_calculation_method_index = self.parameterAsEnum(parameters, 'ela_calculation_method', context)
        ela_calculation_method_choices = ['AABR', 'AAR', 'AA']
        ela_method = ela_calculation_method_choices[ela_calculation_method_index]

        # Retrieve the DEM (glacier surface) layer.
        dem = self.parameterAsRasterLayer(parameters, self.glacier_surface, context)
        crs = dem.crs()
        crs_string = crs.authid() if crs.isValid() else "Unknown CRS"

        # Validate the DEM layer.
        if not self.validate_dem_input(dem):
            raise QgsProcessingException(
                "The selected raster layer does not appear to be a valid DEM.\n\n"
                "Please ensure you select a raster layer that represents elevations (e.g., not a Hillshade).\n"
            )

        return {
            "dem": dem,
            "ela_method": ela_method,
            "crs_string": crs_string}

    def calculate_ela(self, parameters, context, dem, ela_method, feedback):
        """
        Calculate the Equilibrium Line Altitude (ELA) using the selected method.

        This function:
        - Converts the input DEM to a numpy array.
        - Depending on the selected ELA method ('AABR', 'AAR', or 'AA'), invokes the corresponding ELA calculation function.
        - Measures and returns the computation duration.

        Parameters:
            parameters (dict): Dictionary of algorithm parameter values.
            context (QgsProcessingContext): QGIS processing context.
            dem (QgsRasterLayer): The input DEM layer.
            ela_method (str): The chosen ELA calculation method.
            feedback (QgsProcessingFeedback): Object for logging messages and progress.

        Returns:
            tuple: A tuple (ela_value, ela_method, duration) where:
                - ela_value (int): The calculated ELA value.
                - ela_method (str): The method used for ELA calculation.
                - duration (float): The computation time in seconds.

        Raises:
            ValueError: If an invalid ELA calculation method is provided.
        """

        array = self.get_raster_array(dem)
        start_time = time.time()

        if ela_method == 'AABR':
            ratio = self.parameterAsDouble(parameters, 'AABR_ratio', context)
            ela_value = self.aabr_ela(array, ratio)
        elif ela_method == 'AAR':
            ratio = self.parameterAsDouble(parameters, 'AAR_ratio', context)
            ela_value = self.aar_ela(array, ratio)
        elif ela_method == 'AA':
            ela_value = self.aa_ela(array)
        else:
            raise ValueError("Invalid ELA calculation method")

        duration = time.time() - start_time
        return ela_value, ela_method, duration

    def create_ela_contour(self, parameters, context, feedback, dem, ela_value, ela_method):
        """
        Create the ELA contour layer using the calculated ELA value.

        This function:
        - Invokes the contour creation process (via create_contour_layer) to generate a contour vector layer.
        - Uses the input DEM as the base layer for generating contours.
        - Sets the output layer name based on the selected ELA method.

        Parameters:
            parameters (dict): Dictionary of parameter values, including the output path for the ELA contour.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for logging progress.
            dem (QgsRasterLayer): The input DEM layer.
            ela_value (float): The calculated ELA value.
            ela_method (str): The ELA calculation method used (e.g., 'AABR', 'AAR', or 'AA').

        Returns:
            None
        """

        self.create_contour_layer(
            input_layer=dem,
            output_layer=parameters['ELA_Contour'],
            ela_value=str(ela_value),
            ela_method=ela_method,
            context=context,
            feedback=feedback)


    def validate_dem_input(self, input_raster):
        """
        Validate the input raster to ensure it is a valid DEM and not a Hillshade.

        This function:
        - Checks whether the input raster layer is valid.
        - Scans the raster's name for hillshade-related keywords.
        - Evaluates raster statistics (value range and standard deviation) to decide if the raster is likely a DEM.

        Parameters:
            input_raster (QgsRasterLayer): The raster layer to validate.

        Returns:
            bool: True if the raster appears to be a valid DEM; False otherwise.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            return False

        # Check filename for "hillshade" or similar keywords
        hillshade_keywords = ["hillshade", "shade", "Hillshade", "Shade", "HILLSHADE", "SHADE"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            return False

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1, QgsRasterBandStats.All)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            return False

        # If all checks pass, assume it's a valid DEM
        return True

    def log_initialization(self, feedback, dem, ela_calculation_method):
        """
        Log initialization details for the ELA calculation workflow.

        This function:
        - Logs the input parameters, including the DEM name and the selected ELA calculation method.
        - Updates the feedback object with the initial progress text.

        Parameters:
            feedback (QgsProcessingFeedback): The feedback object used for logging and progress updates.
            dem (QgsRasterLayer): The input DEM layer.
            ela_calculation_method (str): The selected ELA calculation method.

        Returns:
            None
        """

        feedback.pushInfo("-------------------------------------------------------------")
        feedback.pushInfo("Initializing ELA Calculation...")
        feedback.pushInfo("-------------------------------------------------------------")
        feedback.pushInfo("Input Parameters:")
        feedback.pushInfo(f"  - DEM: {dem.name()}")
        feedback.pushInfo(f"  - ELA Calculation Method: {ela_calculation_method}")
        feedback.pushInfo("-------------------------------------------------------------")
        feedback.setProgressText("Processing input data...\n")

    def log_final_results(self, feedback, crs_string):
        """
        Log final results for the ELA calculation workflow.

        This function:
        - Logs messages summarizing the final output and CRS information.
        - Updates the feedback object to indicate 100% progress and a completion message.

        Parameters:
            feedback (QgsProcessingFeedback): The feedback object used for progress and logging.
            crs_string (str): A human-readable CRS identifier for the processed data.

        Returns:
            None
        """

        QgsMessageLog.logMessage(f"All data calculated in projection: {crs_string}", "ELA Processing Log", level=3)
        QgsMessageLog.logMessage("-----------------------------------------END PROCESS-----------------------------------------\n", 
                                "ELA Processing Log", level=0)
        feedback.pushInfo(f"All data processed and projected in: {crs_string}\n")
        feedback.setProgress(100)
        feedback.setProgressText("Processing Complete!\n")
        
    def get_raster_array(self, raster):
        """
        Convert a raster layer to a numpy array while handling nodata values.

        This function:
        - Retrieves the raster source and creates a GDAL dataset.
        - Reads the raster data into a numpy array.
        - Replaces nodata values with NaN and filters them out.

        Parameters:
            raster (QgsRasterLayer): The input DEM raster layer.

        Returns:
            numpy.ndarray: A numpy array of the raster data with nodata values handled appropriately.

        Raises:
            FileNotFoundError: If the raster file cannot be opened.
        """

        # Set and open raster using GDAL with an error check
        raster_path = raster.source()
        
        extent = raster.extent()
        provider = raster.dataProvider()
        rows = raster.rasterUnitsPerPixelY()
        cols = raster.rasterUnitsPerPixelX()
        x = int(rows)
        y = int(cols)

        block = provider.block(1, extent,  x, y)
        nodatavalue = block.noDataValue()

        # Open and convert raster to numpy array 
        rasterDS = gdal.Open(raster_path, gdal.GA_ReadOnly)
        if rasterDS is None:
            raise FileNotFoundError("Could not open raster file")
        array1 = rasterDS.ReadAsArray()

        # Handle nodata values
        array2 = np.where(array1 == nodatavalue, np.nan, array1)
        array2 = array2[np.logical_not(np.isnan(array2))]
        
        return array2
        
    def aabr_ela(self, array, ratio):
        """
        Calculate ELA using the AABR (Area-Altitude Balance Ratio) method.

        This function:
        - Converts the input raster array to integers.
        - Extracts unique positive altitude values and their counts.
        - Iterates over the altitudes using a vectorized approach to compute a weighted sum.
        - Determines the ELA as the first altitude where the weighted sum is negative.
        - Rounds and returns the ELA value.

        Parameters:
            array (numpy.ndarray): A numpy array representing the DEM data.
            ratio (float): The ratio parameter specific to the AABR method.

        Returns:
            int: The calculated AABR ELA value rounded to the nearest integer.
        """

        # Convert the array to integers
        array = array.astype(int)

        # Get unique values and their counts, filtered for positive altitudes
        unique_values, counts = np.unique(array[array > 0], return_counts=True)

        # Combine unique values and counts into a sorted array
        altitude_data = np.column_stack((unique_values, counts))

        # Extract altitudes and counts as separate arrays for vectorized computation
        altitudes = altitude_data[:, 0]
        counts = altitude_data[:, 1]

        # Initialize ELA value
        ela_value = None

        # Vectorized computation to evaluate the sum for each altitude
        for altitude in altitudes:
            differences = altitudes - altitude
            weighted_differences = np.where(differences >= 0, differences, differences * ratio)
            sum_val = np.sum(weighted_differences * counts)

            if sum_val < 0:
                ela_value = altitude
                break

        # Convert calculated ELA to int and return
        ela_int = int(ela_value) if ela_value is not None else None
        return ela_int

    def aar_ela(self, array, ratio):
        """
        Calculate ELA using the classical Accumulation Area Ratio (AAR) method.

        This function:
        - Counts the number of glacier pixels at each elevation.
        - Sorts elevation bands from highest to lowest.
        - Computes cumulative area above each elevation.
        - Determines the elevation at which the cumulative area equals the AAR ratio.
        
        Parameters:
            array (numpy.ndarray): A numpy array representing the DEM data.
            ratio (float): The user-defined AAR ratio.
        
        Returns:
            int: The calculated AAR ELA elevation.
        """

        # Ensure values are positive integers (e.g., no nodata or negative elevations)
        array = array[array > 0].astype(int)

        # Count the number of pixels at each elevation
        unique_elevs, counts = np.unique(array, return_counts=True)

        # Sort elevations from high to low
        sorted_indices = np.argsort(unique_elevs)[::-1]
        elevs_desc = unique_elevs[sorted_indices]
        counts_desc = counts[sorted_indices]

        # Compute cumulative area from top down
        cumulative_area = np.cumsum(counts_desc)

        # Total glacier area in pixels
        total_area = cumulative_area[-1]

        # Compute cumulative ratio
        cumulative_ratio = cumulative_area / total_area

        # Find the elevation where the cumulative ratio is >= the AAR threshold
        idx = np.argmax(cumulative_ratio >= ratio)
        ela = elevs_desc[idx]

        return int(ela)
        
    def aa_ela(self, array):
        """
        Calculate ELA using the AA (Area-Altitude) ratio method.

        This function:
        - Converts the DEM array to integers and filters out negative values.
        - Calculates unique altitudes and counts.
        - Computes the area-weighted mean elevation.
        - Rounds and returns the calculated AA ELA value.

        Parameters:
            array (numpy.ndarray): A numpy array representing the DEM data.

        Returns:
            int: The calculated AA ELA value rounded to the nearest integer.
        """
        
        # Convert the array to integers and filter out negative values
        valid_array = array[array >= 0].astype(int)
        unique_values, counts = np.unique(valid_array, return_counts=True)

        # Calculate the weighted sum of elevations
        weighted_sum = np.sum(unique_values * counts)
        
        # Calculate the total number of glacier pixels
        total_pixels = np.sum(counts)
        
        # Compute the area-weighted mean elevation
        ela_aa = weighted_sum / total_pixels

        # Return the ELA rounded to the nearest integer
        return int(round(ela_aa))
    
    def create_contour_layer(self, input_layer, output_layer, ela_value, ela_method, context, feedback=None):
        """
        Create an ELA contour layer from the input DEM based on the calculated ELA value.

        This function:
        - Prepares parameters for the contour generation algorithm (using GDAL).
        - Runs the contour algorithm to create a polyline contour at the specified ELA.
        - Sets the output layer name based on the ELA method used.
        
        Parameters:
            input_layer (str): The file path to the input DEM raster.
            output_layer (str): The file path where the contour layer will be saved.
            ela_value (float): The calculated ELA value.
            ela_method (str): The ELA calculation method used (e.g., 'AABR', 'AAR', or 'AA').
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback, optional): Object for logging progress.

        Returns:
            str: The file path to the output contour layer.
        """


        # Prepare algorithm parameters
        alg_params = {
            'INPUT': input_layer,
            'BAND': 1,
            'INTERVAL': 0.0,
            'EXTRA': f'-fl {ela_value}',
            'FIELD_NAME': 'ELA_Elev',
            'IGNORE_NODATA': False,
            'NODATA': None,
            'OUTPUT': output_layer
        }

        # Run the contour algorithm
        contour_out = processing.run('gdal:contour', alg_params, context=context, feedback=None)
        ela_contour = contour_out['OUTPUT']

        # Load the contour vector polyline into QGIS project
        context.layerToLoadOnCompletionDetails(ela_contour).name = f"{ela_method} ELA Contour"

        return output_layer
    
    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message after processing and perform any necessary post-processing tasks.

        This function:
        - Creates and displays a QMessageBox with a completion message.
        - Sets the processing progress to 100% and updates the progress text.
        - Returns a dictionary indicating the status of post-processing.

        Parameters:
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): The feedback object for progress updates.

        Returns:
            dict: A dictionary reflecting the post-processing completion status.
        """
        
        # Display completion message using a QMessageBox
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle('ELA Calculation')
        msg_box.setText(f"Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec_()
        
        return super().postProcessAlgorithm(context, feedback)