"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 3D Interpolation
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, sys, time, platform, traceback
import numpy as np
from osgeo import ogr, gdal
ogr.UseExceptions()
from .qglare_base import QGlaReAlgorithmMixin
import processing
from qgis.PyQt.QtCore import QCoreApplication, QSettings, QVariant, QMetaType
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import (Qgis,
                       QgsProject,
                       QgsField,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsRasterLayer,
                       QgsSpatialIndex,
                       QgsProcessingUtils,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterBoolean,
                       QgsProcessingParameterDefinition,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingParameterRasterDestination,
                       )

# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38 —
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
_FIELD_DOUBLE = QMetaType.Type.Double if Qgis.QGIS_VERSION_INT >= 33800 else QVariant.Double


# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_RASTER = Qgis.ProcessingSourceType.Raster
    _SOURCE_VECTOR_POINT = Qgis.ProcessingSourceType.VectorPoint
    _SOURCE_VECTOR_POLYGON = Qgis.ProcessingSourceType.VectorPolygon
except AttributeError:                          # QGIS < 3.36
    _SOURCE_RASTER = QgsProcessing.TypeRaster
    _SOURCE_VECTOR_POINT = QgsProcessing.TypeVectorPoint
    _SOURCE_VECTOR_POLYGON = QgsProcessing.TypeVectorPolygon



def get_qgis_saga_directory():
    """
    Retrieve the QGIS Processing SAGA directory from the correct settings key.
    Returns the directory path if found; otherwise, an empty string.
    """
    saga_dir = QSettings().value('Processing/Configuration/SAGA_FOLDER', '').strip()
    return os.path.normpath(saga_dir) if saga_dir else ""

def check_qgis_saga_directory():
    """
    Check if the QGIS Processing SAGA directory is set and valid.
    
    Returns:
        tuple: (status (bool), message (str))
    """
    saga_dir = get_qgis_saga_directory()

    if saga_dir and os.path.isdir(saga_dir):
        return True, f"SAGA directory is set: {saga_dir}"
    
    return (
        False,
        "SAGA directory is not set or is invalid in QGIS Processing options.\n"
        "Please set it via: Settings > Options > Processing > Providers > SAGA."
    )

def check_saga_installation():
    """
    Check if SAGA GIS is installed.
    
    Returns:
        tuple: (status (bool), message (str))
    """
    binary_names = ["saga_cmd.exe", "saga_cmd"] if platform.system() == "Windows" else ["saga_cmd"]
    saga_dir = get_qgis_saga_directory()

    if saga_dir and os.path.isdir(saga_dir):
        for binary in binary_names:
            binary_path = os.path.join(saga_dir, binary)
            if os.path.isfile(binary_path):
                return True, f"SAGA binary found: {binary_path}"
        return (
            False,
            f"SAGA directory is set to '{saga_dir}', but no SAGA binary was found there.\n"
            "Please check your installation or reinstall SAGA."
        )

    return (
        False,
        "SAGA is not installed or configured properly.\n"
        "Ensure SAGA is installed and the directory is set in QGIS:\n"
        "Settings > Options > Processing > Providers > SAGA."
    )

def check_saga_plugin():
    """
    Check if the SAGA GIS plugin is installed and enabled.
    
    Returns:
        tuple: (status (bool), message (str))
    """
    try:
        from qgis.utils import plugins
    except Exception:
        return False, "Error accessing QGIS plugins."

    plugin_names = ["processing_saga_nextgen", "processing_sagang_nextgen"]
    for name in plugin_names:
        if name in plugins:
            return True, f"SAGA plugin '{name}' is installed."
    
    return (
        False,
        "SAGA plugin is not installed.\n"
        "Please install it via: Plugins > Manage and Install Plugins."
    )

def check_dependencies(feedback=None):
    """
    Perform a combined dependency check for SAGA GIS installation, the plugin,
    and the QGIS Processing SAGA directory configuration.
    
    Returns:
        bool: True if all dependencies are satisfied; False otherwise.
    """
    saga_installed, saga_msg = check_saga_installation()
    plugin_installed, plugin_msg = check_saga_plugin()
    saga_dir_set, saga_dir_msg = check_qgis_saga_directory()

    error_messages = []
    
    # Print success messages only
    if saga_installed:
        print(saga_msg)
    else:
        error_messages.append(saga_msg)

    if plugin_installed:
        print(plugin_msg)
    else:
        error_messages.append(plugin_msg)

    if not saga_dir_set:
        error_messages.append(saga_dir_msg)

    # Show error messages if any issues exist
    if error_messages:
        full_error_message = "Dependency check failed:\n\n" + "\n\n".join(error_messages)
        if feedback:
            feedback.reportError(full_error_message)
        else:
            print(full_error_message)

    return saga_installed and plugin_installed and saga_dir_set

class Interpolation(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for reconstructing glacier surfaces 
    and estimating ice thickness using spatial interpolation.

    This tool uses input data such as ice thickness points, 
    a DEM (DSM/DTM), and a basin extent polygon to generate 
    interpolated raster layers of the reconstructed glacier surface 
    and thickness. The tool applies the methodology from 
    Pellitero et al. (2015, 2016) and uses Thin Plate Spline 
    interpolation for surface reconstruction.

    Key Features:
    - Input Validation: Validates DEM and ice thickness points with 
        required fields.
    - Regular Grid Creation: Generates a grid of points for 
        interpolation based on user-specified resolution.
    - Interpolation: Applies Thin Plate Spline (TPS) interpolation 
        to compute the glacier surface elevation.
    - Ice Thickness Calculation: Derives ice thickness from the 
        interpolated surface.
    - Smoothing and Clipping: Applies Gaussian smoothing and clips 
        results to the study area polygon.
    - Outputs: Produces raster layers for:
        - Reconstructed glacier thickness.
        - Reconstructed glacier surface elevation.

    Inputs:
    - DEM: Raster layer of current topography (DSM/DTM).
    - Ice Thickness Points: Vector point layer containing ice surface 
        or thickness data.
    - Basin Extent Polygon: Polygon vector defining the study area.
    - Interpolation Interval: Resolution for generating a regular grid 
        of interpolation points.


    Outputs:
    - Reconstructed Glacier Thickness: Raster layer showing interpolated 
        ice thickness.
    - Reconstructed Glacier Surface: Raster layer showing interpolated 
        glacier surface elevation.

    References:
    - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Hughes, P., Ivy-Ochs, S., 
        Lukas, S., & Ribolini, A., 2015. A GIS tool for automatic calculation of 
        glacier equilibrium-line altitudes. Computers & Geosciences, 82, pp. 55-62.
    - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Ivy-Ochs, S., Frew, C.R., 
        Hughes, P., Ribolini, A., Lukas, S., & Renssen, H., 2016. GlaRe, a GIS tool 
        to reconstruct the 3D surface of palaeoglaciers. Computers & Geosciences, 94, pp. 77-85.
    - SAGA GIS, Thin Plate Spline (TPS) Method: Documentation available at https://saga-gis.sourceforge.io.
    """

    N_STEPS = 19
    _log_tag = 'Glacier Reconstruction Processing Log'

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    input_polygon = 'input_polygon'
    ice_flow_thickness = 'ice_flow_thickness'
    apply_smoothing = 'ApplySmoothing'

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return '3D Interpolation'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """

        return '4. 3D Interpolation'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
        
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("Interpolation", text)
    
    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)
     
    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """

        return self.tr(
            "A tool to reconstruct glacier surfaces and estimate ice thickness based on its basal topography "
            "and down valley limit (usually indicated by the position of a terminal moraine). "
            "A Thin Plate Spline (TPS) interpolation method is used to generate continuous raster layers "
            "that represent the reconstructed glacier surface elevation and ice thickness. " 
            "The methodology is based on Pellitero et al., (2015, 2016). \n"
            "Ice flow thickness points and the basin outline of the glacier are required user input data. "
            "Reconstructed surface resolution may be defined by the user, but will default "
            "to the input DEM resolution if not explicitly defined. \n"
            "Gaussian smoothing of the output rasters is applied by default with a "
            "resolution-aware kernel (radius capped at 10% of glacier dimension); it can be "
            "disabled, or the kernel radius overridden (advanced option). The effective "
            "radius is reported in the processing log. \n\n"
            
            "Outputs include:\n"
            "- Reconstructed Glacier Thickness: A raster layer of the estimated ice thickness.\n"
            "- Reconstructed Glacier Surface: A raster layer of the glacier's interpolated surface elevation.\n\n"
            "References:\n"
            "  - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Hughes, P., Ivy-Ochs, S., Lukas, S., & Ribolini, A., 2015. "
            "A GIS tool for automatic calculation of glacier equilibrium-line altitudes. Computers & Geosciences, 82, pp. 55-62.\n"
            "  - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Ivy-Ochs, S., Frew, C.R., Hughes, P., Ribolini, A., Lukas, S., "
            "& Renssen, H., 2016. GlaRe, a GIS tool to reconstruct the 3D surface of palaeoglaciers. Computers & Geosciences, 94, pp. 77-85.\n"
            "  - Thin Plate Spline (TPS) Method: Documentation available at https://saga-gis.sourceforge.io.")

    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            Interpolation: A new instance of the `Interpolation` class.
        """

        return Interpolation()
    
    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'reconstruct.png')  # Ensure this is the correct filename

        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """

        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem,
        self.tr("\nSelect current topography elevation data (DSM/DTM) raster"),
        [_SOURCE_RASTER]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.ice_flow_thickness, 
        self.tr("\nSelect ice flow thickness points (vector point file)"),
        [_SOURCE_VECTOR_POINT]))

        self.addParameter(QgsProcessingParameterNumber(
        self.user_interval,
        self.tr("\nSpecify the resolution of 3D interpolated surface in map units.\n"
                "Leave blank or 0 to use input DEM resolution. "
                "Minimum spacing is 25 map units. \n"
                "Values below 25 map units will be automatically adjusted. "),
        QgsProcessingParameterNumber.Integer, defaultValue=None))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_polygon,
        self.tr("\nSelect a polygon (vector polygon file) that defines the basin area containing the glacier."),
        [_SOURCE_VECTOR_POLYGON]))

        self.addParameter(QgsProcessingParameterBoolean(
        self.apply_smoothing,
        self.tr("\nApply Gaussian smoothing to the output rasters (recommended)"),
        defaultValue=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
        'ReconstructedGlacierThickness', '\nReconstructed Glacier Thickness',
        createByDefault=True, defaultValue=''))
        
        self.addParameter(QgsProcessingParameterRasterDestination(
        'ReconstructedGlacierSurface', '\nReconstructed Glacier Surface', 
        createByDefault=True, defaultValue=''))

    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Processes data and reconstructs the glacier by following these steps:
        - Check dependencies and preprocess inputs.
        - Determine which ice surface field to use.
        - Reconstruct the glacier surface via a series of processing steps.
        - Prepare and calculate glacier thickness.
        - Load the final layers into QGIS.
        """
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)
        glob_start_time = time.time()

        try:
            self._init_logger('3d_interpolation', feedback)

            # Check dependencies & preprocess inputs
            self.check_dependencies(feedback)
            inputs = self.preprocess_inputs(parameters, context, feedback)

            # Log basic initialization
            self.log_initialization(feedback,
                                    dem=inputs['dem'].name(),
                                    ice_pts=inputs['ice_pts'].name(),
                                    user_interval=inputs['user_interval'],
                                    basin_polygon=inputs['basin_polygon'].name())
            self._log_run_header({
                'DEM':                  f"{inputs['dem'].name()} ({inputs['dem'].source()})",
                'Ice Thickness Points':  inputs['ice_pts'].name(),
                'Resolution (map units)': inputs['user_interval'],
                'Study Area Polygon':    inputs['basin_polygon'].name(),
            'CRS':                   inputs['crs_string'],
        })
            self._log_layer_crs([
                ('DEM',                 inputs['dem']),
                ('Ice Thickness Points', inputs['ice_pts']),
                ('Study Area Polygon',  inputs['basin_polygon']),
            ])
            start_time = time.time()
            self.log_initialization(feedback, stage="data_prep")
            self.log_processing_duration("Data processed for calculation", start_time)
            self.log_initialization(feedback, stage="input_processed")

            # Glacier grid creation
            grid_outputs = self.create_grid(context, feedback, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Glacier raster surface reconstruction
            recon_outputs = self.reconstruct_surface(parameters, context, feedback, grid_outputs, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Modify reconstructed raster surface
            modified_recon_outputs = self.modify_reconstructed_surface(parameters, context, feedback, recon_outputs, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Calculate glacier thickness raster surface
            glacier_thickness_outputs = self.create_glacier_thickness_surface(parameters, context, feedback, modified_recon_outputs, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Recalculate glacier elevation surface
            glacier_elev_outputs = self.re_calculate_glacier_elevation_surface(parameters, context, feedback, glacier_thickness_outputs, inputs)

            # Load results into QGIS
            start_time = time.time()
            self.load_results(parameters, context, feedback, glacier_thickness_outputs, glacier_elev_outputs)
            self.log_processing_duration("Loaded data into QGIS project", start_time)
            self.log_final_results(feedback, inputs['crs_string'], glob_start_time)
            self._log_success(feedback)
            return {"Status": "Complete"}

        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )

    def check_dependencies(self, feedback):
        """
        Checks for required dependencies and logs each result.
        """
        feedback.pushInfo("Checking dependencies...\n")
        saga_installed, saga_msg = check_saga_installation()
        plugin_installed, plugin_msg = check_saga_plugin()
        saga_dir_set, saga_dir_msg = check_qgis_saga_directory()

        self._log("--- Dependency Check ---")
        self._log(f"  SAGA binary : {'OK' if saga_installed else 'FAIL'} | {saga_msg}")
        self._log(f"  SAGA plugin : {'OK' if plugin_installed else 'FAIL'} | {plugin_msg}")
        self._log(f"  SAGA dir    : {'OK' if saga_dir_set else 'FAIL'} | {saga_dir_msg}")

        if not (saga_installed and plugin_installed and saga_dir_set):
            errors = [m for ok, m in [
                (saga_installed, saga_msg),
                (plugin_installed, plugin_msg),
                (saga_dir_set, saga_dir_msg)
            ] if not ok]
            feedback.reportError("Dependency check failed:\n\n" + "\n\n".join(errors))
            raise QgsProcessingException("Dependency check failed.")

        self._log("  All dependencies OK")
        self._log("-" * 60)
        feedback.pushInfo("Dependencies check complete.\n")

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieves and validates input layers and parameters.
        Returns a dictionary with:
        - ice_pts: Ice flow thickness points
        - user_interval: Output resolution (fallback to DEM resolution if needed)
        - basin_polygon: Basin-defining polygon
        - extent: Extent (xmin, xmax, ymin, ymax) of the polygon
        - dem: Input DEM raster layer
        - crs, crs_string: CRS of the DEM
        """

        ice_pts = self.parameterAsVectorLayer(parameters, self.ice_flow_thickness, context)
        if ice_pts is None or not ice_pts.isValid():
            raise QgsProcessingException("Ice thickness points layer could not be retrieved or is not valid.")

        user_interval = self.parameterAsInt(parameters, self.user_interval, context)
        basin_polygon = self.parameterAsVectorLayer(parameters, self.input_polygon, context)

        if basin_polygon is None:
            raise QgsProcessingException("Basin polygon layer could not be retrieved from parameters.")

        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)
        if dem is None:
            raise QgsProcessingException("DEM layer could not be retrieved from parameters.")

        polygon_extent = basin_polygon.extent()
        extent = {
            "xmin": polygon_extent.xMinimum(),
            "xmax": polygon_extent.xMaximum(),
            "ymin": polygon_extent.yMinimum(),
            "ymax": polygon_extent.yMaximum()
        }

        crs = dem.crs()
        crs_string = crs.authid() if crs.isValid() else 'Unknown CRS'

        # Fallback to DEM resolution if needed
        pixel_size_x = dem.rasterUnitsPerPixelX()
        pixel_size_y = dem.rasterUnitsPerPixelY()
        dem_resolution = min(pixel_size_x, pixel_size_y)

        # If the user_interval is not provided (None or 0), use the DEM resolution,
        # A value of 25 is minimum value of output resolution.
        if user_interval is None or user_interval == 0:
            user_interval = dem_resolution
        user_interval = max(user_interval, 25)
        if not self.validate_dem_input(dem):
            raise QgsProcessingException(
                "The selected raster layer does not appear to be a valid DEM.\n\n"
                "Please ensure you select a raster layer that represents elevations (e.g., not a Hillshade).\n")

        # Validate that all inputs use a projected CRS and share the same CRS as the DEM
        self.validate_projected_crs(dem, feedback)
        self.validate_projected_crs(ice_pts, feedback)
        ice_pts = self.validate_layer_crs(ice_pts, crs, context, feedback)
        self.validate_projected_crs(basin_polygon, feedback)
        basin_polygon = self.validate_layer_crs(basin_polygon, crs, context, feedback)

        return {
            "ice_pts": ice_pts,
            "user_interval": user_interval,
            "basin_polygon": basin_polygon,
            "extent": extent,
            "dem": dem,
            "crs": crs,
            "crs_string": crs_string
        }    
   
    def create_grid(self, context, feedback, inputs):
        """
        Create a grid for glacier surface reconstruction and smooth the ice surface values.

        This function:
        - Creates a regular grid of points within the basin polygon.
        - Joins the grid points to existing ice thickness points using a nearest-neighbor join.
        - Retrieves the joined grid layer and determines the appropriate ice surface field.
        - Computes smoothed ice surface values using a K-nearest neighbor approach via a helper function.
        - Creates a new attribute field to store the smoothed values.
        - Returns a dictionary of outputs including the joined and smoothed grid layer details.

        Parameters:
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for logging progress and checking cancelation.
            inputs (dict): Dictionary of input values including:
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The polygon defining the basin.
                - 'user_interval': The spacing between grid points.
                - 'ice_pts': The layer with ice thickness points.

        Returns:
            dict: Dictionary containing output layers and fields, including:
                - 'IceThicknessJoinSmoothed': A dictionary with:
                    - 'OUTPUT': The ID of the joined and smoothed grid layer.
                    - 'FIELD': The name of the new field storing the smoothed ice surface values.

        Raises:
            QgsProcessingException: If processing is canceled or if the required ice surface field is missing.
        """

        start_time = time.time()
        self.log_initialization(feedback, stage="create_grid")

        outputs = {}

        # Create a regular grid of points within the basin polygon.
        alg_params = {
            'CRS': inputs['crs'],
            'EXTENT': inputs['basin_polygon'],
            'INSET': 0,
            'IS_SPACING': True,
            'RANDOMIZE': False,
            'SPACING': inputs['user_interval'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['CreateRegularGridOfPoints'] = self._run_algorithm(
            'qgis:regularpoints', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Create regular grid of points'
        )
        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            feedback.pushInfo("Processing cancelled.")
            return {}

        # Join by nearest points.
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELDS_TO_COPY': [''],
            'INPUT': outputs['CreateRegularGridOfPoints']['OUTPUT'],
            'INPUT_2': inputs['ice_pts'],
            'MAX_DISTANCE': None,
            'NEIGHBORS': 1,
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['IceThicknessJoin'] = self._run_algorithm(
            'native:joinbynearest', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Join grid to ice thickness points'
        )
        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Retrieve the joined grid layer.
        joined_layer = QgsProcessingUtils.mapLayerFromString(
            outputs['IceThicknessJoin']['OUTPUT'], context
        )
        if not joined_layer or not joined_layer.isValid():
            raise QgsProcessingException(
                "Could not retrieve the joined grid layer after spatial join. "
                "Check that the ice thickness points overlap the basin polygon extent."
            )

        # Determine the appropriate ice surface field.
        # ff_ice_surface must be checked first: the shape-factor output layer
        # contains both ff_ice_surface and ice_surface, and we must use the
        # shape-factor corrected values when the user has chosen those points.
        field_names = [f.name() for f in joined_layer.fields()]
        if "ff_ice_surface" in field_names or "ff_ice_sur" in field_names:
            full_field = "ff_ice_surface" if "ff_ice_surface" in field_names else "ff_ice_sur"
        elif "ice_surface" in field_names or "ice_surfac" in field_names:
            full_field = "ice_surface" if "ice_surface" in field_names else "ice_surfac"
        else:
            feedback.reportError("Ice surface field not found in computed grid layer.")
            raise QgsProcessingException("Missing required ice surface data.")

        self._log(f"Field detected: '{full_field}' ({'shape-factor corrected' if full_field in ('ff_ice_surface', 'ff_ice_sur') else 'standard ice flow thickness'})")

        # Compute the smoothed values using the helper smoothing function.
        smoothed_values = self.smooth_ice_surface_values(joined_layer, full_field, feedback)
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Create a new field to store the smoothed values (keeping the original field intact).
        joined_layer.startEditing()
        field_names = [f.name() for f in joined_layer.fields()]
        if "ice_srf_sm" not in field_names:
            joined_layer.addAttribute(QgsField("ice_srf_sm", _FIELD_DOUBLE))

        # Assign the smoothed values to the new field.
        field_idx = joined_layer.fields().indexOf("ice_srf_sm")
        for feat_id, val in smoothed_values.items():
            joined_layer.changeAttributeValue(feat_id, field_idx, val)
        joined_layer.commitChanges()

        # Store the new smoothed layer output with the new field name.
        outputs['IceThicknessJoinSmoothed'] = {
            'OUTPUT': joined_layer.id(),
            'FIELD': "ice_srf_sm"
        }

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        return outputs

    def smooth_ice_surface_values(self, joined_layer, full_field, feedback):
        """
        Compute smoothed values for the joined layer using a 5x5 sliding window mean.

        Exploits the regular grid structure (input always from qgis:regularpoints)

        Parameters:
            joined_layer (QgsVectorLayer): The layer containing features to smooth.
            full_field (str): The name of the field containing the original ice surface values.
            feedback (QgsProcessingFeedback): Object for reporting progress and checking for cancelation.

        Returns:
            dict: A dictionary mapping feature IDs (int) to the computed smoothed value (float).

        Raises:
            QgsProcessingException: If processing is canceled.
        """
        from numpy.lib.stride_tricks import sliding_window_view

        start_time = time.time()
        self.log_initialization(feedback, stage="optimize_grid")

        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Load all features once and extract coords/values as numpy arrays.
        features = list(joined_layer.getFeatures())
        feat_ids = []
        xs = []
        ys = []
        vals = []
        for feat in features:
            geom = feat.geometry()
            if not geom:
                continue
            pt = geom.asPoint()
            feat_ids.append(feat.id())
            xs.append(pt.x())
            ys.append(pt.y())
            v = feat[full_field]
            vals.append(float(v) if v is not None else np.nan)

        feat_ids = np.array(feat_ids)
        xs = np.array(xs)
        ys = np.array(ys)
        vals = np.array(vals, dtype=float)

        # Infer grid dimensions from unique x/y coordinates.
        unique_x = np.sort(np.unique(np.round(xs, 6)))
        unique_y = np.sort(np.unique(np.round(ys, 6)))
        ncols = len(unique_x)
        nrows = len(unique_y)

        # Map each point to its (row, col) index in the 2D grid.
        cols = np.searchsorted(unique_x, np.round(xs, 6))
        rows = np.searchsorted(unique_y, np.round(ys, 6))

        # Build the 2D grid; NaN where no point exists.
        grid = np.full((nrows, ncols), np.nan)
        grid[rows, cols] = vals

        # Pad with NaN so edge points average only over valid neighbours.
        padded = np.pad(grid, 2, mode='constant', constant_values=np.nan)

        # Apply 5×5 sliding window nanmean — one vectorised operation.
        windows = sliding_window_view(padded, (5, 5))   # (nrows, ncols, 5, 5)
        smoothed_grid = np.nanmean(windows, axis=(-2, -1))

        # Read smoothed values back; fall back to original where result is NaN.
        smoothed_vals = smoothed_grid[rows, cols]
        fallback = np.isnan(smoothed_vals)
        smoothed_vals[fallback] = vals[fallback]

        return {int(fid): float(sv) for fid, sv in zip(feat_ids, smoothed_vals)}

    
    def reconstruct_surface(self, parameters, context, feedback, outputs, inputs):
        """
        Reconstruct the glacier surface using a thin plate spline TIN method.

        This function:
        - Creates an Ice Elevation TIN based on the smoothed ice thickness grid.
        - Uses the provided grid spacing, extent, and basin polygon to generate the TIN.
        - Returns the TIN output for further processing.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing outputs from previous steps.
            inputs (dict): Dictionary of inputs including:
                - 'user_interval': The grid spacing.
                - 'extent': A dictionary with keys 'xmin', 'xmax', 'ymin', 'ymax'.
                - 'basin_polygon': The polygon defining the basin.

        Returns:
            dict: Dictionary of outputs including the key 'IceElevationTin' with the TIN result.

        Raises:
            QgsProcessingException: If processing is canceled.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="reconstruct_surface")

        # Create Ice Elevation TIN via thin plate spline.
        alg_params = {
            'FIELD': outputs['IceThicknessJoinSmoothed']['FIELD'],
            'FRAME': False,
            'LEVEL': 0,
            'REGULARISATION': 1.0,
            'SHAPES':  outputs['IceThicknessJoinSmoothed']['OUTPUT'],
            'TARGET_USER_SIZE': inputs['user_interval'],
            'TARGET_USER_XMIN': inputs['extent']['xmin'],
            'TARGET_USER_XMAX': inputs['extent']['xmax'],
            'TARGET_USER_YMIN': inputs['extent']['ymin'],
            'TARGET_USER_YMAX': inputs['extent']['ymax'],
            'TARGET_OUT_GRID': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['IceElevationTin'] = self._run_algorithm(
            'sagang:thinplatesplinetin', alg_params, context, feedback,
            output_key='TARGET_OUT_GRID', step_name='Reconstruct ice elevation TIN'
        )
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        return outputs

    def modify_reconstructed_surface(self, paramters, context, feedback, outputs, inputs):
        """
        Modify the reconstructed glacier surface to match the DEM.

        This function:
        - Clips the reconstructed TIN to the basin polygon.
        - Clips and finalizes the DEM to the basin polygon.
        - Resamples the clipped DEM.
        - Re-clips the TIN based on the resampled DEM extent and finalizes the result.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing outputs from previous processing steps.
            inputs (dict): Dictionary of inputs including:
                - 'dem': The digital elevation model.
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The basin polygon used for clipping.

        Returns:
            dict: Dictionary of outputs including clipped and resampled DEM and TIN layers.

        Raises:
            QgsProcessingException: If processing is canceled.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="modify_reconstructed_surface")

        # Clip the TIN to the basin polygon.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['IceElevationTin']['TARGET_OUT_GRID'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': inputs['basin_polygon'],
            'OUTPUT': QgsProcessingUtils.generateTempFilename('tin_clipped.tif')
        }
        outputs['Tin_clipped'] = self._run_algorithm(
            'gdal:cliprasterbyextent', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip TIN to basin polygon'
        )
        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Clip the DEM to the basin polygon.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': inputs['dem'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': inputs['basin_polygon'],
            'OUTPUT': QgsProcessingUtils.generateTempFilename('clipped_dem.tif')
        }
        outputs['ClippedDEM'] = self._run_algorithm(
            'gdal:cliprasterbyextent', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip DEM to basin polygon'
        )
        
        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Finalize the clipped DEM.
        alg_params = {
            'INPUT': outputs['ClippedDEM']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessingUtils.generateTempFilename('finalized_clipped_dem.tif')
        }
        outputs['FinalizedClippedDEM'] = self._run_algorithm(
            'gdal:translate', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Finalize clipped DEM'
        )
        
        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Resample the DEM.
        alg_params = {
            'INPUT': outputs['FinalizedClippedDEM']['OUTPUT'],
            'TARGET_CRS': inputs['crs'],
            'TARGET_RESOLUTION': inputs['user_interval'],
            'RESAMPLING': 1,
            'OUTPUT': QgsProcessingUtils.generateTempFilename('resampled_dem.tif')
        }
        outputs['ResampledDEM'] = self._run_algorithm(
            'gdal:warpreproject', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Resample DEM to output resolution'
        )
        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Finalize the resampled DEM.
        alg_params = {
            'INPUT': outputs['ResampledDEM']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessingUtils.generateTempFilename('finalized_resampled_dem.tif')
        }
        outputs['FinalizedResampledDEM'] = self._run_algorithm(
            'gdal:translate', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Finalize resampled DEM'
        )
        
        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Re-clip the TIN to the extent of the resampled DEM to ensure precise dimensions.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['Tin_clipped']['OUTPUT'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': outputs['ResampledDEM']['OUTPUT'],
            'OUTPUT': QgsProcessingUtils.generateTempFilename('tin_reclipped.tif')
        }
        outputs['Tin_re-clipped'] = self._run_algorithm(
            'gdal:cliprasterbyextent', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Re-clip TIN to resampled DEM extent'
        )
        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Finalize the re-clipped TIN.
        alg_params = {
            'INPUT': outputs['Tin_re-clipped']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessingUtils.generateTempFilename('finalized_tin_reclipped.tif')
        }
        outputs['FinalizedTin_re-clipped'] = self._run_algorithm(
            'gdal:translate', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Finalize re-clipped TIN'
        )
        
        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
    
        return outputs

    @staticmethod
    def _shift_zero(array, shift, axis):
        """Shift ``array`` along ``axis`` by ``shift`` cells, zero-filled (no wrap)."""
        if shift == 0:
            return array
        out = np.zeros_like(array)
        src = [slice(None)] * array.ndim
        dst = [slice(None)] * array.ndim
        n = array.shape[axis]
        if shift > 0:
            src[axis] = slice(0, n - shift)
            dst[axis] = slice(shift, None)
        else:
            src[axis] = slice(-shift, None)
            dst[axis] = slice(0, n + shift)
        out[tuple(dst)] = array[tuple(src)]
        return out

    def _gaussian_blur_nan(self, array, sigma_px):
        """NaN-aware separable Gaussian blur (sigma in pixels), numpy-only.

        Normalised convolution: the masked data and the mask are blurred separately
        and divided, so nodata neither contributes to nor bleeds into valid cells.
        The input footprint is preserved -- smoothed values are kept only where the
        input was valid -- so the filter never creates data where there was none,
        which would otherwise grow the glacier past its margin. Matches the previous
        SAGA Gaussian to well under a metre; kept numpy-only to avoid a per-call SAGA
        process. The paper method (a fixed-radius uniform Gaussian) is unchanged --
        only the Gaussian's implementation, which the manuscript does not specify.
        """
        if sigma_px <= 0:
            return array.astype(np.float32)
        radius = max(1, int(np.ceil(3.0 * sigma_px)))
        offsets = np.arange(-radius, radius + 1, dtype=np.float64)
        kernel = np.exp(-(offsets ** 2) / (2.0 * sigma_px * sigma_px))
        kernel /= kernel.sum()
        mask = np.isfinite(array).astype(np.float64)
        data = np.where(mask > 0, np.asarray(array, dtype=np.float64), 0.0)

        def conv_axis(plane, axis):
            out = np.zeros_like(plane)
            for index, weight in enumerate(kernel):
                out += weight * self._shift_zero(plane, index - radius, axis)
            return out

        num = conv_axis(conv_axis(data, 0), 1)
        den = conv_axis(conv_axis(mask, 0), 1)
        with np.errstate(invalid='ignore', divide='ignore'):
            result = np.where(den > 1e-6, num / den, np.nan)
        # Preserve the input footprint: normalised convolution would otherwise fill
        # nodata cells within one kernel radius of valid data and grow the glacier
        # beyond its margin. Keep smoothed values only where the input was valid.
        result[mask <= 0] = np.nan
        return result.astype(np.float32)

    def _resolve_smoothing(self, parameters, context, inputs, product, feedback):
        """
        Resolve the automatic Gaussian smoothing configuration for an output product.

        Returns (apply, kr_px, sigma_percent). When smoothing is on, the kernel radius
        follows the automatic resolution-aware rule: min(500 m, 10% of glacier linear
        dimension), floored at 5 DEM cells (the empirically calibrated behaviour). The
        Gaussian standard deviation is one third of the kernel radius, so the finite
        kernel contains approximately +/-3 sigma, supplied as SIGMA = 33.33 percent of
        the kernel radius. There is no user radius override: the manuscript method uses
        this automatic radius, so the smoothing checkbox is the only public control.

        Called once (only the final surface is smoothed). The user sees a one-line
        "Gaussian Smoothing: On/Off"; the full radius/sigma detail goes to the run log
        for anyone who wants to check it.
        """
        apply = self.parameterAsBoolean(parameters, self.apply_smoothing, context)
        if not apply:
            # Full detail to the run log; a clean one-liner to the user.
            self._log(f"Gaussian smoothing ({product}): OFF - unsmoothed output requested")
            feedback.pushInfo("Gaussian Smoothing: Off\n")
            return False, 0, 0

        area_m2 = sum(f.geometry().area() for f in inputs['basin_polygon'].getFeatures())
        # side length of an equal-area square: resolution-independent size proxy
        glacier_dimension_m = area_m2 ** 0.5
        cell = inputs['user_interval']

        # Automatic, resolution-aware kernel radius.
        KR_METRES      = 500   # ceiling: 50 px x 10 m (calibration resolution)
        CAP_FRACTION   = 0.1   # kr <= 10% of glacier linear dimension
        KR_FLOOR_CELLS = 5     # kr >= 5x cell size (Nyquist)
        kr_m = min(KR_METRES, glacier_dimension_m * CAP_FRACTION)
        kr_m = max(KR_FLOOR_CELLS * cell, kr_m)

        kr_px = max(3, int(kr_m / cell))
        sigma_percent = 100.0 / 3.0
        # Full detail to the run log; a clean one-liner to the user.
        sigma_m = (kr_px * cell) / 3.0
        self._log(f"Gaussian smoothing ({product}): ON, radius {kr_m:.0f} m (automatic; "
                  f"{kr_px} px, sigma {sigma_m:.1f} m / {sigma_percent:.2f}% of radius; "
                  f"glacier dimension {glacier_dimension_m:.0f} m)")
        feedback.pushInfo("Gaussian Smoothing: On\n")
        return True, kr_px, sigma_percent

    def create_glacier_thickness_surface(self, parameters, context, feedback, outputs, inputs):
        """
        Create the reconstructed ice thickness by calculating the difference between the
        reconstructed TIN surface and the DEM, then clipping.

        This function:
        - Computes the difference (TIN minus DEM) using a raster calculator.
        - Replaces non-positive values with NaN. This raw thickness is the published
          thickness raster; it is not smoothed (per the manuscript, only the final
          surface is Gaussian-smoothed, in re_calculate_glacier_elevation_surface).
        - Clips the smoothed raster to the basin polygon.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing outputs from previous steps.
            inputs (dict): Dictionary of inputs that includes:
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The basin polygon (QgsVectorLayer), used to derive
                  the glacier linear dimension for kernel scaling.
                - 'user_interval': The grid spacing in map units (metres), used to
                  convert the kernel radius from metres to pixels.
                - 'dem': The digital elevation model.

        Returns:
            dict: Dictionary of outputs including the key 'ice_thick_smooth_clipped',
                which represents the final smoothed and clipped glacier thickness surface.

        Raises:
            QgsProcessingException: If processing is canceled.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="calculate_glacier_thickness")

        # Calculate the difference (TIN - DEM) to derive ice thickness.
        outputs['TinMinusDem'] = self._raster_calc(
            [outputs['FinalizedTin_re-clipped']['OUTPUT'],
             outputs['FinalizedResampledDEM']['OUTPUT']],
            lambda a, b: a - b,
            'tin_minus_dem.tif',
            step_name='Calculate ice thickness (TIN minus DEM)'
        )
        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Remove non-positive values.
        outputs['RemoveNegValues'] = self._raster_calc(
            [outputs['TinMinusDem']['OUTPUT']],
            lambda a: np.where(a <= 0, np.nan, a),
            'remove_neg_values.tif',
            step_name='Remove non-positive ice thickness values'
        )
        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # The reconstructed ice thickness is the raw TIN-minus-DEM difference (per the
        # manuscript); it is not smoothed here. Only the final surface is Gaussian-
        # smoothed, in re_calculate_glacier_elevation_surface().
        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Clip the reconstructed thickness to the basin polygon.
        alg_params = {
            'ALPHA_BAND': False,
            'CROP_TO_CUTLINE': True,
            'DATA_TYPE': 0,  # Use Input Layer Data Type
            'EXTRA': '',
            'INPUT': outputs['RemoveNegValues']['OUTPUT'],
            'KEEP_RESOLUTION': True,
            'MASK': inputs['basin_polygon'],
            'SOURCE_CRS': inputs['crs'],
            'OUTPUT': self.parameterAsOutputLayer(parameters, 'ReconstructedGlacierThickness', context)
        }
        outputs['ice_thick_smooth_clipped'] = self._run_algorithm(
            'gdal:cliprasterbymasklayer', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip ice thickness to basin polygon'
        )
        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        return outputs
        
    def re_calculate_glacier_elevation_surface(self, parameters, context, feedback, outputs, inputs):
        """
        Re-calculate the glacier elevation surface by adding the ice thickness to the DEM,
        followed by Gaussian filtering and clipping.

        This function:
        - Adds the ice thickness to the DEM to form the provisional glacier surface.
        - Applies a resolution-aware Gaussian filter to smooth the resulting surface,
          removing residual DEM terrain roughness inherited when ice thickness is added
          to the DEM. The kernel radius is computed in metres using the same formula as
          the first smoothing pass in create_glacier_thickness_surface.
        - Clips the smoothed surface to the basin polygon.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing prior processing outputs such as:
                - 'RemoveNegValues'
                - 'ResampledDEM'
                - 'surface_smooth'
            inputs (dict): Dictionary of inputs including:
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The polygon for clipping (QgsVectorLayer), used to
                  derive the glacier linear dimension for kernel scaling.
                - 'user_interval': The grid spacing in map units (metres).
                - 'dem': The original digital elevation model.

        Returns:
            dict: Dictionary of outputs including the key 'ice_surface_smooth_clipped',
                representing the final glacier elevation surface.

        Raises:
            QgsProcessingException: If processing is canceled.
        """

        start_time = time.time()
        self.log_initialization(feedback, stage="calculate_glacier_elevation_surface")
        
        # Form the provisional glacier surface as ice thickness + DEM. The Gaussian
        # pass below smooths this combined surface.
        outputs['ice_thickness_plus_dem'] = self._raster_calc(
            [outputs['RemoveNegValues']['OUTPUT'],
             outputs['ResampledDEM']['OUTPUT']],
            lambda a, b: a + b,
            'ice_thickness_plus_dem.tif',
            step_name='Calculate glacier surface (ice thickness + DEM)'
        )
        self.log_processing_duration("Calculated glacier surface", start_time)
        
        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Gaussian smoothing of the surface raster (optional; see the ApplySmoothing
        # checkbox; kernel logic in _resolve_smoothing()). This second pass removes
        # residual DEM terrain roughness that is inherited when the smoothed ice
        # thickness is added to the DEM.
        apply_smoothing, kr_px, sigma_percent = self._resolve_smoothing(
            parameters, context, inputs, 'glacier surface', feedback)

        if apply_smoothing:
            # sigma in pixels from the resolved kernel (see create_glacier_thickness_surface).
            _sigma_px = kr_px * sigma_percent / 100.0
            outputs['surface_smooth'] = {
                'RESULT': self._raster_calc(
                    [outputs['ice_thickness_plus_dem']['OUTPUT']],
                    lambda a: self._gaussian_blur_nan(a, _sigma_px),
                    'surface_smooth.tif',
                    step_name='Smooth glacier surface (Gaussian filter)'
                )['OUTPUT']
            }
        else:
            # Smoothing disabled: pass the unsmoothed surface (thickness + DEM) through.
            outputs['surface_smooth'] = {'RESULT': outputs['ice_thickness_plus_dem']['OUTPUT']}

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Clip the glacier surface to the basin polygon. Both branches above return a
        # GeoTIFF with CRS and nodata already set, so it is clipped directly.
        alg_params = {
            'ALPHA_BAND': False,
            'CROP_TO_CUTLINE': True,
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['surface_smooth']['RESULT'],
            'KEEP_RESOLUTION': True,
            'MASK': inputs['basin_polygon'],
            'SOURCE_CRS': inputs['crs'],
            'OUTPUT': self.parameterAsOutputLayer(parameters, 'ReconstructedGlacierSurface', context)
        }
        outputs['ice_surface_smooth_clipped'] = self._run_algorithm(
            'gdal:cliprasterbymasklayer', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip glacier surface to basin polygon'
        )
        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        return outputs

    def load_results(self, parameters, context, feedback, ice_thick_outputs, ice_elev_outputs):
        """
        Loads the final raster layers into the QGIS project.
        Returns a dictionary of output layers whose keys match the declared
        output parameters.
        """
        results = {}
        results['ReconstructedGlacierThickness'] = ice_thick_outputs.get('ice_thick_smooth_clipped', {}).get('OUTPUT', None)
        results['ReconstructedGlacierSurface'] = ice_elev_outputs.get('ice_surface_smooth_clipped', {}).get('OUTPUT', None)
        
        for key, layer_name in [
            ('ReconstructedGlacierSurface', "Reconstructed Glacier Surface"),
            ('ReconstructedGlacierThickness', "Reconstructed Glacier Thickness")
        ]:
            if results[key]:
                feedback.pushInfo(f"Adding {layer_name} to QGIS project...")
                details = context.layerToLoadOnCompletionDetails(results[key])
                # Ensure that the project is valid:
                if details.project is None:
                    details.project = QgsProject.instance()
                details.name = layer_name
                # Tell QGIS which declared output parameter this layer belongs to
                # so it knows the type is raster and skips the OGR probe.
                details.outputName = key
                feedback.pushInfo(f"Added {layer_name} to project.\n")
        return {"Status": "Complete"}

    def validate_dem_input(self, input_raster):
        """
        Validate whether the input raster layer represents a Digital Elevation Model (DEM) 
        and not a hillshade, based on filename and statistical checks.

        Parameters:
            input_raster (QgsRasterLayer): The input raster layer.

        Returns:
            bool: True if the layer is a valid DEM, False otherwise.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            return False

        # Check filename for hillshade keywords (name is already lowercased)
        hillshade_keywords = ["hillshade", "shaded_relief"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            return False

        # Get raster statistics
        provider = input_raster.dataProvider()
        # No explicit stats argument: any explicit value (even the flags type)
        # binds to the int overload of bandStatistics(), deprecated in QGIS 3.40.
        # The default is All anyway.
        stats = provider.bandStatistics(1)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            return False

        # If all checks pass, assume it's a valid DEM
        return True
    
    def log_initialization(self, feedback, dem=None, ice_pts=None, 
                           user_interval=None, basin_polygon=None, stage=None):
        """
        Log initialization and progress updates to the QGIS feedback console.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for logging messages.
            dem_filename (str): Name of the DEM file being processed.
            ice_thick_name (str): Name of the ice thickness points file.
            distance (float): Resolution in map units.
            flowline_name (str): Name of the flowline file.
            transects_name (str): Name of the transects file.
            shear (float): Shear stress value used in calculations.
            stage (str): Current stage of the workflow (optional).
            valid_percentage (float): Percentage of valid points during validation (optional).
            invalid_points (list): List of invalid points during validation (optional).

        Returns:
            None
        """

        if stage is None:
            # Log initialization details
            feedback.setProgress(0)
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initialising Glacier Surface Interpolation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - DEM: {dem}")
            feedback.pushInfo(f"  - Ice Thickness Points: {ice_pts}")
            feedback.pushInfo(f"  - Resolution (map units): {user_interval}")
            feedback.pushInfo(f"  - Study Area Polygon: {basin_polygon}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText('Pre-processing input data...\n')
        elif stage == "input_processed":
            pass
        elif stage == "create_grid":
            feedback.setProgressText("Creating grid...\n")
        elif stage == "optimize_grid":
            feedback.setProgressText("Optimising grid...\n")
        elif stage == "reconstruct_surface":
            feedback.setProgressText("Reconstructing glacier surface...\n")
        elif stage == "modify_reconstructed_surface":
            feedback.setProgressText("Calculating glacier ice thickness...\n")
        elif stage == "calculate_glacier_thickness":
            feedback.setProgressText("Finalising results...\n")
        elif stage == "calculate_glacier_elevation_surface":
            pass
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def _raster_calc(self, input_paths, func, out_name, step_name=''):
        """
        Perform simple raster arithmetic on one or two aligned rasters using
        GDAL and numpy directly, without spawning a child processing algorithm.

        This avoids QGIS's child-algorithm temp-file lifecycle, which on Windows
        deletes intermediate outputs between consecutive child algorithm calls.

        If input rasters differ in size by a pixel or two (due to SAGA and GDAL
        producing grids with the same resolution but different pixel origins),
        secondary rasters are resampled to the reference dimensions at read time
        using GDAL's buf_xsize/buf_ysize.

        Parameters:
            input_paths (list of str): Ordered list of file paths to input rasters
                (one per operand: A, B, ...). The first path is used as the spatial
                reference for the output.
            func (callable): A function accepting one or two numpy float32 arrays
                and returning a float32 result. Nodata pixels are pre-masked to
                np.nan before the call.
            out_name (str): Base filename for the temporary output raster.
            step_name (str, optional): Human-readable label for log messages.

        Returns:
            dict: {'OUTPUT': out_path}

        Raises:
            QgsProcessingException: If any input raster cannot be opened or the
                GDAL write fails.
        """
        label = step_name or out_name
        self._log(f"START  | {label} | raster_calc (numpy/GDAL)")
        t0 = time.time()

        try:
            datasets = []
            for p in input_paths:
                ds = gdal.Open(p)
                if ds is None:
                    raise QgsProcessingException(
                        f"Could not open input raster for step '{label}': {p}"
                    )
                datasets.append(ds)

            ref = datasets[0]
            ref_gt = ref.GetGeoTransform()
            ref_proj = ref.GetProjection()
            ref_xsize = ref.RasterXSize
            ref_ysize = ref.RasterYSize

            # Compute reference extent from geotransform.
            ref_xmin = ref_gt[0]
            ref_ymax = ref_gt[3]
            ref_xmax = ref_xmin + ref_xsize * ref_gt[1]
            ref_ymin = ref_ymax + ref_ysize * ref_gt[5]

            arrays = []
            warped_datasets = []  # keep in-memory datasets alive until arrays are read
            for ds in datasets:
                if ds.RasterXSize != ref_xsize or ds.RasterYSize != ref_ysize:
                    self._log(
                        f"WARN   | {label} | raster grid mismatch "
                        f"({ds.RasterXSize}x{ds.RasterYSize} vs {ref_xsize}x{ref_ysize})"
                        f" — warping to reference grid"
                    )
                    warped = gdal.Warp(
                        '', ds, format='MEM',
                        outputBounds=(ref_xmin, ref_ymin, ref_xmax, ref_ymax),
                        width=ref_xsize, height=ref_ysize,
                        resampleAlg=gdal.GRA_Bilinear
                    )
                    warped_datasets.append(warped)
                    src = warped
                else:
                    src = ds
                band = src.GetRasterBand(1)
                arr = band.ReadAsArray().astype(np.float32)
                nd = band.GetNoDataValue()
                if nd is not None and not np.isnan(nd):
                    arr[arr == nd] = np.nan
                arrays.append(arr)
            warped_datasets = None

            result = func(*arrays).astype(np.float32)

            out_path = QgsProcessingUtils.generateTempFilename(out_name)
            driver = gdal.GetDriverByName('GTiff')
            out_ds = driver.Create(
                out_path, ref_xsize, ref_ysize, 1, gdal.GDT_Float32
            )
            out_ds.SetGeoTransform(ref.GetGeoTransform())
            out_ds.SetProjection(ref.GetProjection())
            out_band = out_ds.GetRasterBand(1)
            NODATA = -9999.0
            result = np.where(np.isnan(result), NODATA, result)
            out_band.SetNoDataValue(NODATA)
            out_band.WriteArray(result)
            out_ds.FlushCache()
            out_ds = None
            datasets = None

        except QgsProcessingException:
            raise
        except Exception:
            tb = traceback.format_exc()
            self._log(
                f"FAILED | {label} | raster_calc | {time.time() - t0:.1f}s\n{tb}",
                level='error'
            )
            raise QgsProcessingException(
                "An error occurred. See log file."
                + (f"\n{self._log_path}" if self._log_path else "")
            )

        self._log(f"OK     | {label} | {time.time() - t0:.1f}s")
        return {'OUTPUT': out_path}

    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message to the user after processing.

        Parameters:
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Feedback object to report progress.

        Returns:
            dict: Status of the post-processing.
        """
        
        # Display completion message using a custom dialog
        QCoreApplication.processEvents()
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("Glacier Surface Interpolation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)
