"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 3D Interpolation
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, sys, time, platform, traceback
import numpy as np
from osgeo import ogr, gdal
ogr.UseExceptions()
from .qglare_base import QGlaReAlgorithmMixin
import processing
from qgis.PyQt.QtCore import QCoreApplication, QSettings, QVariant, QMetaType, QUrl
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import (Qgis,
                       QgsProject,
                       QgsField,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsRasterLayer,
                       QgsSpatialIndex,
                       QgsProcessingUtils,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterBoolean,
                       QgsProcessingParameterDefinition,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingParameterRasterDestination,
                       )

# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38
# QMetaType.Type is the replacement
_FIELD_DOUBLE = QMetaType.Type.Double if Qgis.QGIS_VERSION_INT >= 33800 else QVariant.Double


# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_RASTER = Qgis.ProcessingSourceType.Raster
    _SOURCE_VECTOR_POINT = Qgis.ProcessingSourceType.VectorPoint
    _SOURCE_VECTOR_POLYGON = Qgis.ProcessingSourceType.VectorPolygon
except AttributeError:                          # QGIS < 3.36
    _SOURCE_RASTER = QgsProcessing.TypeRaster
    _SOURCE_VECTOR_POINT = QgsProcessing.TypeVectorPoint
    _SOURCE_VECTOR_POLYGON = QgsProcessing.TypeVectorPolygon



def get_qgis_saga_directory():
    """Return the configured QGIS Processing SAGA directory, or an empty string."""
    saga_dir = QSettings().value('Processing/Configuration/SAGA_FOLDER', '').strip()
    return os.path.normpath(saga_dir) if saga_dir else ""

def check_qgis_saga_directory():
    """Check the QGIS Processing SAGA directory is set and valid; returns (ok, message)."""
    saga_dir = get_qgis_saga_directory()

    if saga_dir and os.path.isdir(saga_dir):
        return True, f"SAGA directory is set: {saga_dir}"
    
    return (
        False,
        "SAGA directory is not set or is invalid in QGIS Processing options.\n"
        "Please set it via: Settings > Options > Processing > Providers > SAGA."
    )

def check_saga_installation():
    """Check that a SAGA binary exists in the configured directory; returns (ok, message)."""
    binary_names = ["saga_cmd.exe", "saga_cmd"] if platform.system() == "Windows" else ["saga_cmd"]
    saga_dir = get_qgis_saga_directory()

    if saga_dir and os.path.isdir(saga_dir):
        for binary in binary_names:
            binary_path = os.path.join(saga_dir, binary)
            if os.path.isfile(binary_path):
                return True, f"SAGA binary found: {binary_path}"
        return (
            False,
            f"SAGA directory is set to '{saga_dir}', but no SAGA binary was found there.\n"
            "Please check your installation or reinstall SAGA."
        )

    return (
        False,
        "SAGA is not installed or configured properly.\n"
        "Ensure SAGA is installed and the directory is set in QGIS:\n"
        "Settings > Options > Processing > Providers > SAGA."
    )

def check_saga_plugin():
    """Check that the SAGA processing plugin is installed; returns (ok, message)."""
    try:
        from qgis.utils import plugins
    except Exception:
        return False, "Error accessing QGIS plugins."

    plugin_names = ["processing_saga_nextgen", "processing_sagang_nextgen"]
    for name in plugin_names:
        if name in plugins:
            return True, f"SAGA plugin '{name}' is installed."
    
    return (
        False,
        "SAGA plugin is not installed.\n"
        "Please install it via: Plugins > Manage and Install Plugins."
    )

def check_dependencies(feedback=None):
    """Run the SAGA install, plugin, and directory checks; returns True when all pass.

    Reports any failures through feedback when given, otherwise prints them.
    """
    saga_installed, saga_msg = check_saga_installation()
    plugin_installed, plugin_msg = check_saga_plugin()
    saga_dir_set, saga_dir_msg = check_qgis_saga_directory()

    error_messages = []
    
    # Print success messages only
    if saga_installed:
        print(saga_msg)
    else:
        error_messages.append(saga_msg)

    if plugin_installed:
        print(plugin_msg)
    else:
        error_messages.append(plugin_msg)

    if not saga_dir_set:
        error_messages.append(saga_dir_msg)

    # Show error messages if any issues exist
    if error_messages:
        full_error_message = "Dependency check failed:\n\n" + "\n\n".join(error_messages)
        if feedback:
            feedback.reportError(full_error_message)
        else:
            print(full_error_message)

    return saga_installed and plugin_installed and saga_dir_set

class Interpolation(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """Reconstruct the glacier surface and ice thickness by interpolation.

    Fits a thin plate spline (SAGA) to the ice-surface points over the basin
    (Pellitero et al. 2015, 2016), derives thickness against the DEM, applies an
    automatic Gaussian smoothing, and clips both rasters to the basin.

    References:
        Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Hughes, P., Ivy-Ochs,
            S., Lukas, S., Ribolini, A., 2015. A GIS tool for automatic
            calculation of glacier equilibrium-line altitudes. Computers &
            Geosciences 82, 55–62.
        Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Ivy-Ochs, S., Frew,
            C.R., Hughes, P., Ribolini, A., Lukas, S., Renssen, H., 2016. GlaRe, a
            GIS tool to reconstruct the 3D surface of palaeoglaciers. Computers &
            Geosciences 94, 77–85.
        SAGA GIS, Thin Plate Spline (TPS) method. https://saga-gis.sourceforge.io
    """

    N_STEPS = 19
    _log_tag = 'Glacier Reconstruction Processing Log'

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    input_polygon = 'input_polygon'
    ice_flow_thickness = 'ice_flow_thickness'
    apply_smoothing = 'ApplySmoothing'

    def name(self):
        """Internal algorithm id used by QGIS."""

        return '3D Interpolation'

    def displayName(self):
        """User-facing algorithm name shown in the toolbox."""

        return '4. 3D Interpolation'

    def group(self):
        """Toolbox group this algorithm belongs to."""

        return '\u200aQ-GlaRe'

    def groupId(self):
        """Internal id of the toolbox group."""

        return '1_q-glare'
        
    def tr(self, text):
        """Translate a UI string through Qt's localisation."""

        return QCoreApplication.translate("Interpolation", text)
    
    def setProgressText(self, text):
        """Print progress text to the console."""

        print(text)
     
    def shortHelpString(self):
        """Return the HTML help text shown in the tool dialog."""

        # Add the tool icon to the top of the help text (rendered as HTML).
        icon_url = QUrl.fromLocalFile(
            os.path.join(os.path.dirname(__file__), 'icons', 'reconstruct.png')).toString()
        header = ('<img src="%s" width="28" height="27"/>&nbsp;&nbsp;'
                  '<b>3D interpolation</b>\n\n' % icon_url)

        return header + self.tr(
            "A tool to reconstruct glacier surfaces and estimate ice thickness based on its basal topography "
            "and down valley limit (usually indicated by the position of a terminal moraine). "
            "A <b>Thin Plate Spline (TPS)</b> interpolation method is used to generate continuous raster layers "
            "that represent the reconstructed glacier surface elevation and ice thickness. " 
            "The methodology is based on Pellitero et al., (2015, 2016). \n"
            "Ice flow thickness points and the basin outline of the glacier are required user input data. "
            "Reconstructed surface resolution may be defined by the user, but will default "
            "to the input DEM resolution if not explicitly defined. \n"
            "Smoothing of the output rasters is applied by default (recommended) "
            "to reduce short-wavelength noise in the interpolated surface, and can be "
            "disabled. The smoothing approximates a Gaussian of the reconstructed "
            "surface; the radius is set automatically and reported in the processing log. \n\n"
            
            "<b>Outputs include:</b>\n\n"
            "<b>Reconstructed Glacier Thickness</b>: A raster layer of the estimated ice thickness.\n\n"
            "<b>Reconstructed Glacier Surface</b>: A raster layer of the glacier's interpolated surface elevation.\n\n"
            "Both load into a <b>Q-GlaRe Reconstructions</b> group in the Layers panel.\n\n"
            "<b>References:</b>\n"
            "  - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Hughes, P., Ivy-Ochs, S., Lukas, S., & Ribolini, A., 2015. "
            "A GIS tool for automatic calculation of glacier equilibrium-line altitudes. Computers & Geosciences, 82, pp. 55-62.\n"
            "  - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Ivy-Ochs, S., Frew, C.R., Hughes, P., Ribolini, A., Lukas, S., "
            "& Renssen, H., 2016. GlaRe, a GIS tool to reconstruct the 3D surface of palaeoglaciers. Computers & Geosciences, 94, pp. 77-85.\n"
            "  - Thin Plate Spline (TPS) Method: Documentation available at https://saga-gis.sourceforge.io.")

    def createInstance(self):
        """Return a fresh instance of the algorithm."""

        return Interpolation()

    def createCustomParametersWidget(self, parent=None):
        """
        Build the tool dialog with the icon at the top and the inputs grouped into
        collapsible sections. Falls back to the standard dialog if it cannot be built.
        """
        try:
            from .grouped_dialog import build_grouped_dialog
            DialogCls = build_grouped_dialog(
                os.path.dirname(__file__), "reconstruct.png", "3D interpolation",
                sections=[
                    ("Inputs", False, [
                        "InputDEM", "ice_flow_thickness", "input_polygon",
                        "user_interval", "ApplySmoothing"]),
                    ("Outputs", False, [
                        "ReconstructedGlacierThickness", "ReconstructedGlacierSurface"]),
                ])
            return DialogCls(self, parent=parent)
        except Exception:
            return None
    
    def icon(self):
        """Return the algorithm's toolbox icon."""
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'reconstruct.png')  # Ensure this is the correct filename

        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """
        Initialises the algorithm by defining its input parameters.
        """

        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem,
        self.tr("\nSelect current topography elevation data (DSM/DTM) raster"),
        [_SOURCE_RASTER]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.ice_flow_thickness, 
        self.tr("\nSelect ice flow thickness points (vector point file)"),
        [_SOURCE_VECTOR_POINT]))

        self.addParameter(QgsProcessingParameterNumber(
        self.user_interval,
        self.tr("\nSpecify the resolution of 3D interpolated surface in map units.\n"
                "Leave blank or 0 to use input DEM resolution. "
                "Minimum spacing is 25 map units. \n"
                "Values below 25 map units will be automatically adjusted. "),
        QgsProcessingParameterNumber.Integer, defaultValue=None))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_polygon,
        self.tr("\nSelect a polygon (vector polygon file) that defines the basin area containing the glacier."),
        [_SOURCE_VECTOR_POLYGON]))

        self.addParameter(QgsProcessingParameterBoolean(
        self.apply_smoothing,
        self.tr("\nApply smoothing to the output rasters (recommended)"),
        defaultValue=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
        'ReconstructedGlacierThickness', '\nReconstructed Glacier Thickness',
        createByDefault=True, defaultValue=''))
        
        self.addParameter(QgsProcessingParameterRasterDestination(
        'ReconstructedGlacierSurface', '\nReconstructed Glacier Surface', 
        createByDefault=True, defaultValue=''))

    def processAlgorithm(self, parameters, context, model_feedback):
        """Check dependencies, run the reconstruction end to end, and load the outputs into QGIS."""
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)
        glob_start_time = time.time()

        try:
            self._init_logger('3d_interpolation', feedback)

            # Check dependencies & preprocess inputs
            self.check_dependencies(feedback)
            inputs = self.preprocess_inputs(parameters, context, feedback)

            # Log basic initialisation
            self.log_initialization(feedback,
                                    dem=inputs['dem'].name(),
                                    ice_pts=inputs['ice_pts'].name(),
                                    user_interval=inputs['user_interval'],
                                    basin_polygon=inputs['basin_polygon'].name())
            self._log_run_header({
                'DEM':                  f"{inputs['dem'].name()} ({inputs['dem'].source()})",
                'Ice Thickness Points':  inputs['ice_pts'].name(),
                'Resolution (map units)': inputs['user_interval'],
                'Study Area Polygon':    inputs['basin_polygon'].name(),
            'CRS':                   inputs['crs_string'],
        })
            self._log_layer_crs([
                ('DEM',                 inputs['dem']),
                ('Ice Thickness Points', inputs['ice_pts']),
                ('Study Area Polygon',  inputs['basin_polygon']),
            ])
            start_time = time.time()
            self.log_initialization(feedback, stage="data_prep")
            self.log_processing_duration("Data processed for calculation", start_time)
            self.log_initialization(feedback, stage="input_processed")

            # Glacier grid creation
            grid_outputs = self.create_grid(context, feedback, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Glacier raster surface reconstruction
            recon_outputs = self.reconstruct_surface(parameters, context, feedback, grid_outputs, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Modify reconstructed raster surface
            modified_recon_outputs = self.modify_reconstructed_surface(parameters, context, feedback, recon_outputs, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Calculate glacier thickness raster surface
            glacier_thickness_outputs = self.create_glacier_thickness_surface(parameters, context, feedback, modified_recon_outputs, inputs)
            if feedback.isCanceled():
                raise QgsProcessingException("Processing cancelled.")

            # Recalculate glacier elevation surface
            glacier_elev_outputs = self.re_calculate_glacier_elevation_surface(parameters, context, feedback, glacier_thickness_outputs, inputs)

            # Load results into QGIS
            start_time = time.time()
            self.load_results(parameters, context, feedback, glacier_thickness_outputs, glacier_elev_outputs)
            self.log_processing_duration("Loaded data into QGIS project", start_time)
            self.log_final_results(feedback, inputs['crs_string'], glob_start_time)
            self._log_success(feedback)
            return {"Status": "Complete"}

        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )

    def check_dependencies(self, feedback):
        """
        Checks for required dependencies and logs each result.
        """
        feedback.pushInfo("Checking dependencies...\n")
        saga_installed, saga_msg = check_saga_installation()
        plugin_installed, plugin_msg = check_saga_plugin()
        saga_dir_set, saga_dir_msg = check_qgis_saga_directory()

        self._log("--- Dependency Check ---")
        self._log(f"  SAGA binary : {'OK' if saga_installed else 'FAIL'} | {saga_msg}")
        self._log(f"  SAGA plugin : {'OK' if plugin_installed else 'FAIL'} | {plugin_msg}")
        self._log(f"  SAGA dir    : {'OK' if saga_dir_set else 'FAIL'} | {saga_dir_msg}")

        if not (saga_installed and plugin_installed and saga_dir_set):
            errors = [m for ok, m in [
                (saga_installed, saga_msg),
                (plugin_installed, plugin_msg),
                (saga_dir_set, saga_dir_msg)
            ] if not ok]
            feedback.reportError("Dependency check failed:\n\n" + "\n\n".join(errors))
            raise QgsProcessingException("Dependency check failed.")

        self._log("  All dependencies OK")
        self._log("-" * 60)
        feedback.pushInfo("Dependencies check complete.\n")

    def preprocess_inputs(self, parameters, context, feedback):
        """Retrieve and validate the input layers and parameters.

        Returns a dict of the DEM, ice points, basin polygon, extent and CRS, plus the
        output resolution, which falls back to the DEM resolution and is floored at 25
        map units.
        """

        ice_pts = self.parameterAsVectorLayer(parameters, self.ice_flow_thickness, context)
        if ice_pts is None or not ice_pts.isValid():
            raise QgsProcessingException("Ice thickness points layer could not be retrieved or is not valid.")

        user_interval = self.parameterAsInt(parameters, self.user_interval, context)
        basin_polygon = self.parameterAsVectorLayer(parameters, self.input_polygon, context)

        if basin_polygon is None:
            raise QgsProcessingException("Basin polygon layer could not be retrieved from parameters.")

        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)
        if dem is None:
            raise QgsProcessingException("DEM layer could not be retrieved from parameters.")

        polygon_extent = basin_polygon.extent()
        extent = {
            "xmin": polygon_extent.xMinimum(),
            "xmax": polygon_extent.xMaximum(),
            "ymin": polygon_extent.yMinimum(),
            "ymax": polygon_extent.yMaximum()
        }

        crs = dem.crs()
        crs_string = crs.authid() if crs.isValid() else 'Unknown CRS'

        # Fallback to DEM resolution if needed
        pixel_size_x = dem.rasterUnitsPerPixelX()
        pixel_size_y = dem.rasterUnitsPerPixelY()
        dem_resolution = min(pixel_size_x, pixel_size_y)

        # If the user_interval is not provided (None or 0), use the DEM resolution,
        # A value of 25 is minimum value of output resolution.
        if user_interval is None or user_interval == 0:
            user_interval = dem_resolution
        user_interval = max(user_interval, 25)
        if not self.validate_dem_input(dem):
            raise QgsProcessingException(
                "The selected raster layer does not appear to be a valid DEM.\n\n"
                "Please ensure you select a raster layer that represents elevations (e.g., not a Hillshade).\n")

        # Validate that all inputs use a projected CRS and share the same CRS as the DEM
        self.validate_projected_crs(dem, feedback)
        self.validate_projected_crs(ice_pts, feedback)
        ice_pts = self.validate_layer_crs(ice_pts, crs, context, feedback)
        self.validate_projected_crs(basin_polygon, feedback)
        basin_polygon = self.validate_layer_crs(basin_polygon, crs, context, feedback)

        return {
            "ice_pts": ice_pts,
            "user_interval": user_interval,
            "basin_polygon": basin_polygon,
            "extent": extent,
            "dem": dem,
            "crs": crs,
            "crs_string": crs_string
        }    
   
    def create_grid(self, context, feedback, inputs):
        """Create a regular point grid over the basin and attach smoothed ice-surface values.

        Joins each grid point to the nearest ice-surface point, then applies a 5x5 mean.
        Returns the joined layer id under 'IceThicknessJoinSmoothed' with the new
        'ice_srf_sm' field; ff_ice_surface is preferred over ice_surface so shape-factor
        corrected values win.
        """

        start_time = time.time()
        self.log_initialization(feedback, stage="create_grid")

        outputs = {}

        # Create a regular grid of points within the basin polygon.
        alg_params = {
            'CRS': inputs['crs'],
            'EXTENT': inputs['basin_polygon'],
            'INSET': 0,
            'IS_SPACING': True,
            'RANDOMIZE': False,
            'SPACING': inputs['user_interval'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['CreateRegularGridOfPoints'] = self._run_algorithm(
            'qgis:regularpoints', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Create regular grid of points'
        )
        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            feedback.pushInfo("Processing cancelled.")
            return {}

        # Join by nearest points.
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELDS_TO_COPY': [''],
            'INPUT': outputs['CreateRegularGridOfPoints']['OUTPUT'],
            'INPUT_2': inputs['ice_pts'],
            'MAX_DISTANCE': None,
            'NEIGHBORS': 1,
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['IceThicknessJoin'] = self._run_algorithm(
            'native:joinbynearest', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Join grid to ice thickness points'
        )
        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Retrieve the joined grid layer.
        joined_layer = QgsProcessingUtils.mapLayerFromString(
            outputs['IceThicknessJoin']['OUTPUT'], context
        )
        if not joined_layer or not joined_layer.isValid():
            raise QgsProcessingException(
                "Could not retrieve the joined grid layer after spatial join. "
                "Check that the ice thickness points overlap the basin polygon extent."
            )

        # Determine the appropriate ice surface field.
        # ff_ice_surface must be checked first: the shape-factor output layer
        # contains both ff_ice_surface and ice_surface.
        # shape-factor corrected values are used when chosen by user.
        field_names = [f.name() for f in joined_layer.fields()]
        if "ff_ice_surface" in field_names or "ff_ice_sur" in field_names:
            full_field = "ff_ice_surface" if "ff_ice_surface" in field_names else "ff_ice_sur"
        elif "ice_surface" in field_names or "ice_surfac" in field_names:
            full_field = "ice_surface" if "ice_surface" in field_names else "ice_surfac"
        else:
            feedback.reportError("Ice surface field not found in computed grid layer.\n")
            raise QgsProcessingException("Missing required ice surface data.")

        self._log(f"Field detected: '{full_field}' ({'shape-factor corrected' if full_field in ('ff_ice_surface', 'ff_ice_sur') else 'standard ice flow thickness'})")

        # Compute the smoothed values using the helper smoothing function.
        smoothed_values = self.smooth_ice_surface_values(joined_layer, full_field, feedback)
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Create a new field to store the smoothed values (keeping the original field intact).
        joined_layer.startEditing()
        field_names = [f.name() for f in joined_layer.fields()]
        if "ice_srf_sm" not in field_names:
            joined_layer.addAttribute(QgsField("ice_srf_sm", _FIELD_DOUBLE))

        # Assign the smoothed values to the new field.
        field_idx = joined_layer.fields().indexOf("ice_srf_sm")
        for feat_id, val in smoothed_values.items():
            joined_layer.changeAttributeValue(feat_id, field_idx, val)
        joined_layer.commitChanges()

        # Store the new smoothed layer output with the new field name.
        outputs['IceThicknessJoinSmoothed'] = {
            'OUTPUT': joined_layer.id(),
            'FIELD': "ice_srf_sm"
        }

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        return outputs

    def smooth_ice_surface_values(self, joined_layer, full_field, feedback):
        """Smooth the joined ice-surface field with a 5x5 sliding-window mean.

        Exploits the regular grid from qgis:regularpoints. Edge cells fall back to their
        original value where the window is all NaN. Returns {feature id: smoothed value}.
        """
        from numpy.lib.stride_tricks import sliding_window_view

        start_time = time.time()
        self.log_initialization(feedback, stage="optimize_grid")

        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Load all features once and extract coords/values as numpy arrays.
        features = list(joined_layer.getFeatures())
        feat_ids = []
        xs = []
        ys = []
        vals = []
        for feat in features:
            geom = feat.geometry()
            if not geom:
                continue
            pt = geom.asPoint()
            feat_ids.append(feat.id())
            xs.append(pt.x())
            ys.append(pt.y())
            v = feat[full_field]
            vals.append(float(v) if v is not None else np.nan)

        feat_ids = np.array(feat_ids)
        xs = np.array(xs)
        ys = np.array(ys)
        vals = np.array(vals, dtype=float)

        # Infer grid dimensions from unique x/y coordinates.
        unique_x = np.sort(np.unique(np.round(xs, 6)))
        unique_y = np.sort(np.unique(np.round(ys, 6)))
        ncols = len(unique_x)
        nrows = len(unique_y)

        # Map each point to its (row, col) index in the 2D grid.
        cols = np.searchsorted(unique_x, np.round(xs, 6))
        rows = np.searchsorted(unique_y, np.round(ys, 6))

        # Build the 2D grid; NaN where no point exists.
        grid = np.full((nrows, ncols), np.nan)
        grid[rows, cols] = vals

        # Pad with NaN so edge points average only over valid neighbours.
        padded = np.pad(grid, 2, mode='constant', constant_values=np.nan)

        # Apply 5×5 sliding window nanmean - one vectorised operation.
        windows = sliding_window_view(padded, (5, 5))   # (nrows, ncols, 5, 5)
        smoothed_grid = np.nanmean(windows, axis=(-2, -1))

        # Read smoothed values back; fall back to original where result is NaN.
        smoothed_vals = smoothed_grid[rows, cols]
        fallback = np.isnan(smoothed_vals)
        smoothed_vals[fallback] = vals[fallback]

        return {int(fid): float(sv) for fid, sv in zip(feat_ids, smoothed_vals)}

    
    def reconstruct_surface(self, parameters, context, feedback, outputs, inputs):
        """Build the ice-elevation TIN by fitting a SAGA thin plate spline to the smoothed grid.

        Uses the grid spacing, extent and basin polygon from create_grid; returns the TIN
        raster under 'IceElevationTin'.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="reconstruct_surface")

        # Create Ice Elevation TIN via thin plate spline.
        alg_params = {
            'FIELD': outputs['IceThicknessJoinSmoothed']['FIELD'],
            'FRAME': False,
            'LEVEL': 0,
            'REGULARISATION': 1.0,
            'SHAPES':  outputs['IceThicknessJoinSmoothed']['OUTPUT'],
            'TARGET_USER_SIZE': inputs['user_interval'],
            'TARGET_USER_XMIN': inputs['extent']['xmin'],
            'TARGET_USER_XMAX': inputs['extent']['xmax'],
            'TARGET_USER_YMIN': inputs['extent']['ymin'],
            'TARGET_USER_YMAX': inputs['extent']['ymax'],
            'TARGET_OUT_GRID': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['IceElevationTin'] = self._run_algorithm(
            'sagang:thinplatesplinetin', alg_params, context, feedback,
            output_key='TARGET_OUT_GRID', step_name='Reconstruct ice elevation TIN'
        )
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        return outputs

    def modify_reconstructed_surface(self, parameters, context, feedback, outputs, inputs):
        """Clip and align the reconstructed surface and DEM to a common grid.

        Clips the surface and DEM to the basin, resamples the DEM to the output
        resolution, and re-clips the surface to the resampled DEM extent so the two
        rasters share pixel bounds.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="modify_reconstructed_surface")

        # Clip the TIN to the basin polygon.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['IceElevationTin']['TARGET_OUT_GRID'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': inputs['basin_polygon'],
            'OUTPUT': QgsProcessingUtils.generateTempFilename('tin_clipped.tif')
        }
        outputs['Tin_clipped'] = self._run_algorithm(
            'gdal:cliprasterbyextent', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip TIN to basin polygon'
        )
        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Clip the DEM to the basin polygon.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': inputs['dem'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': inputs['basin_polygon'],
            'OUTPUT': QgsProcessingUtils.generateTempFilename('clipped_dem.tif')
        }
        outputs['ClippedDEM'] = self._run_algorithm(
            'gdal:cliprasterbyextent', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip DEM to basin polygon'
        )
        
        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Finalize the clipped DEM.
        alg_params = {
            'INPUT': outputs['ClippedDEM']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessingUtils.generateTempFilename('finalized_clipped_dem.tif')
        }
        outputs['FinalizedClippedDEM'] = self._run_algorithm(
            'gdal:translate', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Finalize clipped DEM'
        )
        
        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Resample the DEM.
        alg_params = {
            'INPUT': outputs['FinalizedClippedDEM']['OUTPUT'],
            'TARGET_CRS': inputs['crs'],
            'TARGET_RESOLUTION': inputs['user_interval'],
            'RESAMPLING': 1,
            'OUTPUT': QgsProcessingUtils.generateTempFilename('resampled_dem.tif')
        }
        outputs['ResampledDEM'] = self._run_algorithm(
            'gdal:warpreproject', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Resample DEM to output resolution'
        )
        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Finalize the resampled DEM.
        alg_params = {
            'INPUT': outputs['ResampledDEM']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessingUtils.generateTempFilename('finalized_resampled_dem.tif')
        }
        outputs['FinalizedResampledDEM'] = self._run_algorithm(
            'gdal:translate', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Finalize resampled DEM'
        )
        
        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Re-clip the TIN to the extent of the resampled DEM to ensure precise dimensions.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['Tin_clipped']['OUTPUT'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': outputs['ResampledDEM']['OUTPUT'],
            'OUTPUT': QgsProcessingUtils.generateTempFilename('tin_reclipped.tif')
        }
        outputs['Tin_re-clipped'] = self._run_algorithm(
            'gdal:cliprasterbyextent', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Re-clip TIN to resampled DEM extent'
        )
        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Finalize the re-clipped TIN.
        alg_params = {
            'INPUT': outputs['Tin_re-clipped']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessingUtils.generateTempFilename('finalized_tin_reclipped.tif')
        }
        outputs['FinalizedTin_re-clipped'] = self._run_algorithm(
            'gdal:translate', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Finalize re-clipped TIN'
        )
        
        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
    
        return outputs

    @staticmethod
    def _shift_zero(array, shift, axis):
        """Shift ``array`` along ``axis`` by ``shift`` cells, zero-filled (no wrap)."""
        if shift == 0:
            return array
        out = np.zeros_like(array)
        src = [slice(None)] * array.ndim
        dst = [slice(None)] * array.ndim
        n = array.shape[axis]
        if shift > 0:
            src[axis] = slice(0, n - shift)
            dst[axis] = slice(shift, None)
        else:
            src[axis] = slice(-shift, None)
            dst[axis] = slice(0, n + shift)
        out[tuple(dst)] = array[tuple(src)]
        return out

    def _gaussian_blur_nan(self, array, sigma_px):
        """NaN-aware separable Gaussian blur, sigma in pixels.

        Normalised convolution: the data and its valid-cell mask are blurred
        separately then divided, so nodata neither contributes to nor bleeds into
        valid cells. Smoothed values are kept only where the input was valid, so the
        filter cannot create data where there was none or grow the glacier past its
        margin.
        """
        if sigma_px <= 0:
            return array.astype(np.float32)
        radius = max(1, int(np.ceil(3.0 * sigma_px)))
        offsets = np.arange(-radius, radius + 1, dtype=np.float64)
        kernel = np.exp(-(offsets ** 2) / (2.0 * sigma_px * sigma_px))
        kernel /= kernel.sum()
        mask = np.isfinite(array).astype(np.float64)
        data = np.where(mask > 0, np.asarray(array, dtype=np.float64), 0.0)

        def conv_axis(plane, axis):
            out = np.zeros_like(plane)
            for index, weight in enumerate(kernel):
                out += weight * self._shift_zero(plane, index - radius, axis)
            return out

        num = conv_axis(conv_axis(data, 0), 1)
        den = conv_axis(conv_axis(mask, 0), 1)
        with np.errstate(invalid='ignore', divide='ignore'):
            result = np.where(den > 1e-6, num / den, np.nan)
        # Preserve the input footprint: normalised convolution would otherwise fill
        # nodata cells within one kernel radius of valid data and grow the glacier
        # beyond its margin. Keep smoothed values only where the input was valid.
        result[mask <= 0] = np.nan
        return result.astype(np.float32)

    def _resolve_smoothing(self, parameters, context, inputs, product, feedback):
        """Resolve the automatic Gaussian smoothing settings for an output product.

        Returns (apply, kr_px, sigma_percent). The kernel radius follows the automatic
        rule min(500 m, 10% of the glacier's linear dimension), floored at 5 DEM cells;
        the standard deviation is a third of the radius (sigma_percent = 33.33), so the
        finite kernel spans about +/-3 sigma. Smoothing is a single on/off checkbox with
        no radius override; the full radius and sigma go to the run log.
        """
        apply = self.parameterAsBoolean(parameters, self.apply_smoothing, context)
        if not apply:
            # Full detail to the run log; a clean one-liner to the user.
            self._log(f"Gaussian smoothing ({product}): OFF - unsmoothed output requested")
            feedback.pushInfo("Smoothing: Off\n")
            return False, 0, 0

        area_m2 = sum(f.geometry().area() for f in inputs['basin_polygon'].getFeatures())
        # side length of an equal-area square: resolution-independent size proxy
        glacier_dimension_m = area_m2 ** 0.5
        cell = inputs['user_interval']

        # Automatic, resolution-aware kernel radius.
        KR_METRES      = 500   # ceiling: 50 px x 10 m (calibration resolution)
        CAP_FRACTION   = 0.1   # kr <= 10% of glacier linear dimension
        KR_FLOOR_CELLS = 5     # kr >= 5x cell size (Nyquist)
        kr_m = min(KR_METRES, glacier_dimension_m * CAP_FRACTION)
        kr_m = max(KR_FLOOR_CELLS * cell, kr_m)

        kr_px = max(3, int(kr_m / cell))
        sigma_percent = 100.0 / 3.0
        # Full detail to the run log; a clean one-liner to the user.
        sigma_m = (kr_px * cell) / 3.0
        self._log(f"Gaussian smoothing ({product}): ON, radius {kr_m:.0f} m (automatic; "
                  f"{kr_px} px, sigma {sigma_m:.1f} m / {sigma_percent:.2f}% of radius; "
                  f"glacier dimension {glacier_dimension_m:.0f} m)")
        feedback.pushInfo("Smoothing: On\n")
        return True, kr_px, sigma_percent

    def create_glacier_thickness_surface(self, parameters, context, feedback, outputs, inputs):
        """Derive ice thickness as the reconstructed surface minus the DEM, then clip to the basin.

        Non-positive values are set to NaN. This raw thickness is not smoothed.
        The final surface is Gaussian-smoothed, in re_calculate_glacier_elevation_surface.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="calculate_glacier_thickness")

        # Calculate the difference (TIN - DEM) to derive ice thickness.
        outputs['TinMinusDem'] = self._raster_calc(
            [outputs['FinalizedTin_re-clipped']['OUTPUT'],
             outputs['FinalizedResampledDEM']['OUTPUT']],
            lambda a, b: a - b,
            'tin_minus_dem.tif',
            step_name='Calculate ice thickness (TIN minus DEM)'
        )
        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Remove non-positive values.
        outputs['RemoveNegValues'] = self._raster_calc(
            [outputs['TinMinusDem']['OUTPUT']],
            lambda a: np.where(a <= 0, np.nan, a),
            'remove_neg_values.tif',
            step_name='Remove non-positive ice thickness values'
        )
        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # The reconstructed ice thickness is the raw TIN-minus-DEM difference.
        # The final surface is Gaussian-smoothed, in re_calculate_glacier_elevation_surface().
        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Clip the reconstructed thickness to the basin polygon.
        alg_params = {
            'ALPHA_BAND': False,
            'CROP_TO_CUTLINE': True,
            'DATA_TYPE': 0,  # Use Input Layer Data Type
            'EXTRA': '',
            'INPUT': outputs['RemoveNegValues']['OUTPUT'],
            'KEEP_RESOLUTION': True,
            'MASK': inputs['basin_polygon'],
            'SOURCE_CRS': inputs['crs'],
            'OUTPUT': self.parameterAsOutputLayer(parameters, 'ReconstructedGlacierThickness', context)
        }
        outputs['ice_thick_smooth_clipped'] = self._run_algorithm(
            'gdal:cliprasterbymasklayer', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip ice thickness to basin polygon'
        )
        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        return outputs
        
    def re_calculate_glacier_elevation_surface(self, parameters, context, feedback, outputs, inputs):
        """Rebuild the glacier surface as thickness + DEM, smooth it, and clip to the basin.

        The optional Gaussian pass (see the ApplySmoothing checkbox and _resolve_smoothing)
        removes residual DEM roughness carried in when thickness is added back to the DEM.
        """

        start_time = time.time()
        self.log_initialization(feedback, stage="calculate_glacier_elevation_surface")
        
        # Form the provisional glacier surface as ice thickness + DEM. The Gaussian
        # pass below smooths this combined surface.
        outputs['ice_thickness_plus_dem'] = self._raster_calc(
            [outputs['RemoveNegValues']['OUTPUT'],
             outputs['ResampledDEM']['OUTPUT']],
            lambda a, b: a + b,
            'ice_thickness_plus_dem.tif',
            step_name='Calculate glacier surface (ice thickness + DEM)'
        )
        self.log_processing_duration("Calculated glacier surface", start_time)
        
        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Gaussian smoothing of the surface raster (optional; see the ApplySmoothing
        # checkbox; kernel logic in _resolve_smoothing()). This second pass removes
        # residual DEM terrain roughness that is inherited when the smoothed ice
        # thickness is added to the DEM.
        apply_smoothing, kr_px, sigma_percent = self._resolve_smoothing(
            parameters, context, inputs, 'glacier surface', feedback)

        if apply_smoothing:
            # sigma in pixels from the resolved kernel (see create_glacier_thickness_surface).
            _sigma_px = kr_px * sigma_percent / 100.0
            outputs['surface_smooth'] = {
                'RESULT': self._raster_calc(
                    [outputs['ice_thickness_plus_dem']['OUTPUT']],
                    lambda a: self._gaussian_blur_nan(a, _sigma_px),
                    'surface_smooth.tif',
                    step_name='Smooth glacier surface (Gaussian filter)'
                )['OUTPUT']
            }
        else:
            # Smoothing disabled: pass the unsmoothed surface (thickness + DEM) through.
            outputs['surface_smooth'] = {'RESULT': outputs['ice_thickness_plus_dem']['OUTPUT']}

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")

        # Clip the glacier surface to the basin polygon. Both branches above return a
        # GeoTIFF with CRS and nodata already set, so it is clipped directly.
        alg_params = {
            'ALPHA_BAND': False,
            'CROP_TO_CUTLINE': True,
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['surface_smooth']['RESULT'],
            'KEEP_RESOLUTION': True,
            'MASK': inputs['basin_polygon'],
            'SOURCE_CRS': inputs['crs'],
            'OUTPUT': self.parameterAsOutputLayer(parameters, 'ReconstructedGlacierSurface', context)
        }
        outputs['ice_surface_smooth_clipped'] = self._run_algorithm(
            'gdal:cliprasterbymasklayer', alg_params, context, feedback,
            output_key='OUTPUT', step_name='Clip glacier surface to basin polygon'
        )
        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        return outputs

    def load_results(self, parameters, context, feedback, ice_thick_outputs, ice_elev_outputs):
        """Queue the final thickness and surface rasters for loading under the declared output names."""
        results = {}
        results['ReconstructedGlacierThickness'] = ice_thick_outputs.get('ice_thick_smooth_clipped', {}).get('OUTPUT', None)
        results['ReconstructedGlacierSurface'] = ice_elev_outputs.get('ice_surface_smooth_clipped', {}).get('OUTPUT', None)
        
        for key, layer_name in [
            ('ReconstructedGlacierSurface', "Reconstructed Glacier Surface"),
            ('ReconstructedGlacierThickness', "Reconstructed Glacier Thickness")
        ]:
            if results[key]:
                feedback.pushInfo(f"Adding {layer_name} to QGIS project...")
                details = context.layerToLoadOnCompletionDetails(results[key])
                # Ensure that the project is valid:
                if details.project is None:
                    details.project = QgsProject.instance()
                details.name = layer_name
                self._set_layer_group(details, "Q-GlaRe Reconstructions")
                # Tell QGIS which declared output parameter this layer belongs to
                # so it knows the type is raster and skips the OGR probe.
                details.outputName = key
                feedback.pushInfo(f"Added {layer_name} to project.\n")
        return {"Status": "Complete"}

    def validate_dem_input(self, input_raster):
        """Reject a raster that is not a plausible DEM.

        Fails on hillshade-style names and on a 0-255 value range with low standard
        deviation.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            return False

        # Check filename for hillshade keywords (name is already lowercased)
        hillshade_keywords = ["hillshade", "shaded_relief"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            return False

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            return False

        # If all checks pass, assume it's a valid DEM
        return True
    
    def log_initialization(self, feedback, dem=None, ice_pts=None, 
                           user_interval=None, basin_polygon=None, stage=None):
        """Push the initialisation banner and per-stage progress text to the feedback console."""

        if stage is None:
            # Log initialisation details
            feedback.setProgress(0)
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initialising Glacier Surface Interpolation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - DEM: {dem}")
            feedback.pushInfo(f"  - Ice Thickness Points: {ice_pts}")
            feedback.pushInfo(f"  - Resolution (map units): {user_interval}")
            feedback.pushInfo(f"  - Study Area Polygon: {basin_polygon}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText('Pre-processing input data...\n')
        elif stage == "input_processed":
            pass
        elif stage == "create_grid":
            feedback.setProgressText("Creating grid...\n")
        elif stage == "optimize_grid":
            feedback.setProgressText("Optimising grid...\n")
        elif stage == "reconstruct_surface":
            feedback.setProgressText("Reconstructing glacier surface...\n")
        elif stage == "modify_reconstructed_surface":
            feedback.setProgressText("Calculating glacier ice thickness...\n")
        elif stage == "calculate_glacier_thickness":
            feedback.setProgressText("Finalising results...\n")
        elif stage == "calculate_glacier_elevation_surface":
            pass
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def _raster_calc(self, input_paths, func, out_name, step_name=''):
        """Apply a numpy function to one or two aligned rasters via GDAL, writing a GeoTIFF.

        Runs the arithmetic directly rather than through a child processing algorithm,
        whose temp-file lifecycle deletes intermediate outputs between calls on Windows.
        Nodata pixels are masked to NaN before func runs; a secondary raster whose grid
        does not match the reference is warped to it first. Returns {'OUTPUT': path}.
        """
        label = step_name or out_name
        self._log(f"START  | {label} | raster_calc (numpy/GDAL)")
        t0 = time.time()

        try:
            datasets = []
            for p in input_paths:
                ds = gdal.Open(p)
                if ds is None:
                    raise QgsProcessingException(
                        f"Could not open input raster for step '{label}': {p}"
                    )
                datasets.append(ds)

            ref = datasets[0]
            ref_gt = ref.GetGeoTransform()
            ref_proj = ref.GetProjection()
            ref_xsize = ref.RasterXSize
            ref_ysize = ref.RasterYSize

            # Compute reference extent from geotransform.
            ref_xmin = ref_gt[0]
            ref_ymax = ref_gt[3]
            ref_xmax = ref_xmin + ref_xsize * ref_gt[1]
            ref_ymin = ref_ymax + ref_ysize * ref_gt[5]

            arrays = []
            warped_datasets = []  # keep in-memory datasets alive until arrays are read
            for ds in datasets:
                if ds.RasterXSize != ref_xsize or ds.RasterYSize != ref_ysize:
                    self._log(
                        f"WARN   | {label} | raster grid mismatch "
                        f"({ds.RasterXSize}x{ds.RasterYSize} vs {ref_xsize}x{ref_ysize})"
                        f" - warping to reference grid"
                    )
                    warped = gdal.Warp(
                        '', ds, format='MEM',
                        outputBounds=(ref_xmin, ref_ymin, ref_xmax, ref_ymax),
                        width=ref_xsize, height=ref_ysize,
                        resampleAlg=gdal.GRA_Bilinear
                    )
                    warped_datasets.append(warped)
                    src = warped
                else:
                    src = ds
                band = src.GetRasterBand(1)
                arr = band.ReadAsArray().astype(np.float32)
                nd = band.GetNoDataValue()
                if nd is not None and not np.isnan(nd):
                    arr[arr == nd] = np.nan
                arrays.append(arr)
            warped_datasets = None

            result = func(*arrays).astype(np.float32)

            out_path = QgsProcessingUtils.generateTempFilename(out_name)
            driver = gdal.GetDriverByName('GTiff')
            out_ds = driver.Create(
                out_path, ref_xsize, ref_ysize, 1, gdal.GDT_Float32
            )
            out_ds.SetGeoTransform(ref.GetGeoTransform())
            out_ds.SetProjection(ref.GetProjection())
            out_band = out_ds.GetRasterBand(1)
            NODATA = -9999.0
            result = np.where(np.isnan(result), NODATA, result)
            out_band.SetNoDataValue(NODATA)
            out_band.WriteArray(result)
            out_ds.FlushCache()
            out_ds = None
            datasets = None

        except QgsProcessingException:
            raise
        except Exception:
            tb = traceback.format_exc()
            self._log(
                f"FAILED | {label} | raster_calc | {time.time() - t0:.1f}s\n{tb}",
                level='error'
            )
            raise QgsProcessingException(
                "An error occurred. See log file."
                + (f"\n{self._log_path}" if self._log_path else "")
            )

        self._log(f"OK     | {label} | {time.time() - t0:.1f}s")
        return {'OUTPUT': out_path}

    def postProcessAlgorithm(self, context, feedback):
        """Show a completion dialog once processing finishes."""
        
        # Display completion message using a custom dialog
        QCoreApplication.processEvents()
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("Glacier Surface Interpolation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)
