"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 3D Interpolation
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, sys, time, platform
from osgeo import ogr, gdal
ogr.UseExceptions()
import processing
from qgis.PyQt.QtCore import QCoreApplication, QSettings, QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import (QgsProject,
                       QgsField,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsRasterLayer,
                       QgsSpatialIndex,
                       QgsRasterBandStats,
                       QgsProcessingUtils,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingParameterRasterDestination,
                       )



def get_qgis_saga_directory():
    """
    Retrieve the QGIS Processing SAGA directory from the correct settings key.
    Returns the directory path if found; otherwise, an empty string.
    """
    saga_dir = QSettings().value('Processing/Configuration/SAGA_FOLDER', '').strip()
    return os.path.normpath(saga_dir) if saga_dir else ""

def check_qgis_saga_directory():
    """
    Check if the QGIS Processing SAGA directory is set and valid.
    
    Returns:
        tuple: (status (bool), message (str))
    """
    saga_dir = get_qgis_saga_directory()

    if saga_dir and os.path.isdir(saga_dir):
        return True, f"SAGA directory is set: {saga_dir}"
    
    return (
        False,
        "SAGA directory is not set or is invalid in QGIS Processing options.\n"
        "Please set it via: Settings > Options > Processing > Providers > SAGA."
    )

def check_saga_installation():
    """
    Check if SAGA GIS is installed.
    
    Returns:
        tuple: (status (bool), message (str))
    """
    binary_names = ["saga_cmd.exe", "saga_cmd"] if platform.system() == "Windows" else ["saga_cmd"]
    saga_dir = get_qgis_saga_directory()

    if saga_dir and os.path.isdir(saga_dir):
        for binary in binary_names:
            binary_path = os.path.join(saga_dir, binary)
            if os.path.isfile(binary_path):
                return True, f"SAGA binary found: {binary_path}"
        return (
            False,
            f"SAGA directory is set to '{saga_dir}', but no SAGA binary was found there.\n"
            "Please check your installation or reinstall SAGA."
        )

    return (
        False,
        "SAGA is not installed or configured properly.\n"
        "Ensure SAGA is installed and the directory is set in QGIS:\n"
        "Settings > Options > Processing > Providers > SAGA."
    )

def check_saga_plugin():
    """
    Check if the SAGA GIS plugin is installed and enabled.
    
    Returns:
        tuple: (status (bool), message (str))
    """
    try:
        from qgis.utils import plugins
    except Exception:
        return False, "Error accessing QGIS plugins."

    plugin_names = ["processing_saga_nextgen", "processing_sagang_nextgen"]
    for name in plugin_names:
        if name in plugins:
            return True, f"SAGA plugin '{name}' is installed."
    
    return (
        False,
        "SAGA plugin is not installed.\n"
        "Please install it via: Plugins > Manage and Install Plugins."
    )

def check_dependencies(feedback=None):
    """
    Perform a combined dependency check for SAGA GIS installation, the plugin,
    and the QGIS Processing SAGA directory configuration.
    
    Returns:
        bool: True if all dependencies are satisfied; False otherwise.
    """
    saga_installed, saga_msg = check_saga_installation()
    plugin_installed, plugin_msg = check_saga_plugin()
    saga_dir_set, saga_dir_msg = check_qgis_saga_directory()

    error_messages = []
    
    # Print success messages only
    if saga_installed:
        print(saga_msg)
    else:
        error_messages.append(saga_msg)

    if plugin_installed:
        print(plugin_msg)
    else:
        error_messages.append(plugin_msg)

    if not saga_dir_set:
        error_messages.append(saga_dir_msg)

    # Show error messages if any issues exist
    if error_messages:
        full_error_message = "Dependency check failed:\n\n" + "\n\n".join(error_messages)
        if feedback:
            feedback.reportError(full_error_message)
        else:
            print(full_error_message)

    return saga_installed and plugin_installed and saga_dir_set

class Interpolation(QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for reconstructing glacier surfaces 
    and estimating ice thickness using spatial interpolation.

    This tool uses input data such as ice thickness points, 
    a DEM (DSM/DTM), and a basin extent polygon to generate 
    interpolated raster layers of the reconstructed glacier surface 
    and thickness. The tool applies the methodology from 
    Pellitero et al. (2015, 2016) and uses Thin Plate Spline 
    interpolation for surface reconstruction.

    Key Features:
    - Input Validation: Validates DEM and ice thickness points with 
        required fields.
    - Regular Grid Creation: Generates a grid of points for 
        interpolation based on user-specified resolution.
    - Interpolation: Applies Thin Plate Spline (TPS) interpolation 
        to compute the glacier surface elevation.
    - Ice Thickness Calculation: Derives ice thickness from the 
        interpolated surface.
    - Smoothing and Clipping: Applies Gaussian smoothing and clips 
        results to the study area polygon.
    - Outputs: Produces raster layers for:
        - Reconstructed glacier thickness.
        - Reconstructed glacier surface elevation.

    Inputs:
    - DEM: Raster layer of current topography (DSM/DTM).
    - Ice Thickness Points: Vector point layer containing ice surface 
        or thickness data.
    - Basin Extent Polygon: Polygon vector defining the study area.
    - Interpolation Interval: Resolution for generating a regular grid 
        of interpolation points.


    Outputs:
    - Reconstructed Glacier Thickness: Raster layer showing interpolated 
        ice thickness.
    - Reconstructed Glacier Surface: Raster layer showing interpolated 
        glacier surface elevation.

    References:
    - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Hughes, P., Ivy-Ochs, S., 
        Lukas, S., & Ribolini, A., 2015. A GIS tool for automatic calculation of 
        glacier equilibrium-line altitudes. Computers & Geosciences, 82, pp. 55-62.
    - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Ivy-Ochs, S., Frew, C.R., 
        Hughes, P., Ribolini, A., Lukas, S., & Renssen, H., 2016. GlaRe, a GIS tool 
        to reconstruct the 3D surface of palaeoglaciers. Computers & Geosciences, 94, pp. 77-85.
    - SAGA GIS, Thin Plate Spline (TPS) Method: Documentation available at https://saga-gis.sourceforge.io.
    """

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    input_polygon = 'input_polygon'
    ice_flow_thickness = 'ice_flow_thickness'

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return '3D Interpolation'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """

        return '4. 3D Interpolation'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
        
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("Interpolation", text)
    
    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)
     
    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """

        return self.tr(
            "A tool to reconstruct glacier surfaces and estimate ice thickness based on its basal topography "
            "and down valley limit (usually indicated by the position of a terminal moraine). "
            "A Thin Plate Spline (TPS) interpolation method is used to generate continuous raster layers "
            "that represent the reconstructed glacier surface elevation and ice thickness. " 
            "The methodology is based on Pellitero et al., (2015, 2016). \n"
            "Ice flow thickness points and the basin outline of the glacier are required user input data. "
            "Reconstructed surface resolution may be defined by the user, but will default "
            "to the input DEM resolution if not explicitly defined. \n\n"
            
            "Outputs include:\n"
            "- Reconstructed Glacier Thickness: A raster layer of the estimated ice thickness.\n"
            "- Reconstructed Glacier Surface: A raster layer of the glacier's interpolated surface elevation.\n\n"
            "References:\n"
            "  - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Hughes, P., Ivy-Ochs, S., Lukas, S., & Ribolini, A., 2015. "
            "A GIS tool for automatic calculation of glacier equilibrium-line altitudes. Computers & Geosciences, 82, pp. 55-62.\n"
            "  - Pellitero, R., Rea, B.R., Spagnolo, M., Bakke, J., Ivy-Ochs, S., Frew, C.R., Hughes, P., Ribolini, A., Lukas, S., "
            "& Renssen, H., 2016. GlaRe, a GIS tool to reconstruct the 3D surface of palaeoglaciers. Computers & Geosciences, 94, pp. 77-85.\n"
            "  - Thin Plate Spline (TPS) Method: Documentation available at https://saga-gis.sourceforge.io.")

    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            Interpolation: A new instance of the `Interpolation` class.
        """

        return Interpolation()
    
    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'reconstruct.png')  # Ensure this is the correct filename

        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """

        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem,
        self.tr("\nSelect current topography elevation data (DSM/DTM) raster"),
        [QgsProcessing.TypeRaster]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.ice_flow_thickness, 
        self.tr("\nSelect ice flow thickness points (vector point file)"),
        [QgsProcessing.TypeVectorPoint]))

        self.addParameter(QgsProcessingParameterNumber(
        self.user_interval,
        self.tr("\nSpecify the resolution of 3D interpolated surface in map units.\n"
                "Leave blank or 0 to use input DEM resolution. "
                "Minimum spacing is 25 map units. \n"
                "Values below 25 map units will be automatically adjusted. "),
        QgsProcessingParameterNumber.Integer, defaultValue=None))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_polygon, 
        self.tr("\nSelect a polygon (vector polygon file) that defines the basin area containing the glacier."),
        [QgsProcessing.TypeVectorPolygon]))
        
        self.addParameter(QgsProcessingParameterRasterDestination(
        'ReconstructedGlacierThickness', '\nReconstructed Glacier Thickness', 
        createByDefault=True, defaultValue=''))
        
        self.addParameter(QgsProcessingParameterRasterDestination(
        'ReconstructedGlacierSurface', '\nReconstructed Glacier Surface', 
        createByDefault=True, defaultValue=''))

    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Processes data and reconstructs the glacier by following these steps:
        - Check dependencies and preprocess inputs.
        - Determine which ice surface field to use.
        - Reconstruct the glacier surface via a series of processing steps.
        - Prepare and calculate glacier thickness.
        - Load the final layers into QGIS.
        """
        feedback = QgsProcessingMultiStepFeedback(19, model_feedback)
        outputs = {}
        glob_start_time = time.time()

        # Check dependencies & preprocess inputs
        self.check_dependencies(feedback)
        inputs = self.preprocess_inputs(parameters, context, feedback)

        # Determine the ice surface field to use
        field_value = self.determine_field_value(inputs['ice_pts'], context, feedback)

        # Log basic initialization
        self.log_initialization(feedback,
                                dem=inputs['dem'].name(),
                                ice_pts=inputs['ice_pts'].name(),
                                user_interval=inputs['user_interval'],
                                basin_polygon=inputs['basin_polygon'].name())
        start_time = time.time()
        self.log_initialization(feedback, stage="data_prep")
        self.log_processing_duration("Data processed for calculation", start_time)
        self.log_initialization(feedback, stage="input_processed")

        # Glacier grid creation
        grid_outputs = self.create_grid(context, feedback, inputs)
        
        # Glacier raster surface reconstruction
        recon_outputs = self.reconstruct_surface(parameters, context, feedback, grid_outputs, inputs, field_value)

        # Modify reconstructed raster surface
        modified_recon_outputs = self.modify_reconstructed_surface(parameters, context, feedback, recon_outputs, inputs)

        # Calculate glacier thickness raster surface
        glacier_thickness_outputs = self.create_glacier_thickness_surface(parameters, context, feedback, modified_recon_outputs, inputs)

        # Recalculate glacier elevation surface
        glacier_elev_outputs = self.re_calculate_glacier_elevation_surface(parameters, context, feedback, glacier_thickness_outputs, inputs)

        # Load results into QGIS
        start_time = time.time()
        self.load_results(parameters, context, feedback, glacier_thickness_outputs, glacier_elev_outputs)
        self.log_processing_duration("Loaded data into QGIS project", start_time)
        self.log_final_results(feedback, inputs['crs_string'], glob_start_time)

        return {"Status": "Complete"}

    def check_dependencies(self, feedback):
        """
        Checks for required dependencies.
        """
        feedback.pushInfo("Checking dependencies...\n")
        if not check_dependencies(feedback):
            raise QgsProcessingException("Dependency check failed.")
        feedback.pushInfo("Dependencies check complete.\n")

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieves and validates input layers and parameters.
        Returns a dictionary with:
        - ice_pts: Ice flow thickness points
        - user_interval: Output resolution (fallback to DEM resolution if needed)
        - basin_polygon: Basin-defining polygon
        - extent: Extent (xmin, xmax, ymin, ymax) of the polygon
        - dem: Input DEM raster layer
        - crs, crs_string: CRS of the DEM
        """

        ice_pts = self.parameterAsVectorLayer(parameters, self.ice_flow_thickness, context)
        user_interval = self.parameterAsInt(parameters, self.user_interval, context)
        basin_polygon = self.parameterAsVectorLayer(parameters, self.input_polygon, context)
        polygon_extent = basin_polygon.extent()
        extent = {
            "xmin": polygon_extent.xMinimum(),
            "xmax": polygon_extent.xMaximum(),
            "ymin": polygon_extent.yMinimum(),
            "ymax": polygon_extent.yMaximum()
        }

        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)
        crs = dem.crs()
        crs_string = crs.authid() if crs.isValid() else 'Unknown CRS'

        # Fallback to DEM resolution if needed
        pixel_size_x = dem.rasterUnitsPerPixelX()
        pixel_size_y = dem.rasterUnitsPerPixelY()
        dem_resolution = min(pixel_size_x, pixel_size_y)
        
        # If the user_interval is not provided (None or 0), use the DEM resolution,
        # A value of 25 is minimum value of output resolution.
        if user_interval is None or user_interval == 0:
            user_interval = dem_resolution
        user_interval = max(user_interval, 25)

        # Validate DEM and CRS of ice_pts
        if dem is None:
            raise QgsProcessingException("DEM layer could not be retrieved from parameters.")
        if not self.validate_dem_input(dem):
            raise QgsProcessingException(
                "The selected raster layer does not appear to be a valid DEM.\n\n"
                "Please ensure you select a raster layer that represents elevations (e.g., not a Hillshade).\n")
        
        # Validate that DEM uses projected CRS
        self.validate_projected_crs(dem, feedback) 

        return {
            "ice_pts": ice_pts,
            "user_interval": user_interval,
            "basin_polygon": basin_polygon,
            "extent": extent,
            "dem": dem,
            "crs": crs,
            "crs_string": crs_string
        }    

    def determine_field_value(self, ice_pts, context, feedback):
        """
        Inspects the ice_pts layer to determine which field holds the ice surface data.
        Field name length of 10 maximum of SAGA Next Gen processes.
        """
        ice_pts_layer_id = ice_pts.id()
        selected_layer = QgsProcessingUtils.mapLayerFromString(ice_pts_layer_id, context)
        layer_fields = [field.name() for field in selected_layer.fields()]
        if 'ff_ice_surface' in layer_fields:
            return 'ff_ice_sur'
        elif 'ice_surface' in layer_fields:
            return 'ice_surfac'
        else:
            feedback.reportError("Required ice surface data not found in the selected layer.")
            raise QgsProcessingException("Missing required ice surface data.")

    def create_grid(self, context, feedback, inputs):
        """
        Create a grid for glacier surface reconstruction and smooth the ice surface values.

        This function:
        - Creates a regular grid of points within the basin polygon.
        - Joins the grid points to existing ice thickness points using a nearest-neighbor join.
        - Retrieves the joined grid layer and determines the appropriate ice surface field.
        - Computes smoothed ice surface values using a K-nearest neighbor approach via a helper function.
        - Creates a new attribute field to store the smoothed values.
        - Returns a dictionary of outputs including the joined and smoothed grid layer details.

        Parameters:
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for logging progress and checking cancelation.
            inputs (dict): Dictionary of input values including:
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The polygon defining the basin.
                - 'user_interval': The spacing between grid points.
                - 'ice_pts': The layer with ice thickness points.

        Returns:
            dict: Dictionary containing output layers and fields, including:
                - 'IceThicknessJoinSmoothed': A dictionary with:
                    - 'OUTPUT': The ID of the joined and smoothed grid layer.
                    - 'FIELD': The name of the new field storing the smoothed ice surface values.

        Raises:
            QgsProcessingException: If processing is canceled or if the required ice surface field is missing.
        """

        start_time = time.time()
        self.log_initialization(feedback, stage="create_grid")

        outputs = {}

        # Create a regular grid of points within the basin polygon.
        alg_params = {
            'CRS': inputs['crs'],
            'EXTENT': inputs['basin_polygon'],
            'INSET': 0,
            'IS_SPACING': True,
            'RANDOMIZE': False,
            'SPACING': inputs['user_interval'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['CreateRegularGridOfPoints'] = processing.run(
            'qgis:regularpoints', alg_params, context=context, feedback=None,
            is_child_algorithm=True
        )
        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            feedback.pushInfo("Processing canceled.")
            return {}

        # Join by nearest points.
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELDS_TO_COPY': [''],
            'INPUT': outputs['CreateRegularGridOfPoints']['OUTPUT'],
            'INPUT_2': inputs['ice_pts'],
            'MAX_DISTANCE': None,
            'NEIGHBORS': 1,
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['IceThicknessJoin'] = processing.run(
            'native:joinbynearest', alg_params, context=context, feedback=None,
            is_child_algorithm=True
        )
        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")

        # Retrieve the joined grid layer.
        joined_layer = QgsProcessingUtils.mapLayerFromString(
            outputs['IceThicknessJoin']['OUTPUT'], context
        )
        if not joined_layer or not joined_layer.isValid():
            feedback.pushInfo("Could not retrieve the joined grid layer.")
            return outputs  # Return what we have so far

        # Determine the appropriate ice surface field.
        field_names = [f.name() for f in joined_layer.fields()]
        if "ice_surface" in field_names:
            full_field = "ice_surface"
        elif "ff_ice_surface" in field_names:
            full_field = "ff_ice_surface"
        else:
            feedback.reportError("Ice surface field not found in computed grid layer.")
            raise QgsProcessingException("Missing required ice surface data.")

        # Compute the smoothed values using the helper smoothing function.
        smoothed_values = self.smooth_ice_surface_values(joined_layer, full_field, feedback)
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")

        # Create a new field to store the smoothed values (keeping the original field intact).
        joined_layer.startEditing()
        field_names = [f.name() for f in joined_layer.fields()]
        if "ice_srf_sm" not in field_names:
            joined_layer.addAttribute(QgsField("ice_srf_sm", QVariant.Double))

        # Assign the smoothed values to the new field.
        for feat_id, val in smoothed_values.items():
            joined_layer.changeAttributeValue(
                feat_id,
                joined_layer.fields().indexOf("ice_srf_sm"),
                val
            )
        joined_layer.commitChanges()

        # Store the new smoothed layer output with the new field name.
        outputs['IceThicknessJoinSmoothed'] = {
            'OUTPUT': joined_layer.id(),
            'FIELD': "ice_srf_sm"
        }

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")

        return outputs

    def smooth_ice_surface_values(self, joined_layer, full_field, feedback):
        """
        Compute smoothed values for the joined layer using a K-nearest neighbor approach.

        This function:
        - Builds a spatial index for the provided layer.
        - Iterates over each feature in the layer.
        - For each feature, finds its k-nearest neighbors and computes the average of the values in the
        specified field.
        - Returns a dictionary mapping each feature ID to the computed smoothed value.

        Parameters:
            joined_layer (QgsVectorLayer): The layer containing features to smooth.
            full_field (str): The name of the field containing the original ice surface values.
            feedback (QgsProcessingFeedback): Object for reporting progress and checking for cancelation.

        Returns:
            dict: A dictionary mapping feature IDs (int) to the computed smoothed value (float).

        Raises:
            QgsProcessingException: If processing is canceled.
        """

        start_time = time.time()
        self.log_initialization(feedback, stage="optimize_grid")

        k_neighbors = 25  # Approximates a 5x5 moving window

        # Build a spatial index for the smoothing process.
        spatial_index = QgsSpatialIndex()
        joined_layer.selectAll()
        features = list(joined_layer.getFeatures())
        spatial_index.addFeatures(features)

        smoothed_values = {}

        # Loop over each feature to compute the average of k-nearest neighbor values.
        for feat in joined_layer.getFeatures():
            # Check for cancelation.
            if feedback.isCanceled():
                raise QgsProcessingException("Processing canceled.")

            geom = feat.geometry()
            if not geom:
                continue

            point = geom.asPoint()
            nearest_ids = spatial_index.nearestNeighbor(point, k_neighbors)
            neighbor_values = []
            for neighbor_id in nearest_ids:
                neighbor_feat = joined_layer.getFeature(neighbor_id)
                if neighbor_feat and neighbor_feat[full_field] is not None:
                    try:
                        neighbor_values.append(float(neighbor_feat[full_field]))
                    except Exception:
                        continue
            if neighbor_values:
                avg_val = sum(neighbor_values) / len(neighbor_values)
            else:
                avg_val = feat[full_field]
            smoothed_values[feat.id()] = avg_val

        return smoothed_values

    
    def reconstruct_surface(self, parameters, context, feedback, outputs, inputs, field_value):
        """
        Reconstruct the glacier surface using a thin plate spline TIN method.

        This function:
        - Creates an Ice Elevation TIN based on the smoothed ice thickness grid.
        - Uses the provided grid spacing, extent, and basin polygon to generate the TIN.
        - Returns the TIN output for further processing.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing outputs from previous steps.
            inputs (dict): Dictionary of inputs including:
                - 'user_interval': The grid spacing.
                - 'extent': A dictionary with keys 'xmin', 'xmax', 'ymin', 'ymax'.
                - 'basin_polygon': The polygon defining the basin.
            field_value (any): A value from a field used in the reconstruction process.

        Returns:
            dict: Dictionary of outputs including the key 'IceElevationTin' with the TIN result.

        Raises:
            QgsProcessingException: If processing is canceled.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="reconstruct_surface")

        # Create Ice Elevation TIN via thin plate spline.
        alg_params = {
            'FIELD': outputs['IceThicknessJoinSmoothed']['FIELD'],
            'FRAME': False,
            'LEVEL': 0,
            'REGULARISATION': 1.0,
            'SHAPES':  outputs['IceThicknessJoinSmoothed']['OUTPUT'],
            'TARGET_USER_SIZE': inputs['user_interval'],
            'TARGET_USER_XMIN': inputs['extent']['xmin'],
            'TARGET_USER_XMAX': inputs['extent']['xmax'],
            'TARGET_USER_YMIN': inputs['extent']['ymin'],
            'TARGET_USER_YMAX': inputs['extent']['ymax'],
            'TARGET_OUT_GRID': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['IceElevationTin'] = processing.run('sagang:thinplatesplinetin', 
                                                    alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        return outputs

    def modify_reconstructed_surface(self, paramters, context, feedback, outputs, inputs):
        """
        Modify the reconstructed glacier surface to match the DEM.

        This function:
        - Clips the reconstructed TIN to the basin polygon.
        - Clips and finalizes the DEM to the basin polygon.
        - Resamples the clipped DEM.
        - Re-clips the TIN based on the resampled DEM extent and finalizes the result.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing outputs from previous processing steps.
            inputs (dict): Dictionary of inputs including:
                - 'dem': The digital elevation model.
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The basin polygon used for clipping.

        Returns:
            dict: Dictionary of outputs including clipped and resampled DEM and TIN layers.

        Raises:
            QgsProcessingException: If processing is canceled.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="modify_reconstructed_surface")

        # Clip the TIN to the basin polygon.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['IceElevationTin']['TARGET_OUT_GRID'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': inputs['basin_polygon'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Tin_clipped'] = processing.run('gdal:cliprasterbyextent', 
                                                alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")

        # Clip the DEM to the basin polygon.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': inputs['dem'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': inputs['basin_polygon'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ClippedDEM'] = processing.run('gdal:cliprasterbyextent', 
                                            alg_params, context=context, feedback=None, is_child_algorithm=True)
        
        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            feedback.pushInfo("Processing canceled.")
            return {}
        
        # Finalize the clipped DEM.
        alg_params = {
            'INPUT': outputs['ClippedDEM']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FinalizedClippedDEM'] = processing.run('gdal:translate', 
                                                        alg_params, context=context, feedback=None, is_child_algorithm=True)
        
        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        # Resample the DEM.
        alg_params = {
            'INPUT': outputs['FinalizedClippedDEM']['OUTPUT'],
            'TARGET_CRS': inputs['crs'],
            'TARGET_RESOLUTION': inputs['user_interval'],
            'RESAMPLING': 1,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ResampledDEM'] = processing.run('gdal:warpreproject', 
                                                alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        # Finalize the resampled DEM.
        alg_params = {
            'INPUT': outputs['ResampledDEM']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FinalizedResampledDEM'] = processing.run('gdal:translate', 
                                                        alg_params, context=context, feedback=None, is_child_algorithm=True)
        
        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        # Re-clip the TIN to the extent of the resampled DEM to ensure precise dimensions.
        alg_params = {
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['Tin_clipped']['OUTPUT'],
            'NODATA': None,
            'OPTIONS': '',
            'OVERCRS': False,
            'PROJWIN': outputs['ResampledDEM']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Tin_re-clipped'] = processing.run('gdal:cliprasterbyextent', 
                                                    alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")

        # Finalize the re-clipped TIN.
        alg_params = {
            'INPUT': outputs['Tin_re-clipped']['OUTPUT'],
            'OPTIONS': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FinalizedTin_re-clipped'] = processing.run('gdal:translate', 
                                                            alg_params, context=context, feedback=None, is_child_algorithm=True)
        
        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
    
        return outputs
        
    def create_glacier_thickness_surface(self, parameters, context, feedback, outputs, inputs):
        """
        Create the glacier thickness surface by calculating the difference between the
        reconstructed TIN surface and the DEM, followed by smoothing and clipping.

        This function:
        - Computes the difference (TIN minus DEM) using a raster calculator.
        - Replaces non-positive values with NaN.
        - Applies a Gaussian filter to smooth the ice thickness raster.
        - Clips the smoothed raster to the basin polygon.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing outputs from previous steps.
            inputs (dict): Dictionary of inputs that includes:
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The basin polygon.
                - 'user_interval': The grid spacing.
                - 'dem': The digital elevation model.

        Returns:
            dict: Dictionary of outputs including the key 'ice_thick_smooth_clipped',
                which represents the final smoothed and clipped glacier thickness surface.

        Raises:
            QgsProcessingException: If processing is canceled.
        """
        
        start_time = time.time()
        self.log_initialization(feedback, stage="calculate_glacier_thickness")

        # Calculate the difference (TIN - DEM) to derive ice thickness.
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'EXTRA': '',
            'FORMULA': '(A - B)',
            'INPUT_A': outputs['FinalizedTin_re-clipped']['OUTPUT'],
            'INPUT_B': outputs['FinalizedResampledDEM']['OUTPUT'],
            'OPTIONS': inputs['crs'],
            'RTYPE': 5,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['TinMinusDem'] = processing.run('gdal:rastercalculator', 
                                                alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
    
        # Remove non-positive values.
        alg_params = {
            'BAND_A': 1,
            'FORMULA': 'where(A <= 0, nan, A)',
            'INPUT_A': outputs['TinMinusDem']['OUTPUT'],
            'RTYPE': 5,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RemoveNegValues'] = processing.run('gdal:rastercalculator', 
                                                    alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        # Apply a Gaussian filter to smooth the ice thickness raster.
        alg_params = {
            'INPUT': outputs['RemoveNegValues']['OUTPUT'],
            'KERNEL_RADIUS': 50,
            'KERNEL_TYPE': 1,  # Circle
            'SIGMA': 200,
            'RESULT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ice_thickness_smooth'] = processing.run('sagang:gaussianfilter', 
                                                alg_params, context=context, feedback=None, is_child_algorithm=True)
        
        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        # Clip raster by mask layer
        alg_params = {
            'ALPHA_BAND': False,
            'CROP_TO_CUTLINE': True,
            'DATA_TYPE': 0,  # Use Input Layer Data Type
            'EXTRA': '',
            'INPUT': outputs['ice_thickness_smooth']['RESULT'],
            'KEEP_RESOLUTION': False,
            'MASK': inputs['basin_polygon'],
            'SOURCE_CRS': inputs['crs'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ice_thick_smooth_clipped'] = processing.run('gdal:cliprasterbymasklayer', 
                                                  alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        return outputs
        
    def re_calculate_glacier_elevation_surface(self, parameters, context, feedback, outputs, inputs):
        """
        Re-calculate the glacier elevation surface by adding the ice thickness to the DEM,
        followed by Gaussian filtering and clipping.

        This function:
        - Adds the smoothed ice thickness (from the raster difference) to the DEM.
        - Applies a Gaussian filter to smooth the resulting surface.
        - Clips the smoothed surface to the basin polygon.

        Parameters:
            parameters (dict): Dictionary of algorithm parameters.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Object for progress reporting and cancelation.
            outputs (dict): Dictionary containing prior processing outputs such as:
                - 'RemoveNegValues'
                - 'ResampledDEM'
                - 'surface_smooth'
            inputs (dict): Dictionary of inputs including:
                - 'crs': The coordinate reference system.
                - 'basin_polygon': The polygon for clipping.
                - 'dem': The original digital elevation model.

        Returns:
            dict: Dictionary of outputs including the key 'ice_surface_smooth_clipped',
                representing the final glacier elevation surface.

        Raises:
            QgsProcessingException: If processing is canceled.
        """

        start_time = time.time()
        self.log_initialization(feedback, stage="calculate_glacier_elevation_surface")
        
        # Add ice elevation to topography post-Gaussian smoothing.
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'EXTRA': '',
            'FORMULA': '(A) + B',
            'INPUT_A': outputs['RemoveNegValues'] ['OUTPUT'],
            'INPUT_B': outputs['ResampledDEM']['OUTPUT'],
            'RTYPE': 5,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ice_thickness_plus_dem'] = processing.run('gdal:rastercalculator', 
                                                        alg_params, context=context, feedback=None, is_child_algorithm=True)
        self.log_processing_duration("Calculated glacier surface", start_time)
        
        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing cancelled.")
        
        # Finalize the raster by applying a Gaussian filter.
        alg_params = {
            'INPUT': outputs['ice_thickness_plus_dem']['OUTPUT'],
            'KERNEL_RADIUS': 50,
            'KERNEL_TYPE': 1,  # Circle
            'SIGMA': 200,
            'RESULT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['surface_smooth'] = processing.run('sagang:gaussianfilter', 
                                                alg_params, context=context, feedback=None, is_child_algorithm=True)

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")

        # Clip the calculated surface by the basin polygon.
        alg_params = {
            'ALPHA_BAND': False,
            'CROP_TO_CUTLINE': True,
            'DATA_TYPE': 0,
            'EXTRA': '',
            'INPUT': outputs['surface_smooth']['RESULT'],
            'KEEP_RESOLUTION': False,
            'MASK': inputs['basin_polygon'],
            'SOURCE_CRS': inputs['crs'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ice_surface_smooth_clipped'] = processing.run('gdal:cliprasterbymasklayer', 
                                                                alg_params, context=context, feedback=None, is_child_algorithm=True)
        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            raise QgsProcessingException("Processing canceled.")
        
        return outputs

    def load_results(self, parameters, context, feedback, ice_thick_outputs, ice_elev_outputs):
        """
        Loads the final raster layers into the QGIS project.
        Returns a dictionary of output layers whose keys match the declared
        output parameters.
        """
        results = {}
        results['ReconstructedGlacierThickness'] = ice_thick_outputs.get('ice_thick_smooth_clipped', {}).get('OUTPUT', None)
        results['ReconstructedGlacierSurface'] = ice_elev_outputs.get('ice_surface_smooth_clipped', {}).get('OUTPUT', None)
        
        for key, layer_name in [
            ('ReconstructedGlacierSurface', "Reconstructed Glacier Surface"),
            ('ReconstructedGlacierThickness', "Reconstructed Glacier Thickness")
        ]:
            if results[key]:
                feedback.pushInfo(f"Adding {layer_name} to QGIS project...")
                details = context.layerToLoadOnCompletionDetails(results[key])
                # Ensure that the project is valid:
                if details.project is None:
                    details.project = QgsProject.instance()
                details.name = layer_name
                feedback.pushInfo(f"Added {layer_name} to project.\n")
        return results

    def validate_dem_input(self, input_raster):
        """
        Validate whether the input raster layer represents a Digital Elevation Model (DEM) 
        and not a hillshade, based on filename and statistical checks.

        Parameters:
            input_raster (QgsRasterLayer): The input raster layer.

        Returns:
            bool: True if the layer is a valid DEM, False otherwise.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            return False

        # Check filename for "hillshade" or similar keywords
        hillshade_keywords = ["hillshade", "shade", "Hillshade", "Shade", "HILLSHADE", "SHADE"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            return False

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1, QgsRasterBandStats.All)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            return False

        # If all checks pass, assume it's a valid DEM
        return True
    
    def validate_layer_crs(self, layer, target_crs):
        """
        Validate that the input layer's CRS matches the target CRS.
        
        Parameters:
            layer (QgsVectorLayer or QgsRasterLayer): The layer to validate.
            target_crs (QgsCoordinateReferenceSystem): The CRS that all layers should match (e.g., the DEM's CRS).
        
        Raises:
            QgsProcessingException: If the layer's CRS does not match the target CRS.
        """
        if not layer or not layer.isValid():
            raise QgsProcessingException("Invalid input layer.")
        
        if layer.crs().authid() != target_crs.authid():
            raise QgsProcessingException(
                f"CRS mismatch:  All input layers and data must use the same projected CRS."
                "\n\nPlease ensure all input data share the same projected CRS.\n"
            )
        
    def validate_projected_crs(self, layer, feedback):
        """
        Validate that the provided layer uses a projected coordinate system with properly transformed coordinates.
        
        This function:
        - Checks if the layer has a valid CRS defined.
        - Checks if the layer's CRS is geographic (lat/long).
        - Checks if the actual coordinate values match the CRS type (detects incorrect reprojection).
        - Raises an exception if the CRS is invalid, undefined, geographic, or if coordinates don't match the CRS.
        
        Parameters:
            layer (QgsVectorLayer or QgsRasterLayer): The layer to validate.
            feedback (QgsProcessingFeedback): For logging messages.
        
        Returns:
            None
        
        Raises:
            QgsProcessingException: If the layer has CRS issues or coordinate mismatches.
        """
        
        if not layer or not layer.isValid():
            raise QgsProcessingException("Invalid input layer.")
        
        layer_crs = layer.crs()
        layer_name = layer.name() if layer else "Unknown layer"
        is_raster = isinstance(layer, QgsRasterLayer)
        
        # Check if CRS is defined and valid
        if not layer_crs or not layer_crs.isValid():
            reproject_instruction = "Raster -> Projections -> Warp (Reproject)" if is_raster else "Vector -> Data Management Tools -> Reproject Layer"
            raise QgsProcessingException(
                f"Missing CRS: The input layer '{layer_name}' has no coordinate reference system defined.\n\n"
                "This algorithm requires that all input data have a valid projected CRS assigned.\n\n"
                "Please assign a projected coordinate system to your layer.\n"
                f"{reproject_instruction}\n"
            )
        
        # Check if CRS is geographic (lat/long)
        if layer_crs.isGeographic():
            reproject_instruction = "Raster -> Projections -> Warp (Reproject)" if is_raster else "Vector -> Data Management Tools -> Reproject Layer"
            raise QgsProcessingException(
                f"Invalid CRS: The layer '{layer_name}' uses a geographic coordinate system ({layer_crs.authid()}).\n\n"
                "This algorithm requires projected coordinates in meters (e.g., UTM).\n"
                "Geographic coordinates (latitude/longitude in degrees) will produce incorrect results.\n\n"
                "Please reproject your data to an appropriate projected coordinate system.\n"
                f"{reproject_instruction}\n"
            )
        
        # Check if coordinates look like geographic despite CRS claiming to be projected
        extent = layer.extent()
        if (abs(extent.xMinimum()) < 360 and abs(extent.xMaximum()) < 360 and 
            abs(extent.yMinimum()) < 90 and abs(extent.yMaximum()) < 90):
            
            reproject_instruction = "Raster -> Projections -> Warp (Reproject)" if is_raster else "Vector -> Data Management Tools -> Reproject Layer"
            export_note = "" if is_raster else "Or: Right-click layer -> Export -> Save Features As (with CRS transformation)\n"
            
            raise QgsProcessingException(
                f"CRS mismatch detected: The layer '{layer_name}' is set to projected CRS ({layer_crs.authid()}), "
                "but the coordinates appear to be in geographic format (lat/long).\n\n"
                f"Extent: X[{extent.xMinimum():.2f}, {extent.xMaximum():.2f}], "
                f"Y[{extent.yMinimum():.2f}, {extent.yMaximum():.2f}]\n\n"
                "This occurs when the CRS is assigned without transforming the coordinate values.\n\n"
                "To fix:\n"
                f"{reproject_instruction}\n"
                f"{export_note}"
                "Choose an appropriate projected CRS (e.g., UTM zone)\n"
                "Verify output coordinates are large numbers (e.g., 273000), not degrees (e.g., -119.5)\n\n"
                "Note: 'Set Layer CRS' does not transform coordinates. You must reproject the data.\n"
            )
    
    def log_initialization(self, feedback, dem=None, ice_pts=None, 
                           user_interval=None, basin_polygon=None, stage=None):
        """
        Log initialization and progress updates to the QGIS feedback console.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for logging messages.
            dem_filename (str): Name of the DEM file being processed.
            ice_thick_name (str): Name of the ice thickness points file.
            distance (float): Resolution in map units.
            flowline_name (str): Name of the flowline file.
            transects_name (str): Name of the transects file.
            shear (float): Shear stress value used in calculations.
            stage (str): Current stage of the workflow (optional).
            valid_percentage (float): Percentage of valid points during validation (optional).
            invalid_points (list): List of invalid points during validation (optional).

        Returns:
            None
        """

        if stage is None:
            # Log initialization details
            feedback.setProgress(0)
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initializing Glacier Surface Interpolation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - DEM: {dem}")
            feedback.pushInfo(f"  - Ice Thickness Points: {ice_pts}")
            feedback.pushInfo(f"  - Resolution (map units): {user_interval}")
            feedback.pushInfo(f"  - Study Area Polygon: {basin_polygon}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText('Pre-processing input data...\n')
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "create_grid":
            feedback.setProgressText("Creating grid...\n")
        elif stage == "optimize_grid":
            feedback.setProgressText("Optimizing grid...\n")
        elif stage == "reconstruct_surface":
            feedback.setProgressText("Reconstructing glacier surface...\n")
        elif stage == "modify_reconstructed_surface":
            feedback.setProgressText("Finalizing reconstructed glacier surface...\n")
        elif stage == "calculate_glacier_thickness":
            feedback.setProgressText("Calculating reconstructed glacier thickness...\n")  
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def log_processing_duration(self, process_name, start_time):
        """
        Log the duration of a process to the QGIS message log.

        Parameters:
            process_name (str): Name of the process being logged.
            start_time (float): Start time of the process (in seconds).

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"{process_name} completed in {duration:.4f} seconds", "Glacier Reconstruction Processing Log", level=3)

    def log_final_results(self, feedback, crs_string, start_time):
        """
        Log the final results of the processing and completion message to the QGIS feedback console.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for logging messages.
            crs_string (str): Coordinate reference system (CRS) of the processed data.
            start_time (float): Start time of the entire process (in seconds).

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"All data calculated in projection: {crs_string}", "Glacier Reconstruction Processing Log", level=3)
        QgsMessageLog.logMessage("-----------------------------------------END PROCESS-----------------------------------------\n", 
                                "Glacier Reconstruction Processing Log", level=0)
        feedback.pushInfo(f"All data processed in: {duration:.4f} seconds.\n")
        feedback.pushInfo(f"All data processed and projected in: {crs_string}\n")
        feedback.setProgress(100)
        feedback.setProgressText("Processing Complete!\n")
    
    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message to the user after processing.

        Parameters:
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Feedback object to report progress.

        Returns:
            dict: Status of the post-processing.
        """
        
        # Display completion message using a custom dialog
        QCoreApplication.processEvents()
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("Glacier Surface Interpolation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec_()
        
        return super().postProcessAlgorithm(context, feedback)