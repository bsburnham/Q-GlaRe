"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D modified FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time
import numpy as np
import pandas as pd
from osgeo import gdal
import processing
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication 
from qgis.core import (QgsField,
                       QgsFields,
                       QgsProject,
                       QgsFeature,
                       QgsPointXY,
                       QgsGeometry,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsVectorLayer,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterField,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterBoolean,                   
                       QgsProcessingMultiStepFeedback,                       
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingFeatureSourceDefinition)

class ModifiedIceFlowThickness(QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for calculating glacier ice thickness.

    This tool reconstructs glacier ice thickness along flowlines using a 
    simplified equilibrium ice surface profile model (Benn and Hulton, 2010)
    and adapted by Pellitero et al., (2015). The calculation relies on 
    user-supplied DEM data, flowlines, and basal shear stress to estimate 
    ice thickness and surface elevation at regular intervals.

    Key Features:
    - Calculates ice thickness and surface elevation along flowlines.
    - Validates results using driving stress (50–200 kPa).
    - Outputs a vector layer with calculated ice thickness and elevation.

    Inputs:
    - DEM: Raster representing glacier basal topography.
    - Flowlines: Vector file of glacier flowlines.
    - Shear Stress: Basal shear stress (default: 100,000 Pa).
    - Interval: Point spacing along flowlines (default: 10 map units).

    Output:
    - A vector point layer with ice thickness, surface elevation, and attributes.

    References:
    - Benn, D.I., Hulton, N.R.J., 2010. An Excel™ spreadsheet program for 
      reconstructing the surface profile of former mountain glaciers and ice caps. 
      Computers & Geosciences, 36, pp. 605–610.
    - Nye, J.F., 1952. The Mechanics of Glacier Flow. Journal of Glaciology, 2, pp. 82–93.
    """

    input_precomputed = 'input_precomputed' 
    input_field = "input_field"
    new_value = "new_value"
    modify_values = "modify_values"

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return 'Ice Flow Thickness Modified'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """

        return '2. 2D modified FL Ice Thickness'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
        
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("1 Ice Flow Thickness", text)
    
    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)
     
    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """

        return self.tr(
            "A tool to re-calculate glacier ice thickness where values may "
             "have been adjusted manually for individual points. "
            "Only a vector point file previously generated from the 2D FL Ice Thickness Tool "
            "is required. A new ice thickness and surface elevation value will be computed. \n"
            "This tool is based on the equilibrium ice surface profile model developed by "
            "Nye (1952a, b) and adapted by Benn and Hulton (2010) to work with glacier "
            "basal topography and shear stress as inputs.\n\n"
            "References:\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of "
            "Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the "
            "Ice-Sheets. Nature 169, pp. 529–530.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program "
            "for reconstructing the surface profile of former mountain glaciers "
            "and ice caps. Computers & Geosciences 36, pp. 605–610.")

    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            IceFlowThickness: A new instance of the `IceFlowThickness` class.
        """
        return ModifiedIceFlowThickness()
    
    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'shear_stress.png') 
        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """
        
        self.addParameter(
        QgsProcessingParameterVectorLayer(
        self.input_precomputed,
        self.tr("\nSelect ice flow thickness (vector point file) to modify"),
        [QgsProcessing.TypeVectorPoint]))
        
        self.addParameter(
        QgsProcessingParameterBoolean(
        self.modify_values, 
        self.tr("\nModify selected point(s) field values (e.g., shear stress, elevation value)"),
        defaultValue=False,
        optional=True))

        self.addParameter(
        QgsProcessingParameterField(
        self.input_field,
        "\nData field to update",
        parentLayerParameterName=self.input_precomputed,
        type=QgsProcessingParameterField.Any))

        self.addParameter(
        QgsProcessingParameterNumber(
        self.new_value,
        "\nValue to update selected data field. Default value is 100,000",
        defaultValue="100000"))
        
    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Executes the algorithm and performs ice thickness reconstruction based on user inputs.
        """
        feedback = QgsProcessingMultiStepFeedback(9, model_feedback)
        results = {}

        # Preprocess inputs
        inputs = self.preprocess_inputs(parameters, context, feedback)
        input_layer = inputs["input_layer"]
        crs = inputs["crs"]
        crs_string = inputs["crs_string"]
        shear = inputs["shear"]  # Should be None when using precomputed points

        # Create a DataFrame from the (possibly modified) input layer
        flowline_points_df = self.create_dataframe(input_layer, None, feedback)

        # Remove the original layer from the project
        QgsProject.instance().removeMapLayer(input_layer.id())

        # Log initialization & pre-processing duration
        start_time = time.time()
        self.log_initialization(feedback, input_layer)
        self.log_initialization(feedback, input_layer, stage="input_processed")
        self.log_processing_duration("Pre-process input data", start_time)
        self.log_initialization(feedback, input_layer, stage="data_prep")
        self.log_processing_duration("Data processed for calculation", start_time)

        # Link tributary and centreline
        start_time = time.time()
        prox_id_df = self.calculate_prox_id_flow_based(flowline_points_df)
        self.log_initialization(feedback, input_layer, stage="tributary_centreline")
        self.log_processing_duration("Spatially linked tributary branches and centreline", start_time)

        # Estimate ice thickness and surface elevation
        start_time = time.time()
        reconstructed_df = self.ice_reconstruction(prox_id_df, shear=None)
        self.log_initialization(feedback, input_layer, stage="ice_calculation")
        self.log_processing_duration("Ice surface and thickness estimation", start_time)

        # Validate the estimates 
        start_time = time.time()
        validated_df, valid_percentage, invalid_points = self.validate_driving_stress(reconstructed_df)
        self.log_initialization(feedback, input_layer, stage="validation", 
                                valid_percentage=valid_percentage, invalid_points=invalid_points)
        self.log_processing_duration("Ice surface and thickness validation", start_time)

        # Load Results into QGIS
        start_time = time.time()
        self.load_dataframe_to_qgis(validated_df, crs, QgsProject.instance(),
                                    layer_name="2D FL Ice Thickness", feedback=feedback)
        self.log_initialization(feedback, input_layer, stage="load_qgis")
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", start_time)

        # Final logging
        self.log_final_results(feedback, crs_string, start_time)

        return {"Status": "Complete"}

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieve and optionally modify a precomputed layer for ice thickness reconstruction.

        This function:
        - Loads the input precomputed points layer.
        - Optionally updates selected features with a new value if the user has enabled `modify_values`.
        - Returns a dictionary containing the input layer, shear (None for precomputed), the layer's CRS,
            and the CRS string.

        Parameters:
            parameters (dict): Dictionary of user-supplied parameters for the algorithm.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): For logging messages and progress.

        Returns:
            dict: A dictionary with keys:
                - "input_layer" (QgsVectorLayer): The precomputed points layer.
                - "shear" (None): Basal shear stress is not used for precomputed data.
                - "crs" (QgsCoordinateReferenceSystem): The layer's CRS.
                - "crs_string" (str): AuthID of the layer's CRS, or 'Unknown CRS' if invalid.

        Raises:
            QgsProcessingException: If no features are selected when `modify_values` is enabled,
                                or if the input layer is invalid.
        """

        input_layer = self.parameterAsLayer(parameters, self.input_precomputed, context)
        shear = None  # Default for shear stress when precomputed points are used
        crs = input_layer.crs()
        crs_string = crs.authid() if crs.isValid() else 'Unknown CRS'

        # Check whether to modify values
        modify_values = self.parameterAsBoolean(parameters, self.modify_values, context)
        if modify_values:
            selected_features = input_layer.selectedFeatures()
            if not selected_features:
                raise QgsProcessingException("Input error: No points selected.\n\n"
                                            "Please select points to update.\n")

            feedback.pushInfo(f"Processing {len(selected_features)} selected points...")

            # Fallback: if the layer is not valid, attempt to fetch it from QgsProject
            if not input_layer or not input_layer.isValid():
                feedback.pushInfo("Attempting to fetch from QgsProject...")
                layer_def = parameters[self.input_layer]
                if isinstance(layer_def, QgsProcessingFeatureSourceDefinition):
                    layer_id = layer_def.source()
                elif isinstance(layer_def, str):
                    layer_id = layer_def
                else:
                    raise QgsProcessingException("Unexpected input layer type.")
                input_layer = QgsProject.instance().mapLayer(layer_id)
                if not input_layer or not input_layer.isValid():
                    raise QgsProcessingException("Invalid input layer. Ensure the layer is loaded and accessible.")

            # Start editing if needed
            if not input_layer.isEditable():
                feedback.pushInfo("Starting an editing session...")
                input_layer.startEditing()

            field_name = self.parameterAsString(parameters, self.input_field, context)
            new_value = self.parameterAsString(parameters, self.new_value, context)

            # Update each selected feature with the new value
            for feature in selected_features:
                try:
                    feature[field_name] = new_value
                    input_layer.updateFeature(feature)
                except Exception as e:
                    feedback.reportError(f"Failed to update feature {feature.id()}: {str(e)}")

            if not input_layer.commitChanges():
                raise QgsProcessingException("Failed to commit changes to the layer.")
            feedback.pushInfo(f"Successfully updated {len(selected_features)} features in field '{field_name}'.")

        return {
            "input_layer": input_layer,
            "shear": shear,
            "crs": crs,
            "crs_string": crs_string
        }

    def log_initialization(self, feedback, input_precomputed, stage=None, valid_percentage=None, invalid_points=None):
        """
        Log workflow messages to the QGIS feedback console, focusing on precomputed input data.

        This function:
        - Logs initial parameters if `stage` is None, including the name of the precomputed points layer.
        - Updates the progress text according to the current stage (e.g., "input_processed", "data_prep", "validation").
        - Optionally logs warnings if the percentage of valid points is below a threshold during validation.

        Parameters:
            feedback (QgsProcessingFeedback): The feedback object for logging messages.
            input_precomputed (QgsVectorLayer): The precomputed points layer being processed.
            stage (str, optional): Current processing stage. If None, logs initialization details.
            valid_percentage (float, optional): Percentage of valid points, used if `stage` == "validation".
            invalid_points (list, optional): Identifiers of invalid points, used if validation fails.

        Returns:
            None
        """


        if stage is None:
            # Log initialization details
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Re-Calculating 2D FL Ice Thickness Points")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - Input Points: {input_precomputed.name()}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText("Pre-processing input data...\n")
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "ice_calculation":
            feedback.setProgressText("Calculating ice surface and thickness...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 95:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushInfo(f"Invalid driving stress points (fid): {invalid_points}")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def log_processing_duration(self, process_name, start_time):
        """
        Log the duration of a specific processing step to the QGIS message log.

        This function:
        - Calculates the elapsed time since the provided start time.
        - Logs a message with the process name and elapsed duration.

        Parameters:
            process_name (str): The name of the process being logged.
            start_time (float): The start time of the process, as returned by time.time().

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"{process_name} completed in {duration:.4f} seconds", "2D Ice Flow Thickness Processing Log", level=3)

    def log_final_results(self, feedback, crs_string, start_time):
        """
        Log the final processing results to the QGIS message log, including duration and projection.

        This function:
        - Computes the total processing time since the provided start time.
        - Logs messages including the projection (CRS) and processing duration.
        - Updates the feedback object to indicate 100% progress and a completion message.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for reporting progress.
            crs_string (str): The CRS string of the processed data.
            start_time (float): The start time of the overall processing, as returned by time.time().

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"All data calculated in projection: {crs_string}", "2D FL Ice Thickness Processing Log", level=3)
        QgsMessageLog.logMessage("-----------------------------------------END PROCESS-----------------------------------------\n", 
                                "2D FL Ice Thickness Processing Log", level=0)
        feedback.pushInfo(f"All data processed in: {duration:.4f} seconds.\n")
        feedback.pushInfo(f"All data processed and projected in: {crs_string}\n")
        feedback.setProgress(100)
        feedback.setProgressText("Processing Complete!\n")

    def create_temp_layer_from_output(self, output_path, layer_name, feedback=None):
        """
        Create a temporary vector layer from a file path and add x/y coordinate attributes.

        This function:
        - Loads the file at the specified output path into a QgsVectorLayer.
        - Adds "xcoord" and "ycoord" fields to the layer.
        - Updates each feature with the corresponding point geometry's x and y coordinate values.

        Parameters:
            output_path (str): The file path to the vector data source.
            layer_name (str): The name to assign to the temporary layer.
            feedback (QgsProcessingFeedback, optional): For logging progress or notifications.

        Returns:
            QgsVectorLayer: The newly created vector layer with added "xcoord" and "ycoord" fields.

        Raises:
            ValueError: If the layer cannot be created from the specified path or is invalid.
        """

        # Load the layer from the output path
        temp_layer = QgsVectorLayer(output_path, layer_name, "ogr")

        if not temp_layer.isValid():
            raise ValueError(f"Failed to create layer: {layer_name} from path: {output_path}")

        # Add xcoord and ycoord fields
        temp_layer.dataProvider().addAttributes([QgsField('xcoord', QVariant.Double), QgsField('ycoord', QVariant.Double)])
        temp_layer.updateFields()  # Apply the added fields

        # Prepare bulk updates for features
        features = temp_layer.getFeatures()
        updates = {}

        for feature in features:
            geom = feature.geometry().asPoint()
            updates[feature.id()] = {'xcoord': geom.x(), 'ycoord': geom.y()}

        # Perform the bulk update
        temp_layer.dataProvider().changeAttributeValues(updates)

        return temp_layer
    
    def create_dataframe(self, temp_layer, attribute_names=None, feedback=None, user_shear=None):
        """
        Generate a Pandas DataFrame from a QGIS vector layer, optionally extracting specific attributes.

        This function:
        - Iterates over each feature in the provided vector layer.
        - Extracts specified attributes (or all if none specified) and the feature's x/y coordinates.
        - Optionally adds a "shear_stress" column if a shear value is provided.
        - Returns the data as a Pandas DataFrame.

        Parameters:
            temp_layer (QgsVectorLayer): The source vector layer.
            attribute_names (list, optional): List of attribute names to extract. If None, all fields are used.
            feedback (QgsProcessingFeedback, optional): Object for logging progress.
            user_shear (float, optional): A shear stress value to assign to all features.

        Returns:
            pd.DataFrame: A DataFrame containing the extracted attributes, xcoord, ycoord, and optional "shear_stress".
        """

        # Validate input layer
        if not isinstance(temp_layer, QgsVectorLayer):
            raise ValueError("Input must be a QgsVectorLayer.")

        data = []  # Container for feature data

        # Extract all fields if attribute_names is None
        if attribute_names is None:
            attribute_names = [field.name() for field in temp_layer.fields()]

        for feature in temp_layer.getFeatures():
            # Extract attributes
            row = {name: feature.attribute(name) for name in attribute_names}
            # Add geometry
            geom = feature.geometry().asPoint()
            row.update({'xcoord': geom.x(), 'ycoord': geom.y()})
            
            if user_shear is not None:
                row['shear_stress'] = user_shear
            
            data.append(row)

        # Convert to DataFrame
        return pd.DataFrame(data)

    def correct_distance_order(self, df):
        """
        Ensure that distance values for each flowline segment increase from smallest to largest.

        This function:
        - Resets the index of the DataFrame for unique integer indexing.
        - Groups the DataFrame by the 'cat' column representing flowline segments.
        - Checks if the 'distance' values in each group are in ascending order, and if they appear reversed,
        adjusts them accordingly.
        - Re-sorts and re-indexes the DataFrame by 'cat' and 'distance'.

        Parameters:
            df (pd.DataFrame): A DataFrame containing flowline segment data that must include columns 'cat' and 'distance'.

        Returns:
            pd.DataFrame: A corrected DataFrame where within each segment, the 'distance' values increase from smallest to largest.
        """

        # Reset index globally to ensure unique integer indices
        df = df.reset_index(drop=True)

        def fix_group(group):
            # Sort by 'distance' (in ascending order)
            group = group.sort_values('distance')
            
            if group['distance'].iloc[0] > group['distance'].iloc[-1]:
                d_min = group['distance'].min()
                d_max = group['distance'].max()
                group['distance'] = d_max + d_min - group['distance']
            return group

        # Group by 'cat' without resetting indices inside the function
        corrected_df = df.groupby('cat', group_keys=False).apply(fix_group)
        corrected_df = corrected_df.sort_values(['cat', 'distance']).reset_index(drop=True)
        
        return corrected_df
    
    def estimate_tributary_flow_direction(self, group_df):
        """
        Estimate the general flow direction of a tributary using multiple points along its flowline.

        This function:
        - Sorts the tributary points by distance to establish upstream-to-downstream order.
        - For short tributaries (< 3 points), calculates a simple start-to-end direction vector.
        - For longer tributaries, computes a weighted average of multiple flow segments for improved accuracy.
        - Normalizes the resulting vector to produce a unit direction vector.

        Parameters:
            group_df (pd.DataFrame): DataFrame containing points from a single tributary flowline with columns:
                - 'distance': Distance along the flowline.
                - 'xcoord', 'ycoord': Spatial coordinates of each point.

        Returns:
            np.ndarray: A normalized 2D unit vector representing the tributary's flow direction.
                    Returns [0, 1] as default if calculation fails.
        """

        # Sort by distance to get upstream -> downstream order
        sorted_group = group_df.sort_values('distance')
        
        if len(sorted_group) < 3:
            # Use simple start-to-end vector for short tributaries
            start = sorted_group.iloc[0]
            end = sorted_group.iloc[-1]
            flow_vector = np.array([end['xcoord'] - start['xcoord'], 
                                end['ycoord'] - start['ycoord']])
        else:
            # Use weighted average of multiple segments for better estimate
            vectors = []
            weights = []
            for i in range(len(sorted_group) - 1):
                p1 = sorted_group.iloc[i]
                p2 = sorted_group.iloc[i + 1]
                vector = np.array([p2['xcoord'] - p1['xcoord'], 
                                p2['ycoord'] - p1['ycoord']])
                distance = np.linalg.norm(vector)
                if distance > 0:
                    vectors.append(vector / distance)  # Normalize
                    weights.append(distance)
            
            if vectors:
                # Weighted average of unit vectors
                flow_vector = np.average(vectors, axis=0, weights=weights)
            else:
                return np.array([0, 1])  # Default downslope
        
        # Normalize
        norm = np.linalg.norm(flow_vector)
        return flow_vector / norm if norm > 0 else np.array([0, 1])
       
    def calculate_prox_id_flow_based(self, df):
        """
        Assign proximity-based identifiers using flow direction compatibility and glaciological constraints.

        This function:
        - Processes the main flowline first, setting the terminus point (minimum distance) to have no upstream connection.
        - For each tributary, estimates its flow direction and connects the first point to the most compatible downstream target.
        - Uses a cost function combining horizontal distance, elevation penalties, and flow direction alignment.
        - Chains subsequent tributary points to their preceding point within the same flowline segment.

        Parameters:
            df (pd.DataFrame): DataFrame containing flowline data with columns:
                - 'cat': Flowline category identifier (0 = main flowline).
                - 'distance': Distance along each flowline segment.
                - 'xcoord', 'ycoord': Spatial coordinates.
                - 'fid': Unique feature identifier.
                - 'rvalue1': DEM elevation values.

        Returns:
            pd.DataFrame: The updated DataFrame with an additional 'prox_id' column indicating downstream linkages
                        based on flow compatibility rather than simple distance-elevation ratios.
        """

        if not df.empty:
            df = self.correct_distance_order(df)

        df['prox_id'] = np.nan

        # Process main flowline first
        main_flow_cat = 0
        main_flowline = df[df['cat'] == main_flow_cat].sort_values('distance')
        if not main_flowline.empty:
            df.loc[main_flowline.index[0], 'prox_id'] = np.nan

        # Process each tributary
        for cat, group in df.groupby('cat'):
            if cat == main_flow_cat:
                continue
                
            group_sorted = group.sort_values('distance').copy()
            group_fids = group_sorted['fid'].values
            
            # Estimate flow direction for this tributary
            trib_flow_dir = self.estimate_tributary_flow_direction(group_sorted)

            for idx, (i, row) in enumerate(group_sorted.iterrows()):
                if idx == 0:
                    # Connection point: use flow compatibility
                    trib_point = np.array([row['xcoord'], row['ycoord']])
                    trib_elev = row['rvalue1']

                    # Consider all other flowlines as potential connections
                    potential_targets = df[df['cat'] != cat][['xcoord', 'ycoord', 'fid', 'rvalue1']]

                    if not potential_targets.empty:
                        candidates = potential_targets.to_numpy()
                        
                        # Calculate flow compatibility
                        flow_compatibility = self.calculate_flow_compatibility(
                            trib_point, trib_flow_dir, candidates)
                        
                        # Calculate elevation-based cost
                        elevation_cost = self.calculate_elevation_cost(
                            trib_elev, candidates[:, 3])
                        
                        # Calculate distance cost
                        distance_cost = np.sqrt((trib_point[0] - candidates[:, 0])**2 + 
                                            (trib_point[1] - candidates[:, 1])**2)
                        
                        # Combined cost prioritizing flow compatibility
                        total_cost = (distance_cost + 
                                    elevation_cost * 20 +  # Moderate elevation penalty
                                    flow_compatibility * 100)  # Strong flow penalty
                        
                        best_idx = np.argmin(total_cost)
                        df.at[row.name, 'prox_id'] = candidates[best_idx, 2]
                    else:
                        df.at[row.name, 'prox_id'] = np.nan
                else:
                    # Chain to previous point in same tributary
                    prev_fid = group_fids[idx - 1]
                    df.at[row.name, 'prox_id'] = prev_fid

        return df
    
    def calculate_flow_compatibility(self, trib_point, trib_flow_dir, candidates):
        """
        Calculate flow direction compatibility between a tributary point and potential connection targets.

        This function:
        - Computes unit vectors from the tributary point to each candidate connection point.
        - Calculates dot products between the tributary flow direction and connection vectors.
        - Converts alignment scores to cost values where lower costs indicate better flow compatibility.

        Parameters:
            trib_point (np.ndarray): 2D coordinates [x, y] of the tributary connection point.
            trib_flow_dir (np.ndarray): Normalized 2D unit vector representing tributary flow direction.
            candidates (np.ndarray): Array of candidate points with shape (n, 4) containing [x, y, fid, elevation].

        Returns:
            np.ndarray: Array of flow compatibility costs where 0 = perfect alignment, 2 = opposite direction.
                    Lower values indicate better glaciological flow compatibility.
        """
        # Vectors from tributary point to each candidate
        connection_vectors = candidates[:, :2] - trib_point
        distances = np.linalg.norm(connection_vectors, axis=1)
        
        # Avoid division by zero
        valid_mask = distances > 1e-6
        connection_vectors[valid_mask] /= distances[valid_mask, np.newaxis]
        
        # Dot product: 1 = same direction, -1 = opposite, 0 = perpendicular
        dot_products = np.dot(connection_vectors, trib_flow_dir)
        
        # Convert to cost: 0 = perfect alignment, 2 = opposite direction
        flow_cost = 1 - dot_products
        
        return flow_cost
    
    def calculate_elevation_cost(self, trib_elev, candidate_elevs):
        """
        Calculate elevation-based connection costs with glaciologically realistic penalties.

        This function:
        - Heavily penalizes uphill connections (ice cannot flow uphill).
        - Applies minimal penalties for downhill connections to allow natural glacier flow.
        - Uses asymmetric weighting to reflect physical constraints of ice flow dynamics.

        Parameters:
            trib_elev (float): Elevation of the tributary connection point.
            candidate_elevs (np.ndarray): Array of elevation values for potential connection targets.

        Returns:
            np.ndarray: Array of elevation-based costs where uphill connections receive 2x penalty
                    and extreme downhill connections receive 0.1x penalty.
        """
        elev_diff = candidate_elevs - trib_elev
        
        # Heavily penalize uphill connections, moderately penalize extreme downhill
        uphill_penalty = np.maximum(0, elev_diff) * 2  # 2x penalty for uphill
        downhill_penalty = np.maximum(0, -elev_diff) * 0.1  # Small penalty for downhill
        
        return uphill_penalty + downhill_penalty
    
    def ice_reconstruction(self, df, shear=None):
        """
        Compute ice thickness and reconstruct the ice surface for flowlines using a quadratic model.

        This function:
        - Processes the main flowline (points with no 'prox_id') sequentially to compute the ice surface.
        - Processes tributaries by inheriting the ice surface from a downstream confluence.
        - Calculates ice thickness as the difference between the reconstructed ice surface and the DEM value ('rvalue1'),
        ensuring that no negative thickness values are produced.
        
        Parameters:
            df (pd.DataFrame): DataFrame containing flowline data with columns: 'cat', 'xcoord', 'ycoord', 'rvalue1', 'prox_id', 'fid', 'shear_stress'.
            shear (float, optional): The constant basal shear stress value; if None, each point's 'shear_stress' is used.

        Returns:
            pd.DataFrame: The updated DataFrame with new columns 'ice_surface' and 'ice_thickness'.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81   # Gravitational acceleration (m/s2)

        # helper function to compute the next ice surface using the quadratic model.
        def compute_next_surface(prev_surface, r_prev, r_curr, d, local_shear):
            """
            Compute the next ice surface value using the quadratic model.
            """

            b = -(r_prev + r_curr)
            c = prev_surface * (r_curr - (prev_surface - r_prev)) - (2 * d * local_shear) / (rho * g)
            disc = b**2 - 4 * c
            if disc >= 0:
                return (-b + np.sqrt(disc)) / 2
            else:
                return r_curr

        # helper function to process a single flowline segment.
        def process_flowline_segment(segment_df, initial_surface=None):
            """
            Process a sorted flowline segment (main or tributary) to compute reconstructed ice surface values.

            This function:
            - Sorts the input DataFrame to replicate the original ordering.
            - Uses an optionally provided initial surface value, or defaults to the first point's DEM value ('rvalue1').
            - Iterates sequentially over the segment and computes the ice surface for each point using a quadratic model.
            - Uses the preceding computed ice surface value and the current point’s data (e.g., distance and shear stress) to calculate a new ice surface value via an external function (compute_next_surface).
            - Returns a mapping of each point's 'fid' to its computed ice surface value.

            Parameters:
                segment_df (pd.DataFrame): DataFrame representing a single flowline segment. It must include at least the columns:
                    - 'fid': Unique feature identifier.
                    - 'xcoord', 'ycoord': Spatial coordinates.
                    - 'rvalue1': DEM value used as a reference for the ice surface.
                    - 'shear_stress': Shear stress value for each point.
                initial_surface (float, optional): The initial ice surface elevation to assign to the first point.
                    If not provided, the first point's 'rvalue1' is used.

            Returns:
                dict: A dictionary mapping feature IDs (int) to the computed ice surface elevation (float) for the segment.
            """

            surface_map = {}
            seg = segment_df.sort_index().reset_index(drop=True)
            first = seg.iloc[0]
            init_surf = initial_surface if initial_surface is not None else first['rvalue1']
            surface_map[first['fid']] = init_surf
            prev_surface = init_surf
            # Process remaining points sequentially.
            for i in range(1, len(seg)):
                curr = seg.iloc[i]
                prev = seg.iloc[i - 1]
                dx = curr['xcoord'] - prev['xcoord']
                dy = curr['ycoord'] - prev['ycoord']
                d = np.sqrt(dx**2 + dy**2)
                local_shear = shear if shear is not None else curr['shear_stress']
                new_surface = compute_next_surface(prev_surface, prev['rvalue1'], curr['rvalue1'], d, local_shear)
                surface_map[curr['fid']] = new_surface
                prev_surface = new_surface
            return surface_map

        surface_dict = {}

        # Process main flowline
        main_mask = df['prox_id'].isna()
        main_flowline = df[main_mask].copy()
        if not main_flowline.empty:
            main_surfaces = process_flowline_segment(main_flowline)
            surface_dict.update(main_surfaces)

        # Process tributaries
        tributaries = df[~main_mask].copy()
        for cat, group in tributaries.groupby('cat'):
            group = group.copy().reset_index(drop=True)
            # The first point in the tributary (confluence) should inherit its ice surface from its
            # downstream connection via prox_id. If that is not available, use its own DEM value.
            confluence = group.iloc[0]
            prox_id = confluence['prox_id']
            if prox_id in surface_dict:
                init_surface = surface_dict[prox_id]
            else:
                init_surface = confluence['rvalue1']
            trib_surfaces = process_flowline_segment(group, initial_surface=init_surface)
            surface_dict.update(trib_surfaces)

        # Map the computed surfaces back to the DataFrame.
        df['ice_surface'] = df['fid'].map(surface_dict)
        df['ice_thickness'] = np.maximum(df['ice_surface'] - df['rvalue1'], 0)
        
        # Locate and replace zero ice thickness values using nearest neighbor approach
        df = self.replace_zero_thickness_with_nearest_neighbor(df)

        # ENSURE TERMINUS HAS ZERO ICE THICKNESS
        main_flow_cat = 0
        main_flowline = df[df['cat'] == main_flow_cat]

        if not main_flowline.empty:
            # Find terminus (minimum distance point on main flowline)
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            terminus_idx = terminus_row.name  # Get the DataFrame index
            
            # Force terminus to zero thickness
            df.at[terminus_idx, 'ice_thickness'] = 0
            df.at[terminus_idx, 'ice_surface'] = df.at[terminus_idx, 'rvalue1']
        
        return df
        
    def replace_zero_thickness_with_nearest_neighbor(self, df):
        """
        Replace zero ice thickness values using prox_id mapping and nearest neighbor search,
        but preserve zero thickness only at the true glacier terminus (end of main flowline).
        
        This function:
        - Identifies points with zero ice thickness.
        - Replaces zero values first by checking the thickness of the point referenced by 'prox_id'.
        - For any remaining zeros, performs a vectorized nearest neighbor search among points with non-zero thickness.
        - Preserves zero thickness at the true glacier terminus (minimum distance point on main flowline).
    
        Parameters:
            df (pd.DataFrame): DataFrame that includes 'fid', 'prox_id', 'ice_thickness', 'xcoord', and 'ycoord'.
        Returns:
            pd.DataFrame: The DataFrame with zero ice thickness values replaced by valid thickness values.
        """
        
        # Find the true terminus - point with minimum distance on main flowline
        main_flow_cat = 0
        main_flowline = df[df['cat'] == main_flow_cat]
        
        if not main_flowline.empty:
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            true_terminus_fid = terminus_row['fid']
        else:
            true_terminus_fid = None

        # Only replace zeros that are NOT at the true terminus
        if true_terminus_fid is not None:
            zero_mask = (df['ice_thickness'] == 0) & (df['fid'] != true_terminus_fid)
        else:
            zero_mask = (df['ice_thickness'] == 0)
            
        if not zero_mask.any():
            return df  # Nothing to replace.
            
        # Split the DataFrame into zero and non-zero thickness points.
        df_zero = df[zero_mask].copy()
        df_nonzero = df[df['ice_thickness'] != 0].copy()
        
        # Replace using prox_id if available.
        thickness_map = df.set_index('fid')['ice_thickness']
        df_zero['prox_thickness'] = df_zero['prox_id'].map(thickness_map)
        valid_prox = df_zero['prox_thickness'].notna() & (df_zero['prox_thickness'] > 0)
        df_zero.loc[valid_prox, 'ice_thickness'] = df_zero.loc[valid_prox, 'prox_thickness']
        
        # For remaining zeros, use vectorized nearest neighbor search.
        still_zero = (df_zero['ice_thickness'] == 0)
        if still_zero.any():
            zero_coords = df_zero.loc[still_zero, ['xcoord', 'ycoord']].to_numpy()
            nonzero_coords = df_nonzero[['xcoord', 'ycoord']].to_numpy()
            nonzero_thickness = df_nonzero['ice_thickness'].to_numpy()
        
            # Compute pairwise Euclidean distances.
            diff = zero_coords[:, np.newaxis, :] - nonzero_coords[np.newaxis, :, :]
            dists = np.sqrt(np.sum(diff**2, axis=2))
            nearest_idx = np.argmin(dists, axis=1)
            df_zero.loc[still_zero, 'ice_thickness'] = nonzero_thickness[nearest_idx]
            
        df_zero.drop(columns=['prox_thickness'], inplace=True)
        df.update(df_zero[['ice_thickness']])
    
        return df
    
    def validate_driving_stress(self, df):
        """
        Validate the computed ice thickness values using driving stress calculations.

        This function:
        - Estimates the local surface slope using differences in x/y coordinates and the reconstructed ice surface.
        - Computes the driving stress based on ice density, gravitational acceleration, ice thickness, and the sine of the slope.
        - Determines which points have driving stress values within the acceptable range (50 kPa to 200 kPa).
        - Returns the updated DataFrame, the percentage of points within range, and a list of invalid point IDs.

        Parameters:
            df (pd.DataFrame): Input DataFrame containing the columns "ice_thickness", "xcoord", "ycoord", and "ice_surface".

        Returns:
            tuple: A tuple consisting of:
                - (pd.DataFrame) The updated DataFrame with driving stress validation.
                - (float) The percentage of points with valid driving stress.
                - (list) A list of "fid" values for points with invalid driving stress.
        """

        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Calculate surface slope
        dx = df['xcoord'].diff().fillna(0) 
        dy = df['ycoord'].diff().fillna(0)  
        dz = df['ice_surface'].diff().fillna(0) 
        d = np.sqrt(dx**2 + dy**2 + 1e-6)  
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate driving stress
        driving_stress = rho * g * df['ice_thickness'] * np.sin(surface_slope)

        # Validate driving stress
        df['stress_valid'] = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        invalid_points = df.loc[~df['stress_valid'], 'fid'].tolist()  
        valid_points = df['stress_valid'].sum()
        total_points = len(df)
        valid_percentage = (valid_points / total_points) * 100

        # Clean up temporary columns
        df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')

        return df, valid_percentage, invalid_points

    def load_dataframe_to_qgis(self, dataframe, crs, project_instance, layer_name='DataFrameLayer', feedback=None):
        """
        Load a Pandas DataFrame into QGIS as a memory vector layer with point geometry.

        This function:
        - Converts numeric columns as needed.
        - Creates a QgsFields object to define attribute fields corresponding to the DataFrame columns.
        - Creates a memory vector layer with Point geometry in the specified CRS.
        - Inserts each row of the DataFrame as a feature with x and y coordinates.
        - Adds the created layer to the current QGIS project.

        Parameters:
            dataframe (pd.DataFrame): The DataFrame to load.
            crs (QgsCoordinateReferenceSystem): The coordinate reference system for the layer.
            project_instance (QgsProject): The current QGIS project.
            layer_name (str, optional): The name for the created layer (default is "DataFrameLayer").
            feedback (QgsProcessingFeedback, optional): Object for progress updates.

        Returns:
            None
        """


        # Create a QgsFields object to define the attribute fields
        fields = QgsFields()
        for column in dataframe.columns:
            field = QgsField(column, QVariant.Double)
            fields.append(field)

        # Create a memory vector layer
        vector_layer = QgsVectorLayer('Point?crs={}'.format(crs.authid()), layer_name, 'memory')
        vector_layer.dataProvider().addAttributes(fields)
        vector_layer.updateFields()
        
        # Add features to the memory vector layer
        features = []

        total_features = len(dataframe)
        current_feature = 0

        # Iterate over each row in the DataFrame
        for row in dataframe.itertuples(index=False):
            feature = QgsFeature(fields)
            x_coord = float(row.xcoord)
            y_coord = float(row.ycoord)
            geometry = QgsGeometry.fromPointXY(QgsPointXY(x_coord, y_coord))
            feature.setGeometry(geometry)

            # Set attributes for each field
            for column in dataframe.columns:
                # Convert the value to float before setting the attribute
                value = float(getattr(row, column))
                feature.setAttribute(column, value)

            features.append(feature)

            # Update progress
            current_feature += 1
            progress_percentage = int(current_feature / total_features * 100)
            if feedback:
                feedback.setProgress(progress_percentage)

            # Check for user cancellation
            if feedback and feedback.isCanceled():
                break

        vector_layer.dataProvider().addFeatures(features)

        # Add the memory vector layer to the map
        QgsProject.instance().addMapLayer(vector_layer)

    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message after processing and perform any necessary post-processing tasks.

        This function:
        - Creates and displays a QMessageBox with a completion message.
        - Sets the processing progress to 100% and updates the progress text.
        - Returns a dictionary indicating the status of post-processing.

        Parameters:
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): The feedback object for progress updates.

        Returns:
            dict: A dictionary reflecting the post-processing completion status.
        """

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("2D FL Ice Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec_()
        
        return super().postProcessAlgorithm(context, feedback)