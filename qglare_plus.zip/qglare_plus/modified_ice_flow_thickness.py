"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D modified FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time
import numpy as np
import pandas as pd
from osgeo import gdal
import processing
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication 
from qgis.core import (QgsField,
                       QgsFields,
                       QgsProject,
                       QgsFeature,
                       QgsPointXY,
                       QgsGeometry,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsVectorLayer,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterField,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterBoolean,                   
                       QgsProcessingMultiStepFeedback,                       
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingFeatureSourceDefinition)

class ModifiedIceFlowThickness(QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for calculating glacier ice thickness.

    This tool reconstructs glacier ice thickness along flowlines using a 
    simplified equilibrium ice surface profile model (Benn and Hulton, 2010)
    and adapted by Pellitero et al., (2015). The calculation relies on 
    user-supplied DEM data, flowlines, and basal shear stress to estimate 
    ice thickness and surface elevation at regular intervals.

    Key Features:
    - Calculates ice thickness and surface elevation along flowlines.
    - Validates results using driving stress (50–200 kPa).
    - Outputs a vector layer with calculated ice thickness and elevation.

    Inputs:
    - DEM: Raster representing glacier basal topography.
    - Flowlines: Vector file of glacier flowlines.
    - Shear Stress: Basal shear stress (default: 100,000 Pa).
    - Interval: Point spacing along flowlines (default: 10 map units).

    Output:
    - A vector point layer with ice thickness, surface elevation, and attributes.

    References:
    - Benn, D.I., Hulton, N.R.J., 2010. An Excel™ spreadsheet program for 
      reconstructing the surface profile of former mountain glaciers and ice caps. 
      Computers & Geosciences, 36, pp. 605–610.
    - Nye, J.F., 1952. The Mechanics of Glacier Flow. Journal of Glaciology, 2, pp. 82–93.
    """

    input_precomputed = 'input_precomputed' 
    input_field = "input_field"
    new_value = "new_value"
    modify_values = "modify_values"

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return 'Ice Flow Thickness Modified'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """

        return '2. 2D modified FL Ice Thickness'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
        
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("1 Ice Flow Thickness", text)
    
    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)
     
    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """

        return self.tr(
            "A tool to re-calculate glacier ice thickness where values may "
             "have been adjusted manually for individual points. "
            "Only a vector point file previously generated from the 2D FL Ice Thickness Tool "
            "is required. A new ice thickness and surface elevation value will be computed. \n"
            "This tool is based on the equilibrium ice surface profile model developed by "
            "Nye (1952a, b) and adapted by Benn and Hulton (2010) to work with glacier "
            "basal topography and shear stress as inputs.\n\n"
            "References:\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of "
            "Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the "
            "Ice-Sheets. Nature 169, pp. 529–530.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program "
            "for reconstructing the surface profile of former mountain glaciers "
            "and ice caps. Computers & Geosciences 36, pp. 605–610.")

    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            IceFlowThickness: A new instance of the `IceFlowThickness` class.
        """
        return ModifiedIceFlowThickness()
    
    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'shear_stress.png') 
        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """
        
        self.addParameter(
        QgsProcessingParameterVectorLayer(
        self.input_precomputed,
        self.tr("\nSelect ice flow thickness (vector point file) to modify"),
        [QgsProcessing.TypeVectorPoint]))
        
        self.addParameter(
        QgsProcessingParameterBoolean(
        self.modify_values, 
        self.tr("\nModify selected point(s) field values (e.g., shear stress, elevation value)"),
        defaultValue=False,
        optional=True))

        self.addParameter(
        QgsProcessingParameterField(
        self.input_field,
        "\nData field to update",
        parentLayerParameterName=self.input_precomputed,
        type=QgsProcessingParameterField.Any))

        self.addParameter(
        QgsProcessingParameterNumber(
        self.new_value,
        "\nValue to update selected data field. Default value is 100,000",
        defaultValue="100000"))
        
    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Executes the algorithm and performs ice thickness reconstruction based on user inputs.
        """
        feedback = QgsProcessingMultiStepFeedback(9, model_feedback)
        results = {}

        # Preprocess inputs
        inputs = self.preprocess_inputs(parameters, context, feedback)
        input_layer = inputs["input_layer"]
        crs = inputs["crs"]
        crs_string = inputs["crs_string"]
        shear = inputs["shear"]  # Should be None when using precomputed points

        # Create a DataFrame from the (possibly modified) input layer
        flowline_points_df = self.create_dataframe(input_layer, None, feedback)

        # Remove the original layer from the project
        QgsProject.instance().removeMapLayer(input_layer.id())

        # Log initialization & pre-processing duration
        start_time = time.time()
        self.log_initialization(feedback, input_layer)
        self.log_initialization(feedback, input_layer, stage="input_processed")
        self.log_processing_duration("Pre-process input data", start_time)
        self.log_initialization(feedback, input_layer, stage="data_prep")
        self.log_processing_duration("Data processed for calculation", start_time)

        # Link tributary and centreline
        start_time = time.time()
        prox_id_df = self.calculate_prox_id(flowline_points_df)
        self.log_initialization(feedback, input_layer, stage="tributary_centreline")
        self.log_processing_duration("Spatially linked tributary branches and centreline", start_time)

        # Estimate ice thickness and surface elevation
        start_time = time.time()
        reconstructed_df = self.ice_reconstruction(prox_id_df, shear=None)
        self.log_initialization(feedback, input_layer, stage="ice_calculation")
        self.log_processing_duration("Ice surface and thickness estimation", start_time)

        # Validate the estimates 
        start_time = time.time()
        validated_df, valid_percentage, invalid_points = self.validate_driving_stress(reconstructed_df)
        self.log_initialization(feedback, input_layer, stage="validation", 
                                valid_percentage=valid_percentage, invalid_points=invalid_points)
        self.log_processing_duration("Ice surface and thickness validation", start_time)

        # Load Results into QGIS
        start_time = time.time()
        self.load_dataframe_to_qgis(validated_df, crs, QgsProject.instance(),
                                    layer_name="2D FL Ice Thickness", feedback=feedback)
        self.log_initialization(feedback, input_layer, stage="load_qgis")
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", start_time)

        # Final logging
        self.log_final_results(feedback, crs_string, start_time)

        return {"Status": "Complete"}

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieve and optionally modify a precomputed layer for ice thickness reconstruction.

        This function:
        - Loads the input precomputed points layer.
        - Optionally updates selected features with a new value if the user has enabled `modify_values`.
        - Returns a dictionary containing the input layer, shear (None for precomputed), the layer's CRS,
            and the CRS string.

        Parameters:
            parameters (dict): Dictionary of user-supplied parameters for the algorithm.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): For logging messages and progress.

        Returns:
            dict: A dictionary with keys:
                - "input_layer" (QgsVectorLayer): The precomputed points layer.
                - "shear" (None): Basal shear stress is not used for precomputed data.
                - "crs" (QgsCoordinateReferenceSystem): The layer's CRS.
                - "crs_string" (str): AuthID of the layer's CRS, or 'Unknown CRS' if invalid.

        Raises:
            QgsProcessingException: If no features are selected when `modify_values` is enabled,
                                or if the input layer is invalid.
        """

        input_layer = self.parameterAsLayer(parameters, self.input_precomputed, context)
        shear = None  # Default for shear stress when precomputed points are used
        crs = input_layer.crs()
        crs_string = crs.authid() if crs.isValid() else 'Unknown CRS'

        # Check whether to modify values
        modify_values = self.parameterAsBoolean(parameters, self.modify_values, context)
        if modify_values:
            selected_features = input_layer.selectedFeatures()
            if not selected_features:
                raise QgsProcessingException("Input error: No points selected.\n\n"
                                            "Please select points to update.\n")

            feedback.pushInfo(f"Processing {len(selected_features)} selected points...")

            # Fallback: if the layer is not valid, attempt to fetch it from QgsProject
            if not input_layer or not input_layer.isValid():
                feedback.pushInfo("Attempting to fetch from QgsProject...")
                layer_def = parameters[self.input_layer]
                if isinstance(layer_def, QgsProcessingFeatureSourceDefinition):
                    layer_id = layer_def.source()
                elif isinstance(layer_def, str):
                    layer_id = layer_def
                else:
                    raise QgsProcessingException("Unexpected input layer type.")
                input_layer = QgsProject.instance().mapLayer(layer_id)
                if not input_layer or not input_layer.isValid():
                    raise QgsProcessingException("Invalid input layer. Ensure the layer is loaded and accessible.")

            # Start editing if needed
            if not input_layer.isEditable():
                feedback.pushInfo("Starting an editing session...")
                input_layer.startEditing()

            field_name = self.parameterAsString(parameters, self.input_field, context)
            new_value = self.parameterAsString(parameters, self.new_value, context)

            # Update each selected feature with the new value
            for feature in selected_features:
                try:
                    feature[field_name] = new_value
                    input_layer.updateFeature(feature)
                except Exception as e:
                    feedback.reportError(f"Failed to update feature {feature.id()}: {str(e)}")

            if not input_layer.commitChanges():
                raise QgsProcessingException("Failed to commit changes to the layer.")
            feedback.pushInfo(f"Successfully updated {len(selected_features)} features in field '{field_name}'.")

        return {
            "input_layer": input_layer,
            "shear": shear,
            "crs": crs,
            "crs_string": crs_string
        }

    def log_initialization(self, feedback, input_precomputed, stage=None, valid_percentage=None, invalid_points=None):
        """
        Log workflow messages to the QGIS feedback console, focusing on precomputed input data.

        This function:
        - Logs initial parameters if `stage` is None, including the name of the precomputed points layer.
        - Updates the progress text according to the current stage (e.g., "input_processed", "data_prep", "validation").
        - Optionally logs warnings if the percentage of valid points is below a threshold during validation.

        Parameters:
            feedback (QgsProcessingFeedback): The feedback object for logging messages.
            input_precomputed (QgsVectorLayer): The precomputed points layer being processed.
            stage (str, optional): Current processing stage. If None, logs initialization details.
            valid_percentage (float, optional): Percentage of valid points, used if `stage` == "validation".
            invalid_points (list, optional): Identifiers of invalid points, used if validation fails.

        Returns:
            None
        """


        if stage is None:
            # Log initialization details
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Re-Calculating 2D FL Ice Thickness Points")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - Input Points: {input_precomputed.name()}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText("Pre-processing input data...\n")
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "ice_calculation":
            feedback.setProgressText("Calculating ice surface and thickness...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 95:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushInfo(f"Invalid driving stress points (fid): {invalid_points}")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def log_processing_duration(self, process_name, start_time):
        """
        Log the duration of a specific processing step to the QGIS message log.

        This function:
        - Calculates the elapsed time since the provided start time.
        - Logs a message with the process name and elapsed duration.

        Parameters:
            process_name (str): The name of the process being logged.
            start_time (float): The start time of the process, as returned by time.time().

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"{process_name} completed in {duration:.4f} seconds", "2D Ice Flow Thickness Processing Log", level=3)

    def log_final_results(self, feedback, crs_string, start_time):
        """
        Log the final processing results to the QGIS message log, including duration and projection.

        This function:
        - Computes the total processing time since the provided start time.
        - Logs messages including the projection (CRS) and processing duration.
        - Updates the feedback object to indicate 100% progress and a completion message.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for reporting progress.
            crs_string (str): The CRS string of the processed data.
            start_time (float): The start time of the overall processing, as returned by time.time().

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"All data calculated in projection: {crs_string}", "2D FL Ice Thickness Processing Log", level=3)
        QgsMessageLog.logMessage("-----------------------------------------END PROCESS-----------------------------------------\n", 
                                "2D FL Ice Thickness Processing Log", level=0)
        feedback.pushInfo(f"All data processed in: {duration:.4f} seconds.\n")
        feedback.pushInfo(f"All data processed and projected in: {crs_string}\n")
        feedback.setProgress(100)
        feedback.setProgressText("Processing Complete!\n")

    def create_temp_layer_from_output(self, output_path, layer_name, feedback=None):
        """
        Create a temporary vector layer from a file path and add x/y coordinate attributes.

        This function:
        - Loads the file at the specified output path into a QgsVectorLayer.
        - Adds "xcoord" and "ycoord" fields to the layer.
        - Updates each feature with the corresponding point geometry's x and y coordinate values.

        Parameters:
            output_path (str): The file path to the vector data source.
            layer_name (str): The name to assign to the temporary layer.
            feedback (QgsProcessingFeedback, optional): For logging progress or notifications.

        Returns:
            QgsVectorLayer: The newly created vector layer with added "xcoord" and "ycoord" fields.

        Raises:
            ValueError: If the layer cannot be created from the specified path or is invalid.
        """

        # Load the layer from the output path
        temp_layer = QgsVectorLayer(output_path, layer_name, "ogr")

        if not temp_layer.isValid():
            raise ValueError(f"Failed to create layer: {layer_name} from path: {output_path}")

        # Add xcoord and ycoord fields
        temp_layer.dataProvider().addAttributes([QgsField('xcoord', QVariant.Double), QgsField('ycoord', QVariant.Double)])
        temp_layer.updateFields()  # Apply the added fields

        # Prepare bulk updates for features
        features = temp_layer.getFeatures()
        updates = {}

        for feature in features:
            geom = feature.geometry().asPoint()
            updates[feature.id()] = {'xcoord': geom.x(), 'ycoord': geom.y()}

        # Perform the bulk update
        temp_layer.dataProvider().changeAttributeValues(updates)

        return temp_layer
    
    def create_dataframe(self, temp_layer, attribute_names=None, feedback=None, user_shear=None):
        """
        Generate a Pandas DataFrame from a QGIS vector layer, optionally extracting specific attributes.

        This function:
        - Iterates over each feature in the provided vector layer.
        - Extracts specified attributes (or all if none specified) and the feature's x/y coordinates.
        - Optionally adds a "shear_stress" column if a shear value is provided.
        - Returns the data as a Pandas DataFrame.

        Parameters:
            temp_layer (QgsVectorLayer): The source vector layer.
            attribute_names (list, optional): List of attribute names to extract. If None, all fields are used.
            feedback (QgsProcessingFeedback, optional): Object for logging progress.
            user_shear (float, optional): A shear stress value to assign to all features.

        Returns:
            pd.DataFrame: A DataFrame containing the extracted attributes, xcoord, ycoord, and optional "shear_stress".
        """

        # Validate input layer
        if not isinstance(temp_layer, QgsVectorLayer):
            raise ValueError("Input must be a QgsVectorLayer.")

        data = []  # Container for feature data

        # Extract all fields if attribute_names is None
        if attribute_names is None:
            attribute_names = [field.name() for field in temp_layer.fields()]

        for feature in temp_layer.getFeatures():
            # Extract attributes
            row = {name: feature.attribute(name) for name in attribute_names}
            # Add geometry
            geom = feature.geometry().asPoint()
            row.update({'xcoord': geom.x(), 'ycoord': geom.y()})
            
            if user_shear is not None:
                row['shear_stress'] = user_shear
            
            data.append(row)

        # Convert to DataFrame
        return pd.DataFrame(data)

    def correct_distance_order(self, df):
        """
        Ensure that within each flowline segment, the point with the smallest distance also has the lowest elevation.

        This function:
        - Groups the input DataFrame by the "cat" column.
        - For each group, checks if the ordering of "distance" values matches the ordering of "rvalue1" (elevation).
        - If not, reverses the distances within the group to enforce proper ordering.
        - Returns the updated DataFrame with corrected "distance" values.

        Parameters:
            df (pd.DataFrame): DataFrame containing at least the columns "cat", "distance", and "rvalue1".

        Returns:
            pd.DataFrame: The updated DataFrame with corrected distance ordering within each group.
        """


        def fix_group(group):
            # Identify the index with the minimum 'distance'
            min_dist_idx = group['distance'].idxmin()
            # Identify the index with the lowest elevation
            min_elev_idx = group['rvalue1'].idxmin()
            # If these don't match, assume ordering is reversed and reflect the distances.
            if min_dist_idx != min_elev_idx:
                d_min = group['distance'].min()
                d_max = group['distance'].max()
                group['distance'] = d_max + d_min - group['distance']
            return group

        corrected_df = df.groupby('cat', group_keys=False).apply(fix_group)
        return corrected_df

    def calculate_prox_id(self, df):
        """
        Calculate proximity identifiers ("prox_id") for flowline points using a weighted cost approach.

        This function:
        - Corrects the ordering of "distance" values within flowline segments.
        - Initializes a "prox_id" column in the DataFrame.
        - For each flowline segment, assigns each point a prox_id based on its nearest valid downstream connection or the previous point.
        - Returns the updated DataFrame including the new "prox_id" column.

        Parameters:
            df (pd.DataFrame): DataFrame with columns including "cat", "xcoord", "ycoord", "fid", "rvalue1", and "distance".

        Returns:
            pd.DataFrame: The updated DataFrame with a new "prox_id" column.
        """
        
        # 1 m elevation gain equivalent to 10 m horizontal distance
        weight = 10.0

        # Check and correct the ordering of 'distance' values per flowline segment,
        if not df.empty:
            df = self.correct_distance_order(df)

        # Initialize prox_id
        df['prox_id'] = np.nan

        # Process main flowline: For cat==0, first point gets prox_id = NaN
        main_flow_cat = 0
        main_flowline = df[df['cat'] == main_flow_cat].sort_values('distance')
        if not main_flowline.empty:
            df.loc[main_flowline.index[0], 'prox_id'] = np.nan

        # Process each flowline segment (cat)
        for cat, group in df.groupby('cat'):
            group_sorted = group.sort_values('distance').copy()
            group_fids = group_sorted['fid'].values

            for idx, (i, row) in enumerate(group_sorted.iterrows()):
                if idx == 0:
                    if cat == main_flow_cat:
                        continue 

                    trib_point = np.array([row['xcoord'], row['ycoord']])
                    trib_elev = row['rvalue1']

                    # Consider candidates from other flowlines (cat != current cat)
                    potential_downstream = df[df['cat'] != cat][['xcoord', 'ycoord', 'fid', 'rvalue1']]

                    if not potential_downstream.empty:
                        candidates = potential_downstream.to_numpy()  # each row: x, y, fid, candidate_rvalue1

                        # Compute horizontal distances
                        dists = np.sqrt((trib_point[0] - candidates[:, 0])**2 + (trib_point[1] - candidates[:, 1])**2)
                        elev_diff = candidates[:, 3] - trib_elev
                        penalty = np.maximum(0, elev_diff)
                        # Compute weighted cost
                        cost = dists + weight * penalty
                        nearest_idx = np.argmin(cost)
                        df.at[row.name, 'prox_id'] = candidates[nearest_idx, 2]
                    else:
                        df.at[row.name, 'prox_id'] = np.nan
                else:
                    # Assign the prox_id of the previous point in this flowline
                    prev_fid = group_fids[idx - 1]
                    df.at[row.name, 'prox_id'] = prev_fid

        return df
    
    def ice_reconstruction(self, df, shear=None):
        """
        Reconstruct the glacier ice surface and compute ice thickness using a quadratic model.

        This function:
        - Processes the main flowline (points with no "prox_id") sequentially.
        - Processes each tributary by inheriting the ice surface value from its confluence (via "prox_id")
        and then propagating upstream.
        - Calculates ice thickness as the difference between the reconstructed ice surface and the DEM value ("rvalue1"),
        ensuring that thickness values are non-negative.
        - Returns the updated DataFrame with new columns "ice_surface" and "ice_thickness".

        Parameters:
            df (pd.DataFrame): Input DataFrame containing at least the columns:
                ["cat", "xcoord", "ycoord", "rvalue1", "prox_id", "fid", "shear_stress"].
            shear (float, optional): A constant basal shear stress value; if None, each row's "shear_stress" is used.

        Returns:
            pd.DataFrame: The DataFrame augmented with "ice_surface" and "ice_thickness" columns.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81   # Gravitational acceleration (m/s2)

        # Internal helper to compute the next ice surface using the quadratic model.
        def compute_next_surface(prev_surface, r_prev, r_curr, d, local_shear):
            """
            Compute the next ice surface value using the quadratic model.
            
            This function uses the quadratic equation derived from the ice flow model:
                b = -(r_prev + r_curr)
                c = prev_surface * (r_curr - (prev_surface - r_prev)) - (2*d*local_shear)/(rho*g)
            
            If the discriminant (b^2 - 4*c) is non-negative, returns:
                (-b + sqrt(discriminant)) / 2
            Otherwise, returns the current DEM value r_curr.
            """
            b = -(r_prev + r_curr)
            c = prev_surface * (r_curr - (prev_surface - r_prev)) - (2 * d * local_shear) / (rho * g)
            disc = b**2 - 4 * c
            if disc >= 0:
                return (-b + np.sqrt(disc)) / 2
            else:
                return r_curr

        # Internal helper to process a single flowline segment.
        def process_flowline_segment(segment_df, initial_surface=None):
            """
            Process a sorted flowline segment (main or tributary) sequentially.
            
            The first point is assigned an ice surface equal to initial_surface
            (if provided) or its DEM value (rvalue1). Then, each subsequent point 
            ice surface is computed using the quadratic model.
            
            Returns:
                dict: A mapping from fid to the computed ice surface.
            """
            surface_map = {}
            seg = segment_df.sort_index().reset_index(drop=True)
            first = seg.iloc[0]
            init_surf = initial_surface if initial_surface is not None else first['rvalue1']
            surface_map[first['fid']] = init_surf
            prev_surface = init_surf
            # Process remaining points sequentially.
            for i in range(1, len(seg)):
                curr = seg.iloc[i]
                prev = seg.iloc[i - 1]
                dx = curr['xcoord'] - prev['xcoord']
                dy = curr['ycoord'] - prev['ycoord']
                d = np.sqrt(dx**2 + dy**2)
                local_shear = shear if shear is not None else curr['shear_stress']
                new_surface = compute_next_surface(prev_surface, prev['rvalue1'], curr['rvalue1'], d, local_shear)
                surface_map[curr['fid']] = new_surface
                prev_surface = new_surface
            return surface_map

        surface_dict = {}

        # Process main flowline
        main_mask = df['prox_id'].isna()
        main_flowline = df[main_mask].copy()
        if not main_flowline.empty:
            main_surfaces = process_flowline_segment(main_flowline)
            surface_dict.update(main_surfaces)

        # Process tributaries
        tributaries = df[~main_mask].copy()
        for cat, group in tributaries.groupby('cat'):
            group = group.copy().reset_index(drop=True)
            # The first point in the tributary (confluence) should inherit its ice surface from its
            # downstream connection via prox_id. If that is not available, use its own DEM value.
            confluence = group.iloc[0]
            prox_id = confluence['prox_id']
            if prox_id in surface_dict:
                init_surface = surface_dict[prox_id]
            else:
                init_surface = confluence['rvalue1']
            trib_surfaces = process_flowline_segment(group, initial_surface=init_surface)
            surface_dict.update(trib_surfaces)

        # Map the computed surfaces back to the DataFrame.
        df['ice_surface'] = df['fid'].map(surface_dict)
        df['ice_thickness'] = np.maximum(df['ice_surface'] - df['rvalue1'], 0)
        
        # Locate and replace zero ice thickness values using nearest neighbor approach
        df = self.replace_zero_thickness_with_nearest_neighbor(df)
        
        return df

    def replace_zero_thickness_with_nearest_neighbor(self, df):
        """
        Replace zero ice thickness values in the DataFrame using prox_id and a nearest neighbor search.

        This function:
        - Identifies points with zero ice thickness.
        - Attempts to replace zero values first by mapping each point's prox_id to its corresponding thickness.
        - For any remaining zero values, performs a vectorized nearest neighbor search (using Euclidean distance)
        among points with non-zero thickness and replaces them.
        - Returns the updated DataFrame with zero thickness values replaced by valid values.

        Parameters:
            df (pd.DataFrame): DataFrame containing at least the columns "fid", "prox_id", "ice_thickness", "xcoord", and "ycoord".

        Returns:
            pd.DataFrame: The updated DataFrame with zero ice thickness values replaced.
        """

        # Identify rows with zero ice_thickness.
        zero_mask = (df['ice_thickness'] == 0)
        if not zero_mask.any():
            return df  # Nothing to replace.

        # Split the DataFrame into zero and non-zero thickness points.
        df_zero = df[zero_mask].copy()
        df_nonzero = df[df['ice_thickness'] != 0].copy()

        # Replace using prox_id if available.
        thickness_map = df.set_index('fid')['ice_thickness']
        df_zero['prox_thickness'] = df_zero['prox_id'].map(thickness_map)
        valid_prox = df_zero['prox_thickness'].notna() & (df_zero['prox_thickness'] > 0)
        df_zero.loc[valid_prox, 'ice_thickness'] = df_zero.loc[valid_prox, 'prox_thickness']

        # For remaining zeros, use vectorized nearest neighbor search.
        still_zero = (df_zero['ice_thickness'] == 0)
        if still_zero.any():
            zero_coords = df_zero.loc[still_zero, ['xcoord', 'ycoord']].to_numpy()
            nonzero_coords = df_nonzero[['xcoord', 'ycoord']].to_numpy()
            nonzero_thickness = df_nonzero['ice_thickness'].to_numpy()
            
            # Compute pairwise Euclidean distances.
            diff = zero_coords[:, np.newaxis, :] - nonzero_coords[np.newaxis, :, :]
            dists = np.sqrt(np.sum(diff**2, axis=2))
            nearest_idx = np.argmin(dists, axis=1)
            df_zero.loc[still_zero, 'ice_thickness'] = nonzero_thickness[nearest_idx]

        df_zero.drop(columns=['prox_thickness'], inplace=True)
        df.update(df_zero[['ice_thickness']])
        
        return df
    
    def validate_driving_stress(self, df):
        """
        Validate the computed ice thickness values using driving stress calculations.

        This function:
        - Estimates the local surface slope using differences in x/y coordinates and the reconstructed ice surface.
        - Computes the driving stress based on ice density, gravitational acceleration, ice thickness, and the sine of the slope.
        - Determines which points have driving stress values within the acceptable range (50 kPa to 200 kPa).
        - Returns the updated DataFrame, the percentage of points within range, and a list of invalid point IDs.

        Parameters:
            df (pd.DataFrame): Input DataFrame containing the columns "ice_thickness", "xcoord", "ycoord", and "ice_surface".

        Returns:
            tuple: A tuple consisting of:
                - (pd.DataFrame) The updated DataFrame with driving stress validation.
                - (float) The percentage of points with valid driving stress.
                - (list) A list of "fid" values for points with invalid driving stress.
        """

        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Calculate surface slope
        dx = df['xcoord'].diff().fillna(0) 
        dy = df['ycoord'].diff().fillna(0)  
        dz = df['ice_surface'].diff().fillna(0) 
        d = np.sqrt(dx**2 + dy**2 + 1e-6)  
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate driving stress
        driving_stress = rho * g * df['ice_thickness'] * np.sin(surface_slope)

        # Validate driving stress
        df['stress_valid'] = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        invalid_points = df.loc[~df['stress_valid'], 'fid'].tolist()  
        valid_points = df['stress_valid'].sum()
        total_points = len(df)
        valid_percentage = (valid_points / total_points) * 100

        # Clean up temporary columns
        df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')

        return df, valid_percentage, invalid_points

    def load_dataframe_to_qgis(self, dataframe, crs, project_instance, layer_name='DataFrameLayer', feedback=None):
        """
        Load a Pandas DataFrame into QGIS as a memory vector layer with point geometry.

        This function:
        - Converts numeric columns as needed.
        - Creates a QgsFields object to define attribute fields corresponding to the DataFrame columns.
        - Creates a memory vector layer with Point geometry in the specified CRS.
        - Inserts each row of the DataFrame as a feature with x and y coordinates.
        - Adds the created layer to the current QGIS project.

        Parameters:
            dataframe (pd.DataFrame): The DataFrame to load.
            crs (QgsCoordinateReferenceSystem): The coordinate reference system for the layer.
            project_instance (QgsProject): The current QGIS project.
            layer_name (str, optional): The name for the created layer (default is "DataFrameLayer").
            feedback (QgsProcessingFeedback, optional): Object for progress updates.

        Returns:
            None
        """


        # Create a QgsFields object to define the attribute fields
        fields = QgsFields()
        for column in dataframe.columns:
            field = QgsField(column, QVariant.Double)
            fields.append(field)

        # Create a memory vector layer
        vector_layer = QgsVectorLayer('Point?crs={}'.format(crs.authid()), layer_name, 'memory')
        vector_layer.dataProvider().addAttributes(fields)
        vector_layer.updateFields()
        
        # Add features to the memory vector layer
        features = []

        total_features = len(dataframe)
        current_feature = 0

        # Iterate over each row in the DataFrame
        for row in dataframe.itertuples(index=False):
            feature = QgsFeature(fields)
            x_coord = float(row.xcoord)
            y_coord = float(row.ycoord)
            geometry = QgsGeometry.fromPointXY(QgsPointXY(x_coord, y_coord))
            feature.setGeometry(geometry)

            # Set attributes for each field
            for column in dataframe.columns:
                # Convert the value to float before setting the attribute
                value = float(getattr(row, column))
                feature.setAttribute(column, value)

            features.append(feature)

            # Update progress
            current_feature += 1
            progress_percentage = int(current_feature / total_features * 100)
            if feedback:
                feedback.setProgress(progress_percentage)

            # Check for user cancellation
            if feedback and feedback.isCanceled():
                break

        vector_layer.dataProvider().addFeatures(features)

        # Add the memory vector layer to the map
        QgsProject.instance().addMapLayer(vector_layer)

    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message after processing and perform any necessary post-processing tasks.

        This function:
        - Creates and displays a QMessageBox with a completion message.
        - Sets the processing progress to 100% and updates the progress text.
        - Returns a dictionary indicating the status of post-processing.

        Parameters:
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): The feedback object for progress updates.

        Returns:
            dict: A dictionary reflecting the post-processing completion status.
        """

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("2D FL Ice Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec_()
        
        return super().postProcessAlgorithm(context, feedback)