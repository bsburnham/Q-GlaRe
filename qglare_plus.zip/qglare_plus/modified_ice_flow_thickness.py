"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D modified FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, traceback
from .qglare_base import QGlaReAlgorithmMixin
from .qglare_utils import normalise_shapefile_field_names
import numpy as np
import pandas as pd
from osgeo import gdal
import processing
from qgis.PyQt.QtCore import QVariant, QMetaType, QUrl
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication 
from qgis.core import (Qgis,
                       QgsField,
                       QgsFields,
                       QgsProject,
                       QgsFeature,
                       QgsPointXY,
                       QgsGeometry,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsRasterLayer,
                       QgsVectorLayer,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterField,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterBoolean,                   
                       QgsProcessingMultiStepFeedback,                       
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingFeatureSourceDefinition)

# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_VECTOR_POINT = Qgis.ProcessingSourceType.VectorPoint
except AttributeError:                          # QGIS < 3.36
    _SOURCE_VECTOR_POINT = QgsProcessing.TypeVectorPoint

# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38 -
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
_FIELD_DOUBLE = QMetaType.Type.Double if Qgis.QGIS_VERSION_INT >= 33800 else QVariant.Double

class ModifiedIceFlowThickness(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """Reconstruct glacier ice thickness from precomputed flowline points.

    Recomputes the equilibrium ice surface and thickness (Nye 1952; Benn and
    Hulton 2010, adapted by Pellitero et al. 2015) from a points layer produced by
    the 2D FL Ice Thickness tool, so individual point values (for example shear
    stress) can be edited and the reconstruction re-run.

    References:
        Nye, J.F., 1952. The mechanics of glacier flow. Journal of Glaciology 2,
            82–93.
        Benn, D.I., Hulton, N.R.J., 2010. An Excel spreadsheet program for
            reconstructing the surface profile of former mountain glaciers and
            ice caps. Computers & Geosciences 36, 605–610.
    """

    N_STEPS = 9
    _log_tag = '2D FL Ice Thickness Processing Log'

    input_precomputed = 'input_precomputed'
    input_field = "input_field"
    new_value = "new_value"
    modify_values = "modify_values"

    def name(self):
        """Internal algorithm id used by QGIS."""

        return 'Ice Flow Thickness Modified'

    def displayName(self):
        """Name shown in the QGIS toolbox."""

        return '2. 2D modified FL Ice Thickness'

    def group(self):
        """Toolbox group this algorithm sits under."""

        return '\u200aQ-GlaRe'

    def groupId(self):
        """Unique id of the toolbox group."""

        return '1_q-glare'
        
    def tr(self, text):
        """Translate a string through Qt's localisation."""

        return QCoreApplication.translate("1 Ice Flow Thickness", text)
    
    def setProgressText(self, text):
        """Print progress text when running outside the QGIS console."""

        print(text)
     
    def shortHelpString(self):
        """Help-panel text for the toolbox, with the tool icon as an HTML header."""

        # Add the tool icon to the top of the help text (rendered as HTML).
        icon_url = QUrl.fromLocalFile(
            os.path.join(os.path.dirname(__file__), 'icons', 'shear_stress.png')).toString()
        header = ('<img src="%s" width="28" height="27"/>&nbsp;&nbsp;'
                  '<b>2D modified FL ice thickness</b>\n\n' % icon_url)

        return header + self.tr(
            "A tool to re-calculate glacier ice thickness where values may "
             "have been adjusted manually for individual points. "
            "Only a vector point file previously generated from the 2D FL Ice Thickness Tool "
            "is required. A new ice thickness and surface elevation value will be computed. \n"
            "This tool is based on the equilibrium ice surface profile model developed by "
            "Nye (1952a, b) and adapted by Benn and Hulton (2010) to work with glacier "
            "basal topography and shear stress as inputs.\n\n"
            "<b>References:</b>\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of "
            "Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the "
            "Ice-Sheets. Nature 169, pp. 529–530.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program "
            "for reconstructing the surface profile of former mountain glaciers "
            "and ice caps. Computers & Geosciences 36, pp. 605–610.")

    def createInstance(self):
        """Return a fresh instance for QGIS to run."""
        return ModifiedIceFlowThickness()

    def createCustomParametersWidget(self, parent=None):
        """
        Build the tool dialog with the icon at the top and the inputs grouped into
        collapsible sections. Falls back to the standard dialog if it cannot be built.
        """
        try:
            from .grouped_dialog import build_grouped_dialog, truthy
            DialogCls = build_grouped_dialog(
                os.path.dirname(__file__), "shear_stress.png", "Modified ice thickness",
                sections=[
                    ("Inputs", False, [
                        "input_precomputed", "modify_values", "input_field", "new_value"]),
                ],
                conditionals=[
                    ("input_field", "modify_values", truthy),
                    ("new_value", "modify_values", truthy),
                ])
            return DialogCls(self, parent=parent)
        except Exception:
            return None
    
    def icon(self):
        """Toolbox icon for this algorithm."""
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'shear_stress.png') 
        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """Define the input parameters: the precomputed points layer and the optional field edit."""
        
        self.addParameter(
        QgsProcessingParameterVectorLayer(
        self.input_precomputed,
        self.tr("\nSelect ice flow thickness (vector point file) to modify"),
        [_SOURCE_VECTOR_POINT]))
        
        self.addParameter(
        QgsProcessingParameterBoolean(
        self.modify_values, 
        self.tr("\nModify selected point(s) field values (e.g., shear stress, elevation value)"),
        defaultValue=False,
        optional=True))

        self.addParameter(
        QgsProcessingParameterField(
        self.input_field,
        "\nData field to update",
        parentLayerParameterName=self.input_precomputed,
        type=QgsProcessingParameterField.Any))

        self.addParameter(
        QgsProcessingParameterNumber(
        self.new_value,
        "\nValue to update selected data field. Default value is 100,000",
        defaultValue="100000"))
        
    def processAlgorithm(self, parameters, context, model_feedback):
        """Re-run the ice thickness reconstruction on an existing points layer."""
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)

        try:
            self._init_logger('modified_ice_flow_thickness', feedback)

            # Preprocess inputs
            inputs = self.preprocess_inputs(parameters, context, feedback)
            input_layer = inputs["input_layer"]
            crs = inputs["crs"]
            crs_string = inputs["crs_string"]
            shear = inputs["shear"]  # Should be None when using precomputed points

            # Create a DataFrame from the (possibly modified) input layer
            flowline_points_df = self.create_dataframe(input_layer, None, feedback, include_geometry=True)
            flowline_points_df = normalise_shapefile_field_names(flowline_points_df)

            # Log initialisation & pre-processing duration
            glob_start_time = time.time()
            self.log_initialization(feedback, input_layer)
            self._log_run_header({
                'Input Points': f"{input_layer.name()} ({input_layer.source()})",
                'CRS':          crs_string,
            })
            self._log_layer_crs([
                ('Input Points', input_layer),
            ])
            self.log_initialization(feedback, input_layer, stage="input_processed")
            self.log_initialization(feedback, input_layer, stage="data_prep")
            self.log_processing_duration("Data processed for calculation", glob_start_time)

            # Link tributary and centreline
            start_time = time.time()
            prox_id_df = self.calculate_prox_id_flow_based(flowline_points_df, feedback)
            self.log_initialization(feedback, input_layer, stage="tributary_centreline")
            self.log_processing_duration("Spatially linked tributary branches and centreline", start_time)

            # Estimate ice thickness and surface elevation
            start_time = time.time()
            reconstructed_df = self.ice_reconstruction(prox_id_df, shear=None, feedback=feedback)
            self.log_initialization(feedback, input_layer, stage="ice_calculation")
            self.log_processing_duration("Ice surface and thickness estimation", start_time)

            # Validate the estimates
            start_time = time.time()
            validated_df, valid_percentage, invalid_points = self.validate_driving_stress(reconstructed_df)
            self.log_initialization(feedback, input_layer, stage="validation",
                                    valid_percentage=valid_percentage, invalid_points=invalid_points)
            self.log_processing_duration("Ice surface and thickness validation", start_time)

            # Load Results into QGIS
            start_time = time.time()
            self.load_dataframe_to_qgis(validated_df, crs, context,
                                        layer_name="2D FL Ice Thickness", feedback=feedback,
                                        group_name="Q-GlaRe Ice Thickness Points")
            self.log_initialization(feedback, input_layer, stage="load_qgis")
            self.log_processing_duration("Ice flow thickness points loaded into QGIS", start_time)

            # Final logging
            self.log_final_results(feedback, crs_string, glob_start_time)
            self._log_success(feedback)
            return {"Status": "Complete"}

        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )

    def preprocess_inputs(self, parameters, context, feedback):
        """Load the precomputed points layer and optionally edit a field first.

        When 'modify_values' is set, writes 'new_value' into the chosen field for
        the currently selected features (committing an edit session it opened) and
        raises if nothing is selected. Shear is None here; each point carries its
        own. Returns the layer and CRS details in a dict.
        """

        input_layer = self.parameterAsLayer(parameters, self.input_precomputed, context)
        if input_layer is None or not input_layer.isValid():
            raise QgsProcessingException(
                "The precomputed ice thickness points layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        shear = None  # Default for shear stress when precomputed points are used
        crs = input_layer.crs()
        crs_string = crs.authid() if crs.isValid() else 'Unknown CRS'

        # Validate that input layer uses projected CRS
        self.validate_projected_crs(input_layer, feedback) 

        # Check whether to modify values
        modify_values = self.parameterAsBoolean(parameters, self.modify_values, context)
        if modify_values:
            selected_features = input_layer.selectedFeatures()
            if not selected_features:
                raise QgsProcessingException("Input error: No points selected.\n\n"
                                            "Please select points to update.\n")

            feedback.pushInfo(f"Processing {len(selected_features)} selected points...")

            # Start editing only if this code opens the session (avoid committing pre-existing user edits)
            started_editing = False
            if not input_layer.isEditable():
                feedback.pushInfo("Starting an editing session...")
                input_layer.startEditing()
                started_editing = True

            field_name = self.parameterAsString(parameters, self.input_field, context)
            new_value = self.parameterAsDouble(parameters, self.new_value, context)

            # Update each selected feature with the new value
            for feature in selected_features:
                try:
                    feature[field_name] = new_value
                    input_layer.updateFeature(feature)
                except Exception as e:
                    feedback.reportError(f"Failed to update feature {feature.id()}: {str(e)}\n")

            if started_editing and not input_layer.commitChanges():
                raise QgsProcessingException("Failed to commit changes to the layer.")
            feedback.pushInfo(f"Successfully updated {len(selected_features)} features in field '{field_name}'.")

        return {
            "input_layer": input_layer,
            "shear": shear,
            "crs": crs,
            "crs_string": crs_string
        }

    def log_initialization(self, feedback, input_precomputed, stage=None, valid_percentage=None, invalid_points=None):
        """Write initialisation details, or a stage-specific progress message when ``stage`` is given."""


        if stage is None:
            # Log initialisation details
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Re-Calculating 2D FL Ice Thickness Points")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - Input Points: {input_precomputed.name()}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText("Pre-processing input data...\n")
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "ice_calculation":
            feedback.setProgressText("Calculating ice surface and thickness...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 95:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushWarning(f"Invalid driving stress points (fid): {invalid_points}\n")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def create_temp_layer_from_output(self, output_path, layer_name, feedback=None):
        """Load a vector layer from a path and add 'xcoord'/'ycoord' fields from each point."""

        # Load the layer from the output path
        temp_layer = QgsVectorLayer(output_path, layer_name, "ogr")

        if not temp_layer.isValid():
            raise ValueError(f"Failed to create layer: {layer_name} from path: {output_path}")

        # Add xcoord and ycoord fields
        temp_layer.dataProvider().addAttributes([QgsField('xcoord', _FIELD_DOUBLE), QgsField('ycoord', _FIELD_DOUBLE)])
        temp_layer.updateFields()  # Apply the added fields

        # Prepare bulk updates for features
        xcoord_idx = temp_layer.fields().indexOf('xcoord')
        ycoord_idx = temp_layer.fields().indexOf('ycoord')
        features = temp_layer.getFeatures()
        updates = {}

        for feature in features:
            geom = feature.geometry().asPoint()
            updates[feature.id()] = {xcoord_idx: geom.x(), ycoord_idx: geom.y()}

        # Perform the bulk update
        temp_layer.dataProvider().changeAttributeValues(updates)

        return temp_layer
    
    def ice_reconstruction(self, df, shear=None, feedback=None):
        """Reconstruct ice surface and thickness along every flowline.

        Marches the main flowline from the terminus, solving the quadratic
        equilibrium profile point by point, then reconstructs each tributary once
        its confluence point has a surface. Thickness is the reconstructed surface
        minus the bed ('rvalue1'), floored at zero, with the terminus forced to
        zero.

        Args:
            df: flowline points with 'cat', 'xcoord', 'ycoord', 'rvalue1' (bed
                elevation), 'prox_id', 'fid', 'shear_stress'.
            shear: constant basal shear stress in Pa; if None, each point's own
                'shear_stress' is used.

        Returns:
            The frame with added 'ice_surface' and 'ice_thickness' columns.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81   # Gravitational acceleration (m/s2)

        # helper function to compute the next ice surface using the quadratic model.
        def compute_next_surface(prev_surface, r_prev, r_curr, d, local_shear):
            """Next surface from the quadratic equilibrium profile; fall back to the bed if there is no real root."""

            b = -(r_prev + r_curr)
            c = prev_surface * (r_curr - (prev_surface - r_prev)) - (2 * d * local_shear) / (rho * g)
            disc = b**2 - 4 * c
            if disc >= 0:
                return (-b + np.sqrt(disc)) / 2
            else:
                return r_curr

        # helper function to process a single flowline segment.
        def process_flowline_segment(segment_df, initial_surface=None):
            """March one flowline segment from its first point, returning {fid: ice_surface}.

            Uses ``initial_surface`` for the first point when given, otherwise the
            segment's first bed value ('rvalue1').
            """

            surface_map = {}
            seg = segment_df.sort_index().reset_index(drop=True)
            first = seg.iloc[0]
            init_surf = initial_surface if initial_surface is not None else first['rvalue1']
            surface_map[first['fid']] = init_surf
            prev_surface = init_surf
            # Process remaining points sequentially.
            for i in range(1, len(seg)):
                curr = seg.iloc[i]
                prev = seg.iloc[i - 1]
                dx = curr['xcoord'] - prev['xcoord']
                dy = curr['ycoord'] - prev['ycoord']
                d = np.sqrt(dx**2 + dy**2)
                local_shear = shear if shear is not None else curr['shear_stress']
                new_surface = compute_next_surface(prev_surface, prev['rvalue1'], curr['rvalue1'], d, local_shear)
                surface_map[curr['fid']] = new_surface
                prev_surface = new_surface
            return surface_map

        surface_dict = {}

        # Process main flowline
        main_mask = df['prox_id'].isna()
        main_flowline = df[main_mask].copy()
        if not main_flowline.empty:
            main_surfaces = process_flowline_segment(main_flowline)
            surface_dict.update(main_surfaces)

        # Process tributaries in network order (multi-pass), not digitising (cat) order.
        # A tributary can only inherit its confluence surface once the flowline it
        # drains into has itself been reconstructed, so each pass processes every
        # tributary whose downstream link (prox_id) is already in surface_dict.
        tributaries = df[~main_mask].copy()
        pending = {cat: group.copy().reset_index(drop=True)
                   for cat, group in tributaries.groupby('cat')}
        while pending:
            ready = [cat for cat, group in pending.items()
                     if group.iloc[0]['prox_id'] in surface_dict]
            if not ready:
                # No remaining tributary links to a reconstructed flowline (mis-linked
                # prox_id, wrong digitising direction, or circular connection).
                # Fall back to bed elevation, but loudly instead of silently.
                for cat, group in pending.items():
                    msg = (f"Tributary cat={cat}: downstream link (fid "
                           f"{group.iloc[0]['prox_id']}) was never reconstructed - "
                           "starting at bed elevation (zero ice thickness). Check the "
                           "flowline digitising direction and network connectivity.")
                    self._log(msg, level='warning')
                    if feedback is not None:
                        feedback.pushWarning(msg + "\n")
                    surface_dict.update(process_flowline_segment(
                        group, initial_surface=group.iloc[0]['rvalue1']))
                break
            for cat in ready:
                group = pending.pop(cat)
                surface_dict.update(process_flowline_segment(
                    group, initial_surface=surface_dict[group.iloc[0]['prox_id']]))
                
        # Map the computed surfaces back to the DataFrame.
        df['ice_surface'] = df['fid'].map(surface_dict)
        df['ice_thickness'] = np.maximum(df['ice_surface'] - df['rvalue1'], 0)
        
        # Locate and replace zero ice thickness values using nearest neighbour approach
        df = self.replace_zero_thickness_with_nearest_neighbor(df)

        # Ensure terminus has zero ice thickness
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]

        if not main_flowline.empty:
            # Find terminus (minimum distance point on main flowline)
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            terminus_idx = terminus_row.name  # Get the DataFrame index
            
            # Force terminus to zero thickness
            df.at[terminus_idx, 'ice_thickness'] = 0
            df.at[terminus_idx, 'ice_surface'] = df.at[terminus_idx, 'rvalue1']
        
        return df
        
    def validate_driving_stress(self, df):
        """Flag points whose driving stress falls outside 50-200 kPa.

        Driving stress is rho*g*H*sin(alpha), with the surface slope taken from
        successive 'ice_surface' values along the line.

        Args:
            df: points with 'ice_thickness', 'xcoord', 'ycoord', 'ice_surface',
                'fid'.

        Returns:
            (frame, valid_percentage, invalid_fids), with the temporary check
            columns removed.
        """

        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Calculate surface slope
        dx = df['xcoord'].diff().fillna(0) 
        dy = df['ycoord'].diff().fillna(0)  
        dz = df['ice_surface'].diff().fillna(0) 
        d = np.sqrt(dx**2 + dy**2 + 1e-6)  
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate driving stress
        driving_stress = rho * g * df['ice_thickness'] * np.sin(surface_slope)

        # Validate driving stress
        df['stress_valid'] = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        invalid_points = df.loc[~df['stress_valid'], 'fid'].tolist()  
        valid_points = df['stress_valid'].sum()
        total_points = len(df)
        if total_points == 0:
            df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')
            return df, 0.0, []
        valid_percentage = (valid_points / total_points) * 100

        # Clean up temporary columns
        df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')

        return df, valid_percentage, invalid_points

    def postProcessAlgorithm(self, context, feedback):
        """Show a completion dialog once processing finishes."""

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("2D FL Ice Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)