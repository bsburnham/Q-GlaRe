"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D modified FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, traceback
from .qglare_base import QGlaReAlgorithmMixin
from .qglare_utils import normalise_shapefile_field_names
import numpy as np
import pandas as pd
from osgeo import gdal
import processing
from qgis.PyQt.QtCore import QVariant, QMetaType
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication 
from qgis.core import (Qgis,
                       QgsField,
                       QgsFields,
                       QgsProject,
                       QgsFeature,
                       QgsPointXY,
                       QgsGeometry,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsRasterLayer,
                       QgsVectorLayer,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterField,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterBoolean,                   
                       QgsProcessingMultiStepFeedback,                       
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingFeatureSourceDefinition)

# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_VECTOR_POINT = Qgis.ProcessingSourceType.VectorPoint
except AttributeError:                          # QGIS < 3.36
    _SOURCE_VECTOR_POINT = QgsProcessing.TypeVectorPoint

# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38 —
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
_FIELD_DOUBLE = QMetaType.Type.Double if Qgis.QGIS_VERSION_INT >= 33800 else QVariant.Double

class ModifiedIceFlowThickness(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for calculating glacier ice thickness.

    This tool reconstructs glacier ice thickness along flowlines using a 
    simplified equilibrium ice surface profile model (Benn and Hulton, 2010)
    and adapted by Pellitero et al., (2015). The calculation relies on 
    user-supplied DEM data, flowlines, and basal shear stress to estimate 
    ice thickness and surface elevation at regular intervals.

    Key Features:
    - Calculates ice thickness and surface elevation along flowlines.
    - Validates results using driving stress (50–200 kPa).
    - Outputs a vector layer with calculated ice thickness and elevation.

    Inputs:
    - DEM: Raster representing glacier basal topography.
    - Flowlines: Vector file of glacier flowlines.
    - Shear Stress: Basal shear stress (default: 100,000 Pa).
    - Interval: Point spacing along flowlines (default: 10 map units).

    Output:
    - A vector point layer with ice thickness, surface elevation, and attributes.

    References:
    - Benn, D.I., Hulton, N.R.J., 2010. An Excel™ spreadsheet program for 
      reconstructing the surface profile of former mountain glaciers and ice caps. 
      Computers & Geosciences, 36, pp. 605–610.
    - Nye, J.F., 1952. The Mechanics of Glacier Flow. Journal of Glaciology, 2, pp. 82–93.
    """

    N_STEPS = 9
    _log_tag = '2D FL Ice Thickness Processing Log'

    input_precomputed = 'input_precomputed'
    input_field = "input_field"
    new_value = "new_value"
    modify_values = "modify_values"

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return 'Ice Flow Thickness Modified'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """

        return '2. 2D modified FL Ice Thickness'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
        
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("1 Ice Flow Thickness", text)
    
    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)
     
    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """

        return self.tr(
            "A tool to re-calculate glacier ice thickness where values may "
             "have been adjusted manually for individual points. "
            "Only a vector point file previously generated from the 2D FL Ice Thickness Tool "
            "is required. A new ice thickness and surface elevation value will be computed. \n"
            "This tool is based on the equilibrium ice surface profile model developed by "
            "Nye (1952a, b) and adapted by Benn and Hulton (2010) to work with glacier "
            "basal topography and shear stress as inputs.\n\n"
            "References:\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of "
            "Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the "
            "Ice-Sheets. Nature 169, pp. 529–530.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program "
            "for reconstructing the surface profile of former mountain glaciers "
            "and ice caps. Computers & Geosciences 36, pp. 605–610.")

    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            IceFlowThickness: A new instance of the `IceFlowThickness` class.
        """
        return ModifiedIceFlowThickness()
    
    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'shear_stress.png') 
        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """
        
        self.addParameter(
        QgsProcessingParameterVectorLayer(
        self.input_precomputed,
        self.tr("\nSelect ice flow thickness (vector point file) to modify"),
        [_SOURCE_VECTOR_POINT]))
        
        self.addParameter(
        QgsProcessingParameterBoolean(
        self.modify_values, 
        self.tr("\nModify selected point(s) field values (e.g., shear stress, elevation value)"),
        defaultValue=False,
        optional=True))

        self.addParameter(
        QgsProcessingParameterField(
        self.input_field,
        "\nData field to update",
        parentLayerParameterName=self.input_precomputed,
        type=QgsProcessingParameterField.Any))

        self.addParameter(
        QgsProcessingParameterNumber(
        self.new_value,
        "\nValue to update selected data field. Default value is 100,000",
        defaultValue="100000"))
        
    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Executes the algorithm and performs ice thickness reconstruction based on user inputs.
        """
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)

        try:
            self._init_logger('modified_ice_flow_thickness', feedback)

            # Preprocess inputs
            inputs = self.preprocess_inputs(parameters, context, feedback)
            input_layer = inputs["input_layer"]
            crs = inputs["crs"]
            crs_string = inputs["crs_string"]
            shear = inputs["shear"]  # Should be None when using precomputed points

            # Create a DataFrame from the (possibly modified) input layer
            flowline_points_df = self.create_dataframe(input_layer, None, feedback, include_geometry=True)
            flowline_points_df = normalise_shapefile_field_names(flowline_points_df)

            # Log initialization & pre-processing duration
            glob_start_time = time.time()
            self.log_initialization(feedback, input_layer)
            self._log_run_header({
                'Input Points': f"{input_layer.name()} ({input_layer.source()})",
                'CRS':          crs_string,
            })
            self._log_layer_crs([
                ('Input Points', input_layer),
            ])
            self.log_initialization(feedback, input_layer, stage="input_processed")
            self.log_initialization(feedback, input_layer, stage="data_prep")
            self.log_processing_duration("Data processed for calculation", glob_start_time)

            # Link tributary and centreline
            start_time = time.time()
            prox_id_df = self.calculate_prox_id_flow_based(flowline_points_df, feedback)
            self.log_initialization(feedback, input_layer, stage="tributary_centreline")
            self.log_processing_duration("Spatially linked tributary branches and centreline", start_time)

            # Estimate ice thickness and surface elevation
            start_time = time.time()
            reconstructed_df = self.ice_reconstruction(prox_id_df, shear=None, feedback=feedback)
            self.log_initialization(feedback, input_layer, stage="ice_calculation")
            self.log_processing_duration("Ice surface and thickness estimation", start_time)

            # Validate the estimates
            start_time = time.time()
            validated_df, valid_percentage, invalid_points = self.validate_driving_stress(reconstructed_df)
            self.log_initialization(feedback, input_layer, stage="validation",
                                    valid_percentage=valid_percentage, invalid_points=invalid_points)
            self.log_processing_duration("Ice surface and thickness validation", start_time)

            # Load Results into QGIS
            start_time = time.time()
            self.load_dataframe_to_qgis(validated_df, crs, QgsProject.instance(),
                                        layer_name="2D FL Ice Thickness", feedback=feedback)
            self.log_initialization(feedback, input_layer, stage="load_qgis")
            self.log_processing_duration("Ice flow thickness points loaded into QGIS", start_time)

            # Final logging
            self.log_final_results(feedback, crs_string, glob_start_time)
            self._log_success(feedback)
            return {"Status": "Complete"}

        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieve and optionally modify a precomputed layer for ice thickness reconstruction.

        This function:
        - Loads the input precomputed points layer.
        - Optionally updates selected features with a new value if the user has enabled `modify_values`.
        - Returns a dictionary containing the input layer, shear (None for precomputed), the layer's CRS,
            and the CRS string.

        Parameters:
            parameters (dict): Dictionary of user-supplied parameters for the algorithm.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): For logging messages and progress.

        Returns:
            dict: A dictionary with keys:
                - "input_layer" (QgsVectorLayer): The precomputed points layer.
                - "shear" (None): Basal shear stress is not used for precomputed data.
                - "crs" (QgsCoordinateReferenceSystem): The layer's CRS.
                - "crs_string" (str): AuthID of the layer's CRS, or 'Unknown CRS' if invalid.

        Raises:
            QgsProcessingException: If no features are selected when `modify_values` is enabled,
                                or if the input layer is invalid.
        """

        input_layer = self.parameterAsLayer(parameters, self.input_precomputed, context)
        if input_layer is None or not input_layer.isValid():
            raise QgsProcessingException(
                "The precomputed ice thickness points layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        shear = None  # Default for shear stress when precomputed points are used
        crs = input_layer.crs()
        crs_string = crs.authid() if crs.isValid() else 'Unknown CRS'

        # Validate that input layer uses projected CRS
        self.validate_projected_crs(input_layer, feedback) 

        # Check whether to modify values
        modify_values = self.parameterAsBoolean(parameters, self.modify_values, context)
        if modify_values:
            selected_features = input_layer.selectedFeatures()
            if not selected_features:
                raise QgsProcessingException("Input error: No points selected.\n\n"
                                            "Please select points to update.\n")

            feedback.pushInfo(f"Processing {len(selected_features)} selected points...")

            # Start editing only if this code opens the session (avoid committing pre-existing user edits)
            started_editing = False
            if not input_layer.isEditable():
                feedback.pushInfo("Starting an editing session...")
                input_layer.startEditing()
                started_editing = True

            field_name = self.parameterAsString(parameters, self.input_field, context)
            new_value = self.parameterAsDouble(parameters, self.new_value, context)

            # Update each selected feature with the new value
            for feature in selected_features:
                try:
                    feature[field_name] = new_value
                    input_layer.updateFeature(feature)
                except Exception as e:
                    feedback.reportError(f"Failed to update feature {feature.id()}: {str(e)}")

            if started_editing and not input_layer.commitChanges():
                raise QgsProcessingException("Failed to commit changes to the layer.")
            feedback.pushInfo(f"Successfully updated {len(selected_features)} features in field '{field_name}'.")

        return {
            "input_layer": input_layer,
            "shear": shear,
            "crs": crs,
            "crs_string": crs_string
        }

    def log_initialization(self, feedback, input_precomputed, stage=None, valid_percentage=None, invalid_points=None):
        """
        Log workflow messages to the QGIS feedback console, focusing on precomputed input data.

        This function:
        - Logs initial parameters if `stage` is None, including the name of the precomputed points layer.
        - Updates the progress text according to the current stage (e.g., "input_processed", "data_prep", "validation").
        - Optionally logs warnings if the percentage of valid points is below a threshold during validation.

        Parameters:
            feedback (QgsProcessingFeedback): The feedback object for logging messages.
            input_precomputed (QgsVectorLayer): The precomputed points layer being processed.
            stage (str, optional): Current processing stage. If None, logs initialization details.
            valid_percentage (float, optional): Percentage of valid points, used if `stage` == "validation".
            invalid_points (list, optional): Identifiers of invalid points, used if validation fails.

        Returns:
            None
        """


        if stage is None:
            # Log initialization details
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Re-Calculating 2D FL Ice Thickness Points")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - Input Points: {input_precomputed.name()}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText("Pre-processing input data...\n")
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "ice_calculation":
            feedback.setProgressText("Calculating ice surface and thickness...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 95:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushWarning(f"Invalid driving stress points (fid): {invalid_points}")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def create_temp_layer_from_output(self, output_path, layer_name, feedback=None):
        """
        Create a temporary vector layer from a file path and add x/y coordinate attributes.

        This function:
        - Loads the file at the specified output path into a QgsVectorLayer.
        - Adds "xcoord" and "ycoord" fields to the layer.
        - Updates each feature with the corresponding point geometry's x and y coordinate values.

        Parameters:
            output_path (str): The file path to the vector data source.
            layer_name (str): The name to assign to the temporary layer.
            feedback (QgsProcessingFeedback, optional): For logging progress or notifications.

        Returns:
            QgsVectorLayer: The newly created vector layer with added "xcoord" and "ycoord" fields.

        Raises:
            ValueError: If the layer cannot be created from the specified path or is invalid.
        """

        # Load the layer from the output path
        temp_layer = QgsVectorLayer(output_path, layer_name, "ogr")

        if not temp_layer.isValid():
            raise ValueError(f"Failed to create layer: {layer_name} from path: {output_path}")

        # Add xcoord and ycoord fields
        temp_layer.dataProvider().addAttributes([QgsField('xcoord', _FIELD_DOUBLE), QgsField('ycoord', _FIELD_DOUBLE)])
        temp_layer.updateFields()  # Apply the added fields

        # Prepare bulk updates for features
        xcoord_idx = temp_layer.fields().indexOf('xcoord')
        ycoord_idx = temp_layer.fields().indexOf('ycoord')
        features = temp_layer.getFeatures()
        updates = {}

        for feature in features:
            geom = feature.geometry().asPoint()
            updates[feature.id()] = {xcoord_idx: geom.x(), ycoord_idx: geom.y()}

        # Perform the bulk update
        temp_layer.dataProvider().changeAttributeValues(updates)

        return temp_layer
    
    def ice_reconstruction(self, df, shear=None, feedback=None):
        """
        Compute ice thickness and reconstruct the ice surface for flowlines using a quadratic model.

        This function:
        - Processes the main flowline (points with no 'prox_id') sequentially to compute the ice surface.
        - Processes tributaries by inheriting the ice surface from a downstream confluence.
        - Calculates ice thickness as the difference between the reconstructed ice surface and the DEM value ('rvalue1'),
        ensuring that no negative thickness values are produced.
        
        Parameters:
            df (pd.DataFrame): DataFrame containing flowline data with columns: 'cat', 'xcoord', 'ycoord', 'rvalue1', 'prox_id', 'fid', 'shear_stress'.
            shear (float, optional): The constant basal shear stress value; if None, each point's 'shear_stress' is used.

        Returns:
            pd.DataFrame: The updated DataFrame with new columns 'ice_surface' and 'ice_thickness'.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81   # Gravitational acceleration (m/s2)

        # helper function to compute the next ice surface using the quadratic model.
        def compute_next_surface(prev_surface, r_prev, r_curr, d, local_shear):
            """
            Compute the next ice surface value using the quadratic model.
            """

            b = -(r_prev + r_curr)
            c = prev_surface * (r_curr - (prev_surface - r_prev)) - (2 * d * local_shear) / (rho * g)
            disc = b**2 - 4 * c
            if disc >= 0:
                return (-b + np.sqrt(disc)) / 2
            else:
                return r_curr

        # helper function to process a single flowline segment.
        def process_flowline_segment(segment_df, initial_surface=None):
            """
            Process a sorted flowline segment (main or tributary) to compute reconstructed ice surface values.

            This function:
            - Sorts the input DataFrame to replicate the original ordering.
            - Uses an optionally provided initial surface value, or defaults to the first point's DEM value ('rvalue1').
            - Iterates sequentially over the segment and computes the ice surface for each point using a quadratic model.
            - Uses the preceding computed ice surface value and the current point’s data (e.g., distance and shear stress) to calculate a new ice surface value via an external function (compute_next_surface).
            - Returns a mapping of each point's 'fid' to its computed ice surface value.

            Parameters:
                segment_df (pd.DataFrame): DataFrame representing a single flowline segment. It must include at least the columns:
                    - 'fid': Unique feature identifier.
                    - 'xcoord', 'ycoord': Spatial coordinates.
                    - 'rvalue1': DEM value used as a reference for the ice surface.
                    - 'shear_stress': Shear stress value for each point.
                initial_surface (float, optional): The initial ice surface elevation to assign to the first point.
                    If not provided, the first point's 'rvalue1' is used.

            Returns:
                dict: A dictionary mapping feature IDs (int) to the computed ice surface elevation (float) for the segment.
            """

            surface_map = {}
            seg = segment_df.sort_index().reset_index(drop=True)
            first = seg.iloc[0]
            init_surf = initial_surface if initial_surface is not None else first['rvalue1']
            surface_map[first['fid']] = init_surf
            prev_surface = init_surf
            # Process remaining points sequentially.
            for i in range(1, len(seg)):
                curr = seg.iloc[i]
                prev = seg.iloc[i - 1]
                dx = curr['xcoord'] - prev['xcoord']
                dy = curr['ycoord'] - prev['ycoord']
                d = np.sqrt(dx**2 + dy**2)
                local_shear = shear if shear is not None else curr['shear_stress']
                new_surface = compute_next_surface(prev_surface, prev['rvalue1'], curr['rvalue1'], d, local_shear)
                surface_map[curr['fid']] = new_surface
                prev_surface = new_surface
            return surface_map

        surface_dict = {}

        # Process main flowline
        main_mask = df['prox_id'].isna()
        main_flowline = df[main_mask].copy()
        if not main_flowline.empty:
            main_surfaces = process_flowline_segment(main_flowline)
            surface_dict.update(main_surfaces)

        # Process tributaries in NETWORK order (multi-pass), not digitising (cat) order.
        # A tributary can only inherit its confluence surface once the flowline it
        # drains into has itself been reconstructed, so each pass processes every
        # tributary whose downstream link (prox_id) is already in surface_dict.
        # Previously this ran in cat order: a tributary joining a higher-cat tributary
        # silently fell back to starting at BED elevation (zero ice), offsetting its
        # entire surface and creating large steps between adjacent reconstructions.
        tributaries = df[~main_mask].copy()
        pending = {cat: group.copy().reset_index(drop=True)
                   for cat, group in tributaries.groupby('cat')}
        while pending:
            ready = [cat for cat, group in pending.items()
                     if group.iloc[0]['prox_id'] in surface_dict]
            if not ready:
                # No remaining tributary links to a reconstructed flowline (mis-linked
                # prox_id, wrong digitising direction, or circular connection).
                # Fall back to bed elevation, but LOUDLY instead of silently.
                for cat, group in pending.items():
                    msg = (f"Tributary cat={cat}: downstream link (fid "
                           f"{group.iloc[0]['prox_id']}) was never reconstructed - "
                           "starting at BED elevation (zero ice thickness). Check the "
                           "flowline digitising direction and network connectivity.")
                    self._log(msg, level='warning')
                    if feedback is not None:
                        feedback.pushWarning(msg)
                    surface_dict.update(process_flowline_segment(
                        group, initial_surface=group.iloc[0]['rvalue1']))
                break
            for cat in ready:
                group = pending.pop(cat)
                surface_dict.update(process_flowline_segment(
                    group, initial_surface=surface_dict[group.iloc[0]['prox_id']]))
                
        # # Process tributaries
        # tributaries = df[~main_mask].copy()
        # for cat, group in tributaries.groupby('cat'):
        #     group = group.copy().reset_index(drop=True)
        #     # The first point in the tributary (confluence) should inherit its ice surface from its
        #     # downstream connection via prox_id. If that is not available, use its own DEM value.
        #     confluence = group.iloc[0]
        #     prox_id = confluence['prox_id']
        #     if prox_id in surface_dict:
        #         init_surface = surface_dict[prox_id]
        #     else:
        #         init_surface = confluence['rvalue1']
        #     trib_surfaces = process_flowline_segment(group, initial_surface=init_surface)
        #     surface_dict.update(trib_surfaces)

        # Map the computed surfaces back to the DataFrame.
        df['ice_surface'] = df['fid'].map(surface_dict)
        df['ice_thickness'] = np.maximum(df['ice_surface'] - df['rvalue1'], 0)
        
        # Locate and replace zero ice thickness values using nearest neighbor approach
        df = self.replace_zero_thickness_with_nearest_neighbor(df)

        # ENSURE TERMINUS HAS ZERO ICE THICKNESS
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]

        if not main_flowline.empty:
            # Find terminus (minimum distance point on main flowline)
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            terminus_idx = terminus_row.name  # Get the DataFrame index
            
            # Force terminus to zero thickness
            df.at[terminus_idx, 'ice_thickness'] = 0
            df.at[terminus_idx, 'ice_surface'] = df.at[terminus_idx, 'rvalue1']
        
        return df
        
    def validate_driving_stress(self, df):
        """
        Validate the computed ice thickness values using driving stress calculations.

        This function:
        - Estimates the local surface slope using differences in x/y coordinates and the reconstructed ice surface.
        - Computes the driving stress based on ice density, gravitational acceleration, ice thickness, and the sine of the slope.
        - Determines which points have driving stress values within the acceptable range (50 kPa to 200 kPa).
        - Returns the updated DataFrame, the percentage of points within range, and a list of invalid point IDs.

        Parameters:
            df (pd.DataFrame): Input DataFrame containing the columns "ice_thickness", "xcoord", "ycoord", and "ice_surface".

        Returns:
            tuple: A tuple consisting of:
                - (pd.DataFrame) The updated DataFrame with driving stress validation.
                - (float) The percentage of points with valid driving stress.
                - (list) A list of "fid" values for points with invalid driving stress.
        """

        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Calculate surface slope
        dx = df['xcoord'].diff().fillna(0) 
        dy = df['ycoord'].diff().fillna(0)  
        dz = df['ice_surface'].diff().fillna(0) 
        d = np.sqrt(dx**2 + dy**2 + 1e-6)  
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate driving stress
        driving_stress = rho * g * df['ice_thickness'] * np.sin(surface_slope)

        # Validate driving stress
        df['stress_valid'] = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        invalid_points = df.loc[~df['stress_valid'], 'fid'].tolist()  
        valid_points = df['stress_valid'].sum()
        total_points = len(df)
        if total_points == 0:
            df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')
            return df, 0.0, []
        valid_percentage = (valid_points / total_points) * 100

        # Clean up temporary columns
        df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')

        return df, valid_percentage, invalid_points

    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message after processing and perform any necessary post-processing tasks.

        This function:
        - Creates and displays a QMessageBox with a completion message.
        - Sets the processing progress to 100% and updates the progress text.
        - Returns a dictionary indicating the status of post-processing.

        Parameters:
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): The feedback object for progress updates.

        Returns:
            dict: A dictionary reflecting the post-processing completion status.
        """

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("2D FL Ice Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)