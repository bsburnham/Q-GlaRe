"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris '
__date__ = '2025-05-29'
__copyright__ = '(C) 2025 Brian S. Burnham'
__email__ = 'brian.burnham@abdn.ac.uk'

__revision__ = '$Format:%H$'

import os
import inspect
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
from .ice_flow_thickness import IceFlowThickness
from .ffactor import Ffactor
from .modified_ice_flow_thickness import ModifiedIceFlowThickness
from .interpolation import Interpolation
from .q_ela import QELA

class QglarePlusProvider(QgsProcessingProvider):

    def __init__(self):
        """Default constructor."""
        QgsProcessingProvider.__init__(self)

    def unload(self):
        """Unload the provider and run any tear-down steps."""
        QgsProcessingProvider.unload(self)

    def loadAlgorithms(self):
        """Load all algorithms belonging to this provider."""
        self.addAlgorithm(IceFlowThickness())
        self.addAlgorithm(Ffactor())
        self.addAlgorithm(ModifiedIceFlowThickness())
        self.addAlgorithm(Interpolation())
        self.addAlgorithm(QELA())

    def id(self):
        """Unique, non-localised provider id used internally by QGIS."""
        return 'qglare'

    def name(self):
        """Provider name shown in the GUI."""
        return self.tr('Q-GlaRe+')

    def icon(self):
        """Icon shown for the provider in the Processing toolbox."""
        iconPath = os.path.join( os.path.dirname(__file__),'icons', 'icon.png')
        return QIcon(iconPath)

    def longName(self):
        """Longer, localised provider name; here the same as name()."""
        return self.name()