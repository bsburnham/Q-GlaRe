"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris '
__date__ = '2025-05-29'
__copyright__ = '(C) 2025 Brian S. Burnham'
__email__ = 'brian.burnham@abdn.ac.uk'

__revision__ = '$Format:%H$'

import os
import inspect
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
from .ice_flow_thickness import IceFlowThickness
from .ffactor import Ffactor
from .modified_ice_flow_thickness import ModifiedIceFlowThickness
from .interpolation import Interpolation
from .q_ela import QELA

class QglarePlusProvider(QgsProcessingProvider):

    def __init__(self):
        """
        Default constructor.
        """
        QgsProcessingProvider.__init__(self)

    def unload(self):
        """
        Unloads the provider. Any tear-down steps required by the provider
        should be implemented here.
        """
        QgsProcessingProvider.unload(self)

    def loadAlgorithms(self):
        """
        Loads all algorithms belonging to this provider.
        """
        self.addAlgorithm(IceFlowThickness())
        self.addAlgorithm(Ffactor())
        self.addAlgorithm(ModifiedIceFlowThickness())
        self.addAlgorithm(Interpolation())
        self.addAlgorithm(QELA())

    def id(self):
        """
        Returns the unique provider id, used for identifying the provider. This
        string should be a unique, short, character only string, eg "qgis" or
        "gdal". This string should not be localised.
        """
        return 'qglare'

    def name(self):
        """
        Returns the provider name, which is used to describe the provider
        within the GUI.
        """
        return self.tr('Q-GlaRe+')

    def icon(self):
        """
        Should return a QIcon which is used for your provider inside
        the Processing toolbox.
        """
        iconPath = os.path.join( os.path.dirname(__file__),'icons', 'icon.png')
        return QIcon(iconPath)

    def longName(self):
        """
        Returns the a longer version of the provider name, which can include
        extra details such as version numbers. This string should be localised. The default
        implementation returns the same string as name().
        """
        return self.name()