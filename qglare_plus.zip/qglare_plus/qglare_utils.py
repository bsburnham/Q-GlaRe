"""
Reusable data-processing utilities for all QGlaRe+ processing algorithms.

QGlaReUtils is a mixin inherited by QGlaReAlgorithmMixin (qglare_base.py).
Algorithms never import this module directly — import QGlaReAlgorithmMixin as usual.
"""

import numpy as np
import pandas as pd
from qgis.PyQt.QtCore import QVariant, QMetaType
from qgis.core import (Qgis, QgsField, QgsFields, QgsFeature,
                        QgsGeometry, QgsPointXY, QgsVectorLayer,
                        QgsCoordinateReferenceSystem,
                        QgsProject, QgsProcessingException)


# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38.
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
# Note: the string type is QMetaType.Type.QString, not .String.
if Qgis.QGIS_VERSION_INT >= 33800:
    _FIELD_DOUBLE = QMetaType.Type.Double
    _FIELD_INT    = QMetaType.Type.Int
    _FIELD_STRING = QMetaType.Type.QString
else:                                            # QGIS < 3.38
    _FIELD_DOUBLE = QVariant.Double
    _FIELD_INT    = QVariant.Int
    _FIELD_STRING = QVariant.String


# QGIS version compatibility: QgsCoordinateReferenceSystem.horizontalCrs() added in 3.34.
# Used to extract the horizontal component of a compound/3D CRS (e.g. UTM + vertical
# height); on QGIS < 3.34 the method is absent and the CRS is used as-is.
_HAS_HORIZONTAL_CRS = hasattr(QgsCoordinateReferenceSystem, 'horizontalCrs')


# Shapefile field names are limited to 10 characters. Map truncated → canonical.
_SHAPEFILE_FIELD_MAP = {
    'ice_surfac': 'ice_surface',
    'ice_thickn': 'ice_thickness',
    'shear_stre': 'shear_stress',
    'transect_i': 'transect_id',
    'ff_ice_sur': 'ff_ice_surface',
    'ff_thickne': 'ff_thickness',
}


def normalise_shapefile_field_names(df):
    """
    Rename any Shapefile-truncated column names to their canonical equivalents.

    Shapefiles limit field names to 10 characters. When a QGlaRe+ output layer is
    saved as a Shapefile and reloaded, fields such as 'ice_surface' become 'ice_surfac'.
    Call this immediately after ``create_dataframe`` when the source is user-supplied
    (i.e. not created by the current algorithm run).

    Parameters:
        df (pd.DataFrame): DataFrame whose columns may contain truncated names.

    Returns:
        pd.DataFrame: DataFrame with columns renamed to canonical names.
    """
    return df.rename(columns={k: v for k, v in _SHAPEFILE_FIELD_MAP.items() if k in df.columns})


class QGlaReUtils:
    """
    Mixin providing shared data-processing methods.

    Inherited by QGlaReAlgorithmMixin so that all algorithm classes gain
    these methods automatically.
    """

    # ------------------------------------------------------------------
    # CRS utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _horizontal_crs(crs):
        """
        Return the horizontal component of a CRS.

        For a compound / 3D CRS (e.g. a DEM with a projected horizontal CRS plus a
        vertical CRS such as EPSG:5703 NAVD88 height), the combined CRS has no single
        registered EPSG code, so authid() returns "". The horizontal component carries
        the projected authority code and linear units, so all CRS validation, comparison
        and layer creation should be done against it.

        horizontalCrs() exists in QGIS >= 3.34 (see _HAS_HORIZONTAL_CRS); on older builds
        a layer rarely exposes a compound CRS, so the original CRS is returned unchanged.
        For a non-compound CRS, horizontalCrs() may return an invalid CRS, so the
        isValid() guard falls back to the original CRS in that case too.
        """
        if crs is not None and _HAS_HORIZONTAL_CRS:
            horizontal = crs.horizontalCrs()
            if horizontal is not None and horizontal.isValid():
                return horizontal
        return crs

    # ------------------------------------------------------------------
    # DataFrame / layer utilities
    # ------------------------------------------------------------------

    def create_dataframe(self, temp_layer, attribute_names=None, feedback=None,
                         user_shear=None, include_geometry=False):
        """
        Generate a Pandas DataFrame from a QGIS vector layer.

        Parameters:
            temp_layer (QgsVectorLayer): The source vector layer.
            attribute_names (list, optional): Fields to extract; all fields if None.
            feedback: QGIS feedback object for progress reporting.
            user_shear (float, optional): Shear stress value appended as 'shear_stress' column.
            include_geometry (bool): If True, extract point geometry as 'xcoord'/'ycoord' columns.

        Returns:
            pd.DataFrame: One row per feature.
        """
        if not isinstance(temp_layer, QgsVectorLayer):
            raise ValueError("Input must be a QgsVectorLayer.")

        if attribute_names is None:
            attribute_names = [field.name() for field in temp_layer.fields()]

        data = []
        total_features = temp_layer.featureCount()

        for current_feature, feature in enumerate(temp_layer.getFeatures()):
            row = {name: feature.attribute(name) for name in attribute_names}

            if include_geometry:
                geom = feature.geometry().asPoint()
                row['xcoord'] = geom.x()
                row['ycoord'] = geom.y()

            if user_shear is not None:
                row['shear_stress'] = user_shear

            data.append(row)

            if feedback:
                feedback.setProgress(int((current_feature + 1) / total_features * 100))

        return pd.DataFrame(data)

    def load_dataframe_to_qgis(self, dataframe, crs, project_instance,
                                layer_name='DataFrameLayer', feedback=None):
        """
        Import a Pandas DataFrame into QGIS as a memory vector layer with point geometry.

        Column types are detected from the first non-null value in each column:
        float → Double, int → Int, anything else → String (via the version-appropriate
        field-type constants; see _FIELD_DOUBLE at module level).
        NaN values are written as NULL (None).

        Parameters:
            dataframe (pd.DataFrame): DataFrame to import; must include 'xcoord' and 'ycoord' columns.
            crs (QgsCoordinateReferenceSystem): Target CRS for the new layer.
            project_instance (QgsProject): The QGIS project instance.
            layer_name (str, optional): Name for the created layer (default 'DataFrameLayer').
            feedback: QGIS feedback object for progress reporting and cancellation.
        """
        fields = QgsFields()
        for column in dataframe.columns:
            first = dataframe[column].dropna()
            sample = first.iloc[0] if not first.empty else None
            if isinstance(sample, (float, np.floating)):
                field_type = _FIELD_DOUBLE
            elif isinstance(sample, (int, np.integer)):
                field_type = _FIELD_INT
            else:
                field_type = _FIELD_STRING
            fields.append(QgsField(column, field_type))

        # Use the horizontal component so a compound/3D source CRS (e.g. a DEM with a
        # vertical height CRS) yields a clean 2D CRS on the output points. Assign via
        # setCrs() rather than the provider URI so a CRS without an authority code
        # (compound or fully custom) is still applied correctly.
        vector_layer = QgsVectorLayer('Point', layer_name, 'memory')
        vector_layer.setCrs(self._horizontal_crs(crs))
        vector_layer.dataProvider().addAttributes(fields)
        vector_layer.updateFields()

        features = []
        total = len(dataframe)
        for i, row in enumerate(dataframe.itertuples(index=False)):
            feat = QgsFeature(fields)
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(float(row.xcoord), float(row.ycoord))))
            for column, value in zip(dataframe.columns, row):
                feat.setAttribute(column, None if pd.isna(value) else value)
            features.append(feat)
            if feedback:
                feedback.setProgress(int((i + 1) / total * 100))
                if feedback.isCanceled():
                    break

        vector_layer.dataProvider().addFeatures(features)
        QgsProject.instance().addMapLayer(vector_layer)

    # ------------------------------------------------------------------
    # Flowline geometry utilities
    # ------------------------------------------------------------------

    def correct_distance_order(self, df, feedback=None):
        """
        Ensure distance values within each flowline segment (cat) increase from terminus to headwall.

        The reconstruction assumes distance = 0 is the DOWNSTREAM end (terminus or confluence)
        of every flowline. Vertex order is the only record of digitising direction and it is
        arbitrary, so each branch is verified against the sampled bed elevation ('rvalue1'):
        ice flows downhill, therefore the downstream end must be the lower end. A branch whose
        distance = 0 end sits significantly HIGHER than its far end was digitised
        head-to-terminus; its distance axis is flipped (with a warning) so the reconstruction
        integrates in the correct direction.

        Parameters:
            df (pd.DataFrame): DataFrame with 'cat' and 'distance' columns. If 'rvalue1'
                               (sampled bed elevation) is present, digitising direction is
                               verified per branch and reversed lines are corrected.
            feedback (QgsProcessingFeedback, optional): For user-visible warnings.

        Returns:
            pd.DataFrame: Sorted ascending by distance within each cat, oriented terminus-first.
        """
        df = df.sort_values(['cat', 'distance']).reset_index(drop=True)

        if 'rvalue1' not in df.columns:
            return df

        FLIP_TOLERANCE_M = 10.0   # ignore sub-noise elevation differences (e.g. flat tongues)
        flipped = []              # (cat, start_elev, end_elev) of every line we auto-correct
        for cat, group in df.groupby('cat'):
            bed = pd.to_numeric(group['rvalue1'], errors='coerce').to_numpy(dtype=float)
            bed = bed[np.isfinite(bed)]
            if bed.size < 2:
                continue
            n_end = max(1, min(3, bed.size // 2))   # average a few points per end (DEM noise)
            start_elev = bed[:n_end].mean()
            end_elev = bed[-n_end:].mean()
            if (start_elev - end_elev) > FLIP_TOLERANCE_M:
                d = pd.to_numeric(group['distance'], errors='coerce')
                df.loc[group.index, 'distance'] = d.max() + d.min() - d
                flipped.append((cat, start_elev, end_elev))

        if flipped:
            n = len(flipped)
            # full per-line detail goes to the file log
            log = getattr(self, '_log', None)
            if log:
                for c, s, e in flipped:
                    log(f"Flowline segment {c} was digitised head-to-terminus "
                        f"({s:.0f} m -> {e:.0f} m); its distance axis was flipped so "
                        f"the reconstruction builds up from the terminus.",
                        level='warning')
            # short summary goes to the QGIS log panel
            c0, s0, e0 = flipped[0]
            if n == 1:
                msg = (f"1 flowline may have been digitised from glacier head to "
                       f"terminus (flowline segment {c0}: {s0:.0f} m -> {e0:.0f} m). "
                       f"It was corrected. Consider reversing this line in the source "
                       f"layer. Full details in log.")
            else:
                msg = (f"{n} flowlines may have been digitised from glacier head to "
                       f"terminus (e.g. flowline segment {c0}: {s0:.0f} m -> {e0:.0f} m). "
                       f"All {n} flowlines were corrected. Consider reversing these "
                       f"lines in the source layer. Full details in log.")
            if feedback is not None:
                feedback.pushWarning(msg)
            df = df.sort_values(['cat', 'distance']).reset_index(drop=True)
        return df

    def _find_main_flow_cat(self, df):
        """
        Return the cat value of the main flowline (the branch containing the glacier terminus).

        The terminus is the point with the minimum along-channel distance. Using distance rather
        than assuming cat==0 makes this robust when cat numbering is arbitrary (e.g. after GRASS
        or QGIS network processing).
        """
        return df.loc[df['distance'].idxmin(), 'cat']

    def estimate_tributary_flow_direction(self, group_df):
        """
        Estimate the general flow direction of a tributary using multiple points along its flowline.

        Parameters:
            group_df (pd.DataFrame): DataFrame containing points from a single tributary flowline with columns:
                - 'distance': Distance along the flowline.
                - 'xcoord', 'ycoord': Spatial coordinates of each point.

        Returns:
            np.ndarray: A normalized 2D unit vector representing the tributary's flow direction.
                    Returns [0, 1] as default if calculation fails.
        """
        sorted_group = group_df.sort_values('distance')

        if len(sorted_group) < 3:
            start = sorted_group.iloc[0]
            end = sorted_group.iloc[-1]
            flow_vector = np.array([end['xcoord'] - start['xcoord'],
                                    end['ycoord'] - start['ycoord']])
        else:
            vectors = []
            weights = []
            for i in range(len(sorted_group) - 1):
                p1 = sorted_group.iloc[i]
                p2 = sorted_group.iloc[i + 1]
                vector = np.array([p2['xcoord'] - p1['xcoord'],
                                   p2['ycoord'] - p1['ycoord']])
                distance = np.linalg.norm(vector)
                if distance > 0:
                    vectors.append(vector / distance)
                    weights.append(distance)

            if vectors:
                flow_vector = np.average(vectors, axis=0, weights=weights)
            else:
                return np.array([0, 1])

        norm = np.linalg.norm(flow_vector)
        return flow_vector / norm if norm > 0 else np.array([0, 1])

    def calculate_flow_compatibility(self, trib_point, trib_flow_dir, candidates):
        """
        Calculate flow direction compatibility between a tributary point and potential connection targets.

        Parameters:
            trib_point (np.ndarray): 2D coordinates [x, y] of the tributary connection point.
            trib_flow_dir (np.ndarray): Normalized 2D unit vector representing tributary flow direction.
            candidates (np.ndarray): Array of candidate points with shape (n, 4) containing [x, y, fid, elevation].

        Returns:
            np.ndarray: Array of flow compatibility costs where 0 = perfect alignment, 2 = opposite direction.
        """
        connection_vectors = candidates[:, :2] - trib_point
        distances = np.linalg.norm(connection_vectors, axis=1)

        valid_mask = distances > 1e-6
        connection_vectors[~valid_mask] = 0.0
        connection_vectors[valid_mask] /= distances[valid_mask, np.newaxis]

        dot_products = np.dot(connection_vectors, trib_flow_dir)
        return 1 - dot_products

    def calculate_elevation_cost(self, trib_elev, candidate_elevs):
        """
        Calculate elevation-based connection costs with glaciologically realistic penalties.

        Parameters:
            trib_elev (float): Elevation of the tributary connection point.
            candidate_elevs (np.ndarray): Array of elevation values for potential connection targets.

        Returns:
            np.ndarray: Array of elevation-based costs (uphill 2x penalty, extreme downhill 0.1x penalty).
        """
        elev_diff = candidate_elevs - trib_elev
        uphill_penalty = np.maximum(0, elev_diff) * 2
        downhill_penalty = np.maximum(0, -elev_diff) * 0.1
        return uphill_penalty + downhill_penalty

    def calculate_prox_id_flow_based(self, df, feedback=None):
        """
        Assign proximity-based identifiers using flow direction compatibility and glaciological constraints.

        Parameters:
            df (pd.DataFrame): DataFrame containing 'cat', 'distance', 'xcoord', 'ycoord', 'fid', 'rvalue1'.
            feedback (QgsProcessingFeedback, optional): For user-visible warnings (reversed
                lines, suspicious confluence links).

        Returns:
            pd.DataFrame: Updated DataFrame with 'prox_id' column indicating downstream linkages.
        """
        if not df.empty:
            df = self.correct_distance_order(df, feedback)

        df['prox_id'] = np.nan

        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat].sort_values('distance')
        if not main_flowline.empty:
            df.loc[main_flowline.index[0], 'prox_id'] = np.nan

        for cat, group in df.groupby('cat'):
            if cat == main_flow_cat:
                continue

            group_sorted = group.sort_values('distance').copy()
            group_fids = group_sorted['fid'].values
            trib_flow_dir = self.estimate_tributary_flow_direction(group_sorted)

            # typical along-line point spacing, for the confluence-link sanity check below
            seg = np.hypot(np.diff(group_sorted['xcoord'].to_numpy(dtype=float)),
                           np.diff(group_sorted['ycoord'].to_numpy(dtype=float)))
            typical_spacing = float(np.nanmedian(seg)) if seg.size else 10.0

            for idx, (i, row) in enumerate(group_sorted.iterrows()):
                if idx == 0:
                    trib_point = np.array([row['xcoord'], row['ycoord']])
                    trib_elev = row['rvalue1']
                    potential_targets = df[df['cat'] != cat][['xcoord', 'ycoord', 'fid', 'rvalue1']]

                    if not potential_targets.empty:
                        candidates = potential_targets.to_numpy()
                        flow_compatibility = self.calculate_flow_compatibility(
                            trib_point, trib_flow_dir, candidates)
                        elevation_cost = self.calculate_elevation_cost(
                            trib_elev, candidates[:, 3])
                        distance_cost = np.sqrt((trib_point[0] - candidates[:, 0])**2 +
                                                (trib_point[1] - candidates[:, 1])**2)
                        total_cost = (distance_cost +
                                      elevation_cost * 20 +
                                      flow_compatibility * 100)
                        best_idx = np.argmin(total_cost)
                        df.at[row.name, 'prox_id'] = candidates[best_idx, 2]

                        # Sanity check: a healthy confluence link lands within a few
                        # point-spacings of the branch start. A distant link usually means
                        # a reversed flowline or a branch not snapped to the network, and
                        # the inherited surface will poison everything downstream of it.
                        link_dist = float(distance_cost[best_idx])
                        link_threshold = max(10.0 * typical_spacing, 100.0)
                        if np.isfinite(link_dist) and link_dist > link_threshold:
                            msg = (f"Tributary cat={cat}: confluence link is {link_dist:.0f} m "
                                   f"from the branch start (expected within ~{link_threshold:.0f} m). "
                                   f"Check the flowline digitising direction and that the branch "
                                   f"snaps to the network - reconstructed thickness downstream of "
                                   f"this link may be unreliable.")
                            log = getattr(self, '_log', None)
                            if log:
                                log(msg, level='warning')
                            if feedback is not None:
                                feedback.pushWarning(msg)
                    else:
                        df.at[row.name, 'prox_id'] = np.nan
                else:
                    df.at[row.name, 'prox_id'] = group_fids[idx - 1]

        return df

    def replace_zero_thickness_with_nearest_neighbor(self, df):
        """
        Replace zero ice thickness values using prox_id mapping and nearest neighbour search,
        preserving zero thickness only at the true glacier terminus.

        Parameters:
            df (pd.DataFrame): DataFrame with 'fid', 'prox_id', 'ice_thickness', 'xcoord', 'ycoord',
                               'cat', 'distance'.

        Returns:
            pd.DataFrame: DataFrame with zero 'ice_thickness' values replaced.
        """
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]

        if not main_flowline.empty:
            true_terminus_fid = main_flowline.loc[main_flowline['distance'].idxmin(), 'fid']
        else:
            true_terminus_fid = None

        if true_terminus_fid is not None:
            zero_mask = (df['ice_thickness'] == 0) & (df['fid'] != true_terminus_fid)
        else:
            zero_mask = (df['ice_thickness'] == 0)

        if not zero_mask.any():
            return df

        df_zero = df[zero_mask].copy()
        df_nonzero = df[df['ice_thickness'] != 0].copy()

        thickness_map = df.set_index('fid')['ice_thickness']
        df_zero['prox_thickness'] = df_zero['prox_id'].map(thickness_map)
        valid_prox = df_zero['prox_thickness'].notna() & (df_zero['prox_thickness'] > 0)
        df_zero.loc[valid_prox, 'ice_thickness'] = df_zero.loc[valid_prox, 'prox_thickness']

        still_zero = (df_zero['ice_thickness'] == 0)
        if still_zero.any():
            if df_nonzero.empty:
                raise QgsProcessingException(
                    "Cannot replace zero-thickness points: no non-zero thickness points exist in this dataset. "
                    "Check that the input ice thickness data contains valid non-zero values."
                )
            zero_coords = df_zero.loc[still_zero, ['xcoord', 'ycoord']].to_numpy()
            nonzero_coords = df_nonzero[['xcoord', 'ycoord']].to_numpy()
            nonzero_thickness = df_nonzero['ice_thickness'].to_numpy()

            diff = zero_coords[:, np.newaxis, :] - nonzero_coords[np.newaxis, :, :]
            dists = np.sqrt(np.sum(diff**2, axis=2))
            nearest_idx = np.argmin(dists, axis=1)
            df_zero.loc[still_zero, 'ice_thickness'] = nonzero_thickness[nearest_idx]

        df_zero = df_zero.drop(columns=['prox_thickness'])  # redundant (update call selects only ice_thickness), kept for clarity
        df.update(df_zero[['ice_thickness']])
        return df
