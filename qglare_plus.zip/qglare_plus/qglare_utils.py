"""
Reusable data-processing utilities for all QGlaRe+ processing algorithms.

QGlaReUtils is a mixin inherited by QGlaReAlgorithmMixin (qglare_base.py).
Algorithms never import this module directly - import QGlaReAlgorithmMixin as usual.
"""

import numpy as np
import pandas as pd
from qgis.PyQt.QtCore import QVariant, QMetaType
from qgis.core import (Qgis, QgsField, QgsFields, QgsFeature,
                        QgsGeometry, QgsPointXY, QgsVectorLayer,
                        QgsCoordinateReferenceSystem,
                        QgsProject, QgsProcessingContext, QgsProcessingException)


# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38.
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
# Note: the string type is QMetaType.Type.QString, not .String.
if Qgis.QGIS_VERSION_INT >= 33800:
    _FIELD_DOUBLE = QMetaType.Type.Double
    _FIELD_INT    = QMetaType.Type.Int
    _FIELD_STRING = QMetaType.Type.QString
else:                                            # QGIS < 3.38
    _FIELD_DOUBLE = QVariant.Double
    _FIELD_INT    = QVariant.Int
    _FIELD_STRING = QVariant.String


# QGIS version compatibility: QgsCoordinateReferenceSystem.horizontalCrs() added in 3.34.
# Used to extract the horizontal component of a compound/3D CRS (e.g. UTM + vertical
# height); on QGIS < 3.34 the method is absent and the CRS is used as-is.
_HAS_HORIZONTAL_CRS = hasattr(QgsCoordinateReferenceSystem, 'horizontalCrs')


# Shapefile field names are limited to 10 characters. Map truncated → canonical.
_SHAPEFILE_FIELD_MAP = {
    'ice_surfac': 'ice_surface',
    'ice_thickn': 'ice_thickness',
    'shear_stre': 'shear_stress',
    'transect_i': 'transect_id',
    'ff_ice_sur': 'ff_ice_surface',
    'ff_thickne': 'ff_thickness',
}


def normalise_shapefile_field_names(df):
    """Rename any Shapefile-truncated column names to their canonical equivalents.

    Shapefiles limit field names to 10 characters, so a saved-and-reloaded QGlaRe+
    layer has fields such as 'ice_surface' shortened to 'ice_surfac'. Call this right
    after create_dataframe when the source is user-supplied (not created by the
    current algorithm run).
    """
    return df.rename(columns={k: v for k, v in _SHAPEFILE_FIELD_MAP.items() if k in df.columns})


class QGlaReUtils:
    """
    Mixin providing shared data-processing methods.

    Inherited by QGlaReAlgorithmMixin so that all algorithm classes gain
    these methods automatically.
    """

    # ------------------------------------------------------------------
    # CRS utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _horizontal_crs(crs):
        """Return the horizontal component of a CRS, falling back to the CRS itself.

        A compound / 3D CRS (e.g. a DEM with a projected horizontal CRS plus a vertical
        height CRS such as EPSG:5703) has no single EPSG code, so authid() returns "";
        the horizontal component carries the projected authority code and linear units,
        so validation, comparison and layer creation use it. On QGIS < 3.34 (no
        horizontalCrs), or when horizontalCrs() is invalid for a non-compound CRS, the
        original CRS is returned unchanged.
        """
        if crs is not None and _HAS_HORIZONTAL_CRS:
            horizontal = crs.horizontalCrs()
            if horizontal is not None and horizontal.isValid():
                return horizontal
        return crs

    # ------------------------------------------------------------------
    # DataFrame / layer utilities
    # ------------------------------------------------------------------

    def create_dataframe(self, temp_layer, attribute_names=None, feedback=None,
                         user_shear=None, include_geometry=False):
        """Build a Pandas DataFrame from a QGIS vector layer, one row per feature.

        Args:
            user_shear: if given, a constant shear stress in Pa added as a
                'shear_stress' column on every row.
            include_geometry: if True, add the point geometry as 'xcoord' and
                'ycoord' columns.

        Returns:
            One row per feature, with the requested attribute columns.
        """
        if not isinstance(temp_layer, QgsVectorLayer):
            raise ValueError("Input must be a QgsVectorLayer.")

        if attribute_names is None:
            attribute_names = [field.name() for field in temp_layer.fields()]

        data = []
        total_features = temp_layer.featureCount()

        for current_feature, feature in enumerate(temp_layer.getFeatures()):
            row = {name: feature.attribute(name) for name in attribute_names}

            if include_geometry:
                geom = feature.geometry().asPoint()
                row['xcoord'] = geom.x()
                row['ycoord'] = geom.y()

            if user_shear is not None:
                row['shear_stress'] = user_shear

            data.append(row)

            if feedback:
                feedback.setProgress(int((current_feature + 1) / total_features * 100))

        return pd.DataFrame(data)

    def load_dataframe_to_qgis(self, dataframe, crs, context,
                                layer_name='DataFrameLayer', feedback=None, group_name=None):
        """Import a Pandas DataFrame into QGIS as a point memory layer.

        Column types come from the first non-null value in each column: float ->
        Double, int -> Int, anything else -> String (using the version-appropriate
        field-type constants; see _FIELD_DOUBLE at module level). NaN is written as
        NULL. The layer takes the horizontal component of crs, so a compound / 3D
        source CRS yields clean 2D points.

        Args:
            dataframe: must include 'xcoord' and 'ycoord' columns for the point
                geometry.
            group_name: if given, place the layer under this layer-tree group
                (created if absent) instead of at the top level.
        """
        fields = QgsFields()
        for column in dataframe.columns:
            first = dataframe[column].dropna()
            sample = first.iloc[0] if not first.empty else None
            if isinstance(sample, (float, np.floating)):
                field_type = _FIELD_DOUBLE
            elif isinstance(sample, (int, np.integer)):
                field_type = _FIELD_INT
            else:
                field_type = _FIELD_STRING
            fields.append(QgsField(column, field_type))

        # Use the horizontal component so a compound/3D source CRS (e.g. a DEM with a
        # vertical height CRS) yields a clean 2D CRS on the output points. Assign via
        # setCrs() rather than the provider URI so a CRS without an authority code
        # (compound or fully custom) is still applied correctly.
        vector_layer = QgsVectorLayer('Point', layer_name, 'memory')
        vector_layer.setCrs(self._horizontal_crs(crs))
        vector_layer.dataProvider().addAttributes(fields)
        vector_layer.updateFields()

        features = []
        total = len(dataframe)
        for i, row in enumerate(dataframe.itertuples(index=False)):
            feat = QgsFeature(fields)
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(float(row.xcoord), float(row.ycoord))))
            for column, value in zip(dataframe.columns, row):
                feat.setAttribute(column, None if pd.isna(value) else value)
            features.append(feat)
            if feedback:
                feedback.setProgress(int((i + 1) / total * 100))
                if feedback.isCanceled():
                    break

        vector_layer.dataProvider().addFeatures(features)
        # Thread-safe load: hand the memory layer to the processing context's temporary
        # store and defer loading to completion, which runs on the GUI thread. Adding to
        # QgsProject or the layer tree directly here would run on a worker thread and can
        # crash the layer-tree model.
        context.temporaryLayerStore().addMapLayer(vector_layer)
        details = QgsProcessingContext.LayerDetails(layer_name, QgsProject.instance(), '')
        if group_name:
            self._set_layer_group(details, group_name)
        context.addLayerToLoadOnCompletion(vector_layer.id(), details)

    # ------------------------------------------------------------------
    # Flowline geometry utilities
    # ------------------------------------------------------------------

    def correct_distance_order(self, df, feedback=None):
        """Orient each flowline segment so distance increases from terminus to headwall.

        The reconstruction assumes distance = 0 is the downstream end (terminus or
        confluence) of every flowline. Vertex order, the only record of digitising
        direction, is arbitrary, so each branch is checked against the sampled bed
        elevation: ice flows downhill, so the downstream end must be the lower end. A
        branch whose distance = 0 end sits well above its far end was digitised
        head-to-terminus, and its distance axis is flipped (with a warning).

        Args:
            df: flowline points with 'cat' (segment id) and 'distance' columns. If
                'rvalue1' (sampled bed elevation) is present, digitising direction is
                checked per branch and reversed lines are corrected.

        Returns:
            The frame sorted ascending by distance within each 'cat', terminus-first.
        """
        df = df.sort_values(['cat', 'distance']).reset_index(drop=True)

        if 'rvalue1' not in df.columns:
            return df

        FLIP_TOLERANCE_M = 10.0   # ignore sub-noise elevation differences (e.g. flat tongues)
        flipped = []              # (cat, start_elev, end_elev) of every line we auto-correct
        for cat, group in df.groupby('cat'):
            bed = pd.to_numeric(group['rvalue1'], errors='coerce').to_numpy(dtype=float)
            bed = bed[np.isfinite(bed)]
            if bed.size < 2:
                continue
            n_end = max(1, min(3, bed.size // 2))   # average a few points per end (DEM noise)
            start_elev = bed[:n_end].mean()
            end_elev = bed[-n_end:].mean()
            if (start_elev - end_elev) > FLIP_TOLERANCE_M:
                d = pd.to_numeric(group['distance'], errors='coerce')
                df.loc[group.index, 'distance'] = d.max() + d.min() - d
                flipped.append((cat, start_elev, end_elev))

        if flipped:
            n = len(flipped)
            # full per-line detail goes to the file log
            log = getattr(self, '_log', None)
            if log:
                for c, s, e in flipped:
                    log(f"Flowline segment {c} was digitised head-to-terminus "
                        f"({s:.0f} m -> {e:.0f} m); its distance axis was flipped so "
                        f"the reconstruction builds up from the terminus.",
                        level='warning')
            # short summary goes to the QGIS log panel
            c0, s0, e0 = flipped[0]
            if n == 1:
                msg = (f"1 flowline may have been digitised from glacier head to "
                       f"terminus (flowline segment {c0}: {s0:.0f} m -> {e0:.0f} m). "
                       f"It was corrected. Consider reversing this line in the source "
                       f"layer. Full details in log.")
            else:
                msg = (f"{n} flowlines may have been digitised from glacier head to "
                       f"terminus (e.g. flowline segment {c0}: {s0:.0f} m -> {e0:.0f} m). "
                       f"All {n} flowlines were corrected. Consider reversing these "
                       f"lines in the source layer. Full details in log.")
            if feedback is not None:
                feedback.pushWarning(msg + "\n")
            df = df.sort_values(['cat', 'distance']).reset_index(drop=True)
        return df

    def _find_main_flow_cat(self, df):
        """Return the 'cat' of the main flowline (the branch holding the glacier terminus).

        The terminus is the point of minimum along-channel distance; using distance
        rather than assuming cat == 0 keeps this correct when cat numbering is arbitrary
        (e.g. after GRASS or QGIS network processing).
        """
        return df.loc[df['distance'].idxmin(), 'cat']

    def estimate_tributary_flow_direction(self, group_df):
        """Estimate a tributary's flow direction from points along its flowline.

        Args:
            group_df: points of a single tributary flowline, with 'distance' (along
                the flowline) and 'xcoord'/'ycoord' columns.

        Returns:
            A normalised 2D unit vector for the flow direction, or [0, 1] if it
            cannot be computed.
        """
        sorted_group = group_df.sort_values('distance')

        if len(sorted_group) < 3:
            start = sorted_group.iloc[0]
            end = sorted_group.iloc[-1]
            flow_vector = np.array([end['xcoord'] - start['xcoord'],
                                    end['ycoord'] - start['ycoord']])
        else:
            vectors = []
            weights = []
            for i in range(len(sorted_group) - 1):
                p1 = sorted_group.iloc[i]
                p2 = sorted_group.iloc[i + 1]
                vector = np.array([p2['xcoord'] - p1['xcoord'],
                                   p2['ycoord'] - p1['ycoord']])
                distance = np.linalg.norm(vector)
                if distance > 0:
                    vectors.append(vector / distance)
                    weights.append(distance)

            if vectors:
                flow_vector = np.average(vectors, axis=0, weights=weights)
            else:
                return np.array([0, 1])

        norm = np.linalg.norm(flow_vector)
        return flow_vector / norm if norm > 0 else np.array([0, 1])

    def calculate_flow_compatibility(self, trib_point, trib_flow_dir, candidates):
        """Cost of each candidate connection by how well it aligns with tributary flow.

        Args:
            trib_point: [x, y] of the tributary connection point.
            trib_flow_dir: normalised 2D unit vector of tributary flow direction.
            candidates: array of shape (n, 4) with columns [x, y, fid, elevation].

        Returns:
            Per-candidate cost, 0 for perfect alignment up to 2 for opposite flow.
        """
        connection_vectors = candidates[:, :2] - trib_point
        distances = np.linalg.norm(connection_vectors, axis=1)

        valid_mask = distances > 1e-6
        connection_vectors[~valid_mask] = 0.0
        connection_vectors[valid_mask] /= distances[valid_mask, np.newaxis]

        dot_products = np.dot(connection_vectors, trib_flow_dir)
        return 1 - dot_products

    def calculate_elevation_cost(self, trib_elev, candidate_elevs):
        """Elevation-based connection cost, penalising uphill links heavily.

        Args:
            trib_elev: elevation of the tributary connection point.
            candidate_elevs: elevations of the candidate connection targets.

        Returns:
            Per-candidate cost: uphill difference weighted 2x, downhill 0.1x.
        """
        elev_diff = candidate_elevs - trib_elev
        uphill_penalty = np.maximum(0, elev_diff) * 2
        downhill_penalty = np.maximum(0, -elev_diff) * 0.1
        return uphill_penalty + downhill_penalty

    def calculate_prox_id_flow_based(self, df, feedback=None):
        """Assign each flowline point its downstream neighbour via flow, elevation and distance costs.

        Args:
            df: flowline points with 'cat', 'distance', 'xcoord', 'ycoord', 'fid'
                and 'rvalue1' (bed elevation) columns.

        Returns:
            The frame with an added 'prox_id' column giving the downstream link
            (the fid each point flows toward).
        """
        if not df.empty:
            df = self.correct_distance_order(df, feedback)

        df['prox_id'] = np.nan

        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat].sort_values('distance')
        if not main_flowline.empty:
            df.loc[main_flowline.index[0], 'prox_id'] = np.nan

        for cat, group in df.groupby('cat'):
            if cat == main_flow_cat:
                continue

            group_sorted = group.sort_values('distance').copy()
            group_fids = group_sorted['fid'].values
            trib_flow_dir = self.estimate_tributary_flow_direction(group_sorted)

            # typical along-line point spacing, for the confluence-link sanity check below
            seg = np.hypot(np.diff(group_sorted['xcoord'].to_numpy(dtype=float)),
                           np.diff(group_sorted['ycoord'].to_numpy(dtype=float)))
            typical_spacing = float(np.nanmedian(seg)) if seg.size else 10.0

            for idx, (i, row) in enumerate(group_sorted.iterrows()):
                if idx == 0:
                    trib_point = np.array([row['xcoord'], row['ycoord']])
                    trib_elev = row['rvalue1']
                    potential_targets = df[df['cat'] != cat][['xcoord', 'ycoord', 'fid', 'rvalue1']]

                    if not potential_targets.empty:
                        candidates = potential_targets.to_numpy()
                        flow_compatibility = self.calculate_flow_compatibility(
                            trib_point, trib_flow_dir, candidates)
                        elevation_cost = self.calculate_elevation_cost(
                            trib_elev, candidates[:, 3])
                        distance_cost = np.sqrt((trib_point[0] - candidates[:, 0])**2 +
                                                (trib_point[1] - candidates[:, 1])**2)
                        total_cost = (distance_cost +
                                      elevation_cost * 20 +
                                      flow_compatibility * 100)
                        best_idx = np.argmin(total_cost)
                        df.at[row.name, 'prox_id'] = candidates[best_idx, 2]

                        # Sanity check: a healthy confluence link lands within a few
                        # point-spacings of the branch start. A distant link usually means
                        # a reversed flowline or a branch not snapped to the network, and
                        # the inherited surface will poison everything downstream of it.
                        link_dist = float(distance_cost[best_idx])
                        link_threshold = max(10.0 * typical_spacing, 100.0)
                        if np.isfinite(link_dist) and link_dist > link_threshold:
                            msg = (f"Tributary cat={cat}: confluence link is {link_dist:.0f} m "
                                   f"from the branch start (expected within ~{link_threshold:.0f} m). "
                                   f"Check the flowline digitising direction and that the branch "
                                   f"snaps to the network - reconstructed thickness downstream of "
                                   f"this link may be unreliable.")
                            log = getattr(self, '_log', None)
                            if log:
                                log(msg, level='warning')
                            if feedback is not None:
                                feedback.pushWarning(msg + "\n")
                    else:
                        df.at[row.name, 'prox_id'] = np.nan
                else:
                    df.at[row.name, 'prox_id'] = group_fids[idx - 1]

        return df

    def replace_zero_thickness_with_nearest_neighbor(self, df):
        """Fill zero ice-thickness points, keeping a genuine zero only at the terminus.

        Zeros are filled first from the prox_id neighbour's thickness, then by nearest
        non-zero point for any that remain.

        Args:
            df: points with 'fid', 'prox_id', 'ice_thickness', 'xcoord', 'ycoord',
                'cat' and 'distance' columns.

        Returns:
            The frame with zero 'ice_thickness' values replaced.
        """
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]

        if not main_flowline.empty:
            true_terminus_fid = main_flowline.loc[main_flowline['distance'].idxmin(), 'fid']
        else:
            true_terminus_fid = None

        if true_terminus_fid is not None:
            zero_mask = (df['ice_thickness'] == 0) & (df['fid'] != true_terminus_fid)
        else:
            zero_mask = (df['ice_thickness'] == 0)

        if not zero_mask.any():
            return df

        df_zero = df[zero_mask].copy()
        df_nonzero = df[df['ice_thickness'] != 0].copy()

        thickness_map = df.set_index('fid')['ice_thickness']
        df_zero['prox_thickness'] = df_zero['prox_id'].map(thickness_map)
        valid_prox = df_zero['prox_thickness'].notna() & (df_zero['prox_thickness'] > 0)
        df_zero.loc[valid_prox, 'ice_thickness'] = df_zero.loc[valid_prox, 'prox_thickness']

        still_zero = (df_zero['ice_thickness'] == 0)
        if still_zero.any():
            if df_nonzero.empty:
                raise QgsProcessingException(
                    "Cannot replace zero-thickness points: no non-zero thickness points exist in this dataset. "
                    "Check that the input ice thickness data contains valid non-zero values."
                )
            zero_coords = df_zero.loc[still_zero, ['xcoord', 'ycoord']].to_numpy()
            nonzero_coords = df_nonzero[['xcoord', 'ycoord']].to_numpy()
            nonzero_thickness = df_nonzero['ice_thickness'].to_numpy()

            diff = zero_coords[:, np.newaxis, :] - nonzero_coords[np.newaxis, :, :]
            dists = np.sqrt(np.sum(diff**2, axis=2))
            nearest_idx = np.argmin(dists, axis=1)
            df_zero.loc[still_zero, 'ice_thickness'] = nonzero_thickness[nearest_idx]

        df_zero = df_zero.drop(columns=['prox_thickness'])  # redundant (update call selects only ice_thickness), kept for clarity
        df.update(df_zero[['ice_thickness']])
        return df
