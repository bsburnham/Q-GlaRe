"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D shape-factor FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, math, traceback, processing
from .qglare_base import QGlaReAlgorithmMixin
from .qglare_utils import normalise_shapefile_field_names
import numpy as np
import pandas as pd
from qgis.PyQt.QtCore import QVariant, QMetaType, QUrl
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (Qgis,
                       QgsField,
                       QgsFields,
                       QgsProject,
                       QgsPointXY,
                       QgsFeature,
                       QgsGeometry,
                       QgsWkbTypes,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsRasterLayer,
                       QgsVectorLayer,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingUtils)

# QGIS version compatibility: GeometryType moved to Qgis enum in 3.30
try:
    _POINT_GEOMETRY = Qgis.GeometryType.Point
except AttributeError:                          # QGIS < 3.30
    _POINT_GEOMETRY = QgsWkbTypes.PointGeometry

# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38 -
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
_FIELD_DOUBLE = QMetaType.Type.Double if Qgis.QGIS_VERSION_INT >= 33800 else QVariant.Double

# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_RASTER = Qgis.ProcessingSourceType.Raster
    _SOURCE_VECTOR_POINT = Qgis.ProcessingSourceType.VectorPoint
    _SOURCE_VECTOR_LINE = Qgis.ProcessingSourceType.VectorLine
except AttributeError:                          # QGIS < 3.36
    _SOURCE_RASTER = QgsProcessing.TypeRaster
    _SOURCE_VECTOR_POINT = QgsProcessing.TypeVectorPoint
    _SOURCE_VECTOR_LINE = QgsProcessing.TypeVectorLine

class Ffactor(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """Apply the shape friction factor (F-factor) to refine ice thickness.

    The F-factor quantifies flow resistance from lateral drag, computed from each
    transect's cross-sectional area and perimeter (Nye 1965). It is estimated per
    transect, propagated to the flowline points, and used to adjust the basal
    shear stress when the equilibrium ice surface (Nye 1952; Benn and Hulton 2010)
    is reconstructed along every flowline.

    References:
        Nye, J.F., 1952. The mechanics of glacier flow. Journal of Glaciology 2,
            82–93.
        Nye, J.F., 1965. The flow of a glacier in a channel of rectangular,
            elliptic or parabolic cross-section. Journal of Glaciology 5,
            661–690.
        Shilling, D.H., Hollin, J.T., 1981. Numerical reconstructions of valley
            glaciers and small icecaps. In: Denton, G.H., Hughes, T.J. (Eds.),
            The Last Great Ice Sheets. Wiley, New York, 207–220.
        Benn, D.I., Hulton, N.R.J., 2010. An Excel spreadsheet program for
            reconstructing the surface profile of former mountain glaciers and
            ice caps. Computers & Geosciences 36, 605–610.
    """

    N_STEPS = 18
    _log_tag = '2D shape-factor FL Ice Thickness Processing Log'

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    shear_stress = 'specify_shear_stress'
    input_flowline = 'input_flowline'
    input_transects = 'transects'
    ice_flow_thickness = 'ice_flow_thickness'

    def name(self):
        """Internal algorithm id used by QGIS."""

        return 'F-Factor'

    def displayName(self):
        """Name shown in the QGIS toolbox."""
        
        return '3. 2D shape-factor FL Ice Thickness'

    def group(self):
        """Toolbox group this algorithm sits under."""

        return '\u200aQ-GlaRe'

    def groupId(self):
        """Unique id of the toolbox group."""

        return '1_q-glare'
       
    def tr(self, text):
        """Translate a string through Qt's localisation."""

        return QCoreApplication.translate("2 F-Factor", text)

    def setProgressText(self, text):
        """Print progress text when running outside the QGIS console."""

        print(text)

    def shortHelpString(self):
        """Help-panel text for the toolbox, with the tool icon as an HTML header."""
        
        # Add the tool icon to the top of the help text (rendered as HTML).
        icon_url = QUrl.fromLocalFile(
            os.path.join(os.path.dirname(__file__), 'icons', 'ffactor.png')).toString()
        header = ('<img src="%s" width="28" height="27"/>&nbsp;&nbsp;'
                  '<b>2D shape-factor FL ice thickness</b>\n\n' % icon_url)

        return header + self.tr(
            "The <b>shape friction factor (F-Factor)</b> quantifies flow resistance due to lateral drag. "
            "It is calculated based on the cross-sectional area and perimeter length of the glacier profile. "
            "The F-Factor is computed for all input points and applied to re-estimate ice thickness and "
            "surface elevation at each point.\n\n"
            "The specified shear stress value will be applied to all data. \n\n"
            "A new vector point file is created from the specified input data. \n\n"
            "N.B. See Nye (1952a, b), Nye (1965), Shilling and Hollin (1981), and Benn and Hulton (2010) "
            "for detailed information on the F-Factor.\n\n"
            "<b>References:</b>\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the Ice-Sheets. "
            "Nature 169, pp. 529–530.\n"
            "  - Nye, J.F., 1965. The flow of a glacier in a channel of rectangular, elliptic or parabolic cross-section. "
            "Journal of Glaciology 5, pp. 661–690.\n"
            "  - Shilling, D.H., Hollin, J.T., 1981. Numerical reconstructions of valley glaciers and small icecaps. "
            "In: Denton, G.H., Hughes, T.J. (Eds.), The Last Great Ice Sheets. Wiley, New York, pp. 207–220.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program for reconstructing the surface profile "
            "of former mountain glaciers and ice caps. Computers & Geosciences 36, pp. 605–610.")
    
    def createInstance(self):
        """Return a fresh instance for QGIS to run."""

        return Ffactor()

    def createCustomParametersWidget(self, parent=None):
        """
        Build the tool dialog with the icon at the top and the inputs grouped into
        collapsible sections. Falls back to the standard dialog if it cannot be built.
        """
        try:
            from .grouped_dialog import build_grouped_dialog
            DialogCls = build_grouped_dialog(
                os.path.dirname(__file__), "ffactor.png", "Shape-factor ice thickness",
                sections=[
                    ("Inputs", False, [
                        "InputDEM", "ice_flow_thickness", "transects", "input_flowline"]),
                    ("Parameters", False, ["specify_shear_stress"]),
                ])
            return DialogCls(self, parent=parent)
        except Exception:
            return None

    def icon(self):
        """Toolbox icon for this algorithm."""
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'ffactor.png')  # Ensure this is the correct filename

        # Return the QIcon
        return QIcon(icon_file)
        
    def initAlgorithm(self, config=None):
        """Define the input parameters: DEM, ice thickness points, transects, flowline, shear stress."""
        
        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem, 
        self.tr("\nSelect current topography elevation data (DSM/DTM)"),
        [_SOURCE_RASTER]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.ice_flow_thickness, 
        self.tr("\nSelect ice flow thickness points (vector point file)"),
        [_SOURCE_VECTOR_POINT]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_transects,
        self.tr("\nSelect transect lines (vector polyline file)"),
        [_SOURCE_VECTOR_LINE]))
        
        self.addParameter(QgsProcessingParameterVectorLayer( 
        self.input_flowline, 
        self.tr("\nSelect flow line (vector polyline file)"),
        [_SOURCE_VECTOR_LINE]))
        
        self.addParameter(QgsProcessingParameterNumber(
        self.shear_stress, 
        self.tr("\nSpecify shear stress value"),
        QgsProcessingParameterNumber.Integer, minValue=0, defaultValue=100000))

    def processAlgorithm(self, parameters, context, model_feedback):
        """Run the F-factor estimation and correct ice thickness along the flowlines."""
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)

        try:
            self._init_logger('ffactor', feedback)
            return self._run_algorithm_body(parameters, context, feedback)
        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )

    def _run_algorithm_body(self, parameters, context, feedback):
        # Preprocess and validate inputs
        inputs = self.preprocess_inputs(parameters, context, feedback)
        dem = inputs["dem"]
        dem_file = inputs["dem_file"]
        crs = inputs["crs"]
        crs_string = inputs["crs_string"]
        shear = inputs["shear"]
        ice_pts = inputs["ice_pts"]
        ice_thickness_pts_file = inputs["ice_thickness_pts_file"]
        flowline = inputs["flowline"]
        flowline_file = inputs["flowline_file"]
        transects = inputs["transects"]
        transects_file = inputs["transects_file"]

        # Generate the interval distance using the ice thickness points layer
        distance = self.point_distance(ice_pts)

        # Log initial parameters and start time
        start_time = time.time()
        self.log_initialization(feedback, dem_file, ice_thickness_pts_file, distance, flowline_file,
                                transects_file, shear)
        self._log_run_header({
            'DEM':                   f"{dem_file} ({dem.source()})",
            'Ice Thickness Points':   ice_thickness_pts_file,
            'Flowline':               flowline_file,
            'Transects':              transects_file,
            'Shear Stress (kPa)':     shear,
            'Point Interval (m)':     f"{distance:.1f}",
            'CRS':                    crs_string,
        })
        self._log_layer_crs([
            ('DEM',                  dem),
            ('Ice Thickness Points',  ice_pts),
            ('Flowline',              flowline),
            ('Transects',             transects),
        ])

        # Process transects
        transects_processed = self.process_transects(transects, context, feedback)

        # Generate points along transects
        transect_points = self.generate_points_along_transects(transects_processed, distance, dem, context, feedback)
        if feedback.isCanceled():
            return {}

        # Process intersections
        intersections = self.process_intersections(transects_processed, flowline, dem, context, feedback)
        if feedback.isCanceled():
            return {}

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        self.log_initialization(feedback, stage="input_processed")
        self.log_processing_duration("Pre-process input data", start_time)

        # Convert layers to DataFrame
        df_start_time = time.time()
        intersection_with_coords = self.add_xy_coordinates(intersections, "Intersection Points with X/Y", feedback)
        transect_points_with_coords = self.add_xy_coordinates(transect_points, "Sampled Points with X/Y", feedback)
        intersection_df = self.create_dataframe(intersection_with_coords, feedback=feedback)
        ice_pts_df = self.create_dataframe(transect_points_with_coords, feedback=feedback)
        ff_calc_df = self.create_dataframe(ice_pts, feedback=feedback)
        ff_calc_df = normalise_shapefile_field_names(ff_calc_df)
        ff_calc_df = self.correct_distance_order(ff_calc_df, feedback)   # guarantee terminus→headwall order
        transect_cat_map = self._map_transects_to_cats(transects_processed, ff_calc_df, context)
        transect_df = self.pre_process_dataframe(ice_pts_df)
        self.log_initialization(feedback, stage="data_prep")
        self.log_processing_duration("Data processed for calculation", df_start_time)

        # F-factor estimation
        ff_start_time = time.time()
        ffactor = self.calculate_ffactor(transect_df, feedback)
        ffactor_csv = ffactor.copy()
        self.log_initialization(feedback, stage="estimate_ffactor")
        self.log_processing_duration("F-factor calculation", ff_start_time)

        # Spatial linking flowlines and tributary branches
        link_start_time = time.time()
        ff_calc_linked = self.assign_transect_id(ff_calc_df, intersection_df, ffactor_csv, transect_cat_map)
        self.log_initialization(feedback, stage="tributary_centreline")
        self.log_processing_duration("Spatially linked tributary branches and centreline", link_start_time)

        # Propagate F-factor
        prop_start_time = time.time()
        ffactor_prop = self.propagate_ffactor(ff_calc_linked, ffactor_csv)
        self.log_initialization(feedback, stage="apply_ffactor")
        self.log_processing_duration("2D shape-factor propagation to ice thickness", prop_start_time)

        # Correct ice thickness
        recon_start_time = time.time()
        result_df = self.ice_reconstruction_with_ffactor(ffactor_prop, shear, feedback=feedback)
        self.log_initialization(feedback, stage="calculate_corrected")
        self.log_processing_duration("Calculate 2D shape-factor corrected ice thickness", recon_start_time)

        # Validate and load results
        val_start_time = time.time()
        validated_df, valid_percentage, invalid_points = self.validate_driving_stress(result_df)
        self.log_initialization(feedback, stage="validation", valid_percentage=valid_percentage, invalid_points=invalid_points)
        self.log_processing_duration("Ice surface and thickness validation", val_start_time)

        load_start_time = time.time()
        self.load_dataframe_to_qgis(validated_df, crs, context, feedback=feedback,
                                    layer_name="2D shape-factor FL Ice Thickness",
                                    group_name="Q-GlaRe Ice Thickness Points")
        self.log_initialization(feedback, stage="load_qgis")
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", load_start_time)

        self.log_final_results(feedback, crs_string, start_time)
        self._log_success(feedback)

        results = {"Status": "Complete"}
        return results

    def preprocess_inputs(self, parameters, context, feedback):
        """Read and validate the DEM, ice thickness points, flowline and transects.

        Reprojects each vector layer to the DEM CRS, checks the DEM is projected,
        and rejects the case where the flowline and transects are the same layer.
        Returns the validated layers and CRS details in a dict.
        """

        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)
        if dem is None or not dem.isValid():
            raise QgsProcessingException(
                "The input DEM layer could not be retrieved or is not valid. "
                "Please select a valid raster layer."
            )
        dem_file = dem.source()
        crs = dem.crs()
        crs_string = crs.authid() if crs and crs.isValid() else 'Unknown CRS'

        shear = self.parameterAsInt(parameters, self.shear_stress, context)

        ice_pts = self.parameterAsVectorLayer(parameters, self.ice_flow_thickness, context)
        if ice_pts is None or not ice_pts.isValid():
            raise QgsProcessingException(
                "The ice thickness points layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        ice_thickness_pts_file = ice_pts.name()

        flowline = self.parameterAsVectorLayer(parameters, self.input_flowline, context)
        if flowline is None or not flowline.isValid():
            raise QgsProcessingException(
                "The input flowline layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        flowline_file = flowline.name()

        transects = self.parameterAsVectorLayer(parameters, self.input_transects, context)
        if transects is None or not transects.isValid():
            raise QgsProcessingException(
                "The input transects layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        transects_file = transects.name()

        if flowline.id() == transects.id() or flowline.source() == transects.source():
            raise QgsProcessingException(
                "The flowline and transects inputs appear to be the same layer. "
                "Please select different layers for each input."
            )

        # Clean geometries - remove any empty geometries
        transects_cleaned = self.remove_empty_geometries(transects, context)
        transects = transects_cleaned

        # Validate CRS first so that subsequent checks (e.g. flowline/transect
        # length comparison) use projected metres rather than the original units.
        flowline = self.validate_layer_crs(flowline, crs, context, feedback)
        transects = self.validate_layer_crs(transects, crs, context, feedback)
        ice_pts = self.validate_layer_crs(ice_pts, crs, context, feedback)
        self.validate_projected_crs(dem, feedback)

        # Validate layers (after reprojection so lengths are in map units)
        self.validate_flowline_and_transect(flowline, transects)
        self.validate_dem_input(dem)
        self.validate_input_points(ice_pts)

        return {
            "dem": dem,
            "dem_file": dem_file,
            "crs": crs,
            "crs_string": crs_string,
            "shear": shear,
            "ice_pts": ice_pts,
            "ice_thickness_pts_file": ice_thickness_pts_file,
            "flowline": flowline,
            "flowline_file": flowline_file,
            "transects": transects,
            "transects_file": transects_file
        }
    
    def process_transects(self, transects, context, feedback):
        """Give each transect a stable 'transect_id'.

        Preserves the original Id, rebuilds Id from the row number, drops the
        duplicate lower-case 'id', then adds an auto-increment 'transect_id'.
        """


        # Preserve the original 'Id' field if it exists
        params_preserve_id = {
            'FIELD_NAME': 'original_Id',
            'FIELD_TYPE': 1,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 0,
            'FORMULA': 'coalesce("Id", "ID", "id", @row_number)',  # Use original Id or fallback to row number
            'INPUT': transects,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        layer_with_original = self._run_algorithm(
            'native:fieldcalculator', params_preserve_id, context, feedback,
            output_key='OUTPUT', step_name='Preserve original transect Id field'
        )['OUTPUT']

        
        # Add new 'Id' field using the field calculator
        params_add_field = {
            'FIELD_NAME': 'Id',
            'FIELD_TYPE': 1,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 0,
            'FORMULA': '@row_number + 1',
            'INPUT': layer_with_original,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        layer_id = self._run_algorithm(
            'native:fieldcalculator', params_add_field, context, feedback,
            output_key='OUTPUT', step_name='Add transect Id field'
        )['OUTPUT']

        # Remove the unwanted 'id' field
        params_delete_field = {
            'INPUT': layer_id,
            'COLUMN': ['id'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        transects_no_id = self._run_algorithm(
            'native:deletecolumn', params_delete_field, context, feedback,
            output_key='OUTPUT', step_name='Remove duplicate id field from transects'
        )['OUTPUT']

        # Add auto-incremental field to create a proper transect identifier
        params_auto_field = {
            'FIELD_NAME': 'transect_id',
            'GROUP_FIELDS': None,
            'INPUT': transects_no_id,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        transects_with_id = self._run_algorithm(
            'native:addautoincrementalfield', params_auto_field, context, feedback,
            output_key='OUTPUT', step_name='Add transect_id incremental field'
        )['OUTPUT']

        return transects_with_id

    def generate_points_along_transects(self, transects_layer, distance, dem, context, feedback):
        """Break each transect into points, sample the DEM at each, and add xcoord/ycoord fields."""

        # Break transect lines into points
        params_points = {
            'DISTANCE': distance,
            'END_OFFSET': 0,
            'INPUT': transects_layer,
            'START_OFFSET': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        points_result = self._run_algorithm(
            'native:pointsalonglines', params_points, context, feedback,
            output_key='OUTPUT', step_name='Break transects into points'
        )
        points_layer = points_result['OUTPUT']
        self._check_layer_features(
            points_layer, context, 'Break transects into points',
            "No points were generated along transects. "
            "Check that your point interval is smaller than your transect length."
        )
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Sample DEM values at the generated points
        params_sampling = {
            'COLUMN_PREFIX': 'values',
            'INPUT': points_layer,
            'RASTERCOPY': dem,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        sampling_result = self._run_algorithm(
            'native:rastersampling', params_sampling, context, feedback,
            output_key='OUTPUT', step_name='Sample DEM at transect points'
        )
        sampled_layer = sampling_result['OUTPUT']
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Add X and Y coordinate fields
        params_xy = {
            'CALC_METHOD': 0,  # 0 = Layer CRS
            'INPUT': sampled_layer,
            'OUTPUT': f'/vsimem/temp_x-y_coords_{id(self)}'
        }
        xy_result = self._run_algorithm(
            'qgis:exportaddgeometrycolumns', params_xy, context, feedback,
            output_key='OUTPUT', step_name='Add X/Y coordinates to transect points'
        )
        return xy_result['OUTPUT']

    def process_intersections(self, transects_layer, flowline, dem, context, feedback):
        """Compute transect-flowline intersection points and sample the DEM at each."""

        params_intersect = {
            'INPUT': transects_layer,
            'INPUT_FIELDS': [''],
            'INTERSECT': flowline,
            'INTERSECT_FIELDS': [''],
            'INTERSECT_FIELDS_PREFIX': 'fl_',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        intersect_result = self._run_algorithm(
            'native:lineintersections', params_intersect, context, feedback,
            output_key='OUTPUT', step_name='Compute transect-flowline intersections'
        )
        intersection_layer = intersect_result['OUTPUT']
        self._check_layer_features(
            intersection_layer, context, 'Compute transect-flowline intersections',
            "No intersections found between transects and the flowline. "
            "Check that your transect lines cross the flowline."
        )
        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        params_sampling = {
            'COLUMN_PREFIX': 'rvalue',
            'INPUT': intersection_layer,
            'RASTERCOPY': dem,
            'OUTPUT': f'/vsimem/temp_intersect_pts_{id(self)}'
        }
        intersect_sampling = self._run_algorithm(
            'native:rastersampling', params_sampling, context, feedback,
            output_key='OUTPUT', step_name='Sample DEM at intersection points'
        )
        sampled_intersections = intersect_sampling['OUTPUT']
        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        return sampled_intersections

    def _map_transects_to_cats(self, transects_layer, ff_calc_df, context):
        """
        For each transect, find which ice_pts branch (cat) it was drawn for.

        Computes the minimum distance from each cat's ice_pts to each transect line.
        The transect physically crosses the target branch, so its ice_pts have near-zero
        distance; other branches are measurably further away.
        """
        ice_coords = ff_calc_df[['xcoord', 'ycoord']].values
        ice_cats   = ff_calc_df['cat'].values
        unique_cats = ff_calc_df['cat'].unique()
        cat_pts = {cat: ice_coords[ice_cats == cat] for cat in unique_cats}

        if isinstance(transects_layer, QgsVectorLayer):
            lyr = transects_layer
        else:
            lyr = QgsProcessingUtils.mapLayerFromString(transects_layer, context)

        transect_cat_map = {}
        for feat in lyr.getFeatures():
            tid = feat['transect_id']
            geom = feat.geometry()
            verts = np.array([[v.x(), v.y()] for v in geom.vertices()])
            if len(verts) < 2:
                continue

            # Segment vectors for the transect polyline
            a = verts[:-1]           # (S, 2) segment starts
            b = verts[1:]            # (S, 2) segment ends
            d = b - a                # (S, 2) directions
            seg_len_sq = (d ** 2).sum(axis=1)  # (S,)

            best_cat, best_dist = None, np.inf
            for cat, pts in cat_pts.items():
                # pts: (N, 2)  a, b, d: (S, 2)  seg_len_sq: (S,)
                pa = pts[:, np.newaxis, :] - a[np.newaxis, :, :]          # (N, S, 2)
                t  = (pa * d[np.newaxis, :, :]).sum(axis=2)               # (N, S)
                t  = np.clip(t / np.where(seg_len_sq > 0, seg_len_sq, 1), 0, 1)  # (N, S)
                proj = a[np.newaxis, :, :] + t[:, :, np.newaxis] * d[np.newaxis, :, :]  # (N, S, 2)
                dists = np.sqrt(((pts[:, np.newaxis, :] - proj) ** 2).sum(axis=2))  # (N, S)
                min_dist = dists.min()
                if min_dist < best_dist:
                    best_dist, best_cat = min_dist, cat

            transect_cat_map[tid] = best_cat

        self._log(f"_map_transects_to_cats: {transect_cat_map}")
        return transect_cat_map

    def get_longest_line_length(self, layer):
        """Return the length of the longest line in a line or multi-line layer (0.0 if none)."""
        
        longest = 0.0
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            # Get a list of polylines (one for single-part, many for multi-part)
            lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]

            # Compute lengths and update 'longest' if we find a longer one
            for line in lines:
                length = QgsGeometry.fromPolylineXY(line).length()
                if length > longest:
                    longest = length

        return longest

    def remove_empty_geometries(self, layer, context):
        """Return a copy of ``layer`` with empty or null geometries dropped."""
        
        # Filter valid geometries
        valid_features = []
        for f in layer.getFeatures():
            if f.geometry() and not f.geometry().isEmpty():
                valid_features.append(f)
        
        # Create clean layer, preserving the original layer name
        clean = QgsVectorLayer(
            f"LineString?crs={layer.crs().authid()}",
            layer.name(),
            "memory"
        )
        clean.dataProvider().addAttributes(layer.fields())
        clean.updateFields()
        clean.dataProvider().addFeatures(valid_features)
        
        return clean
    
    def validate_flowline_and_transect(self, flowline_layer, transect_layer):
        """Check the flowline is longer than the longest transect.

        Raises if the flowline's longest line is not strictly longer than the
        transect layer's longest line, a guard against swapped inputs.
        """

        flowline_longest = self.get_longest_line_length(flowline_layer)
        transect_longest = self.get_longest_line_length(transect_layer)

        # Check that the input flowline layer is longer than the input transect layer.
        if flowline_longest <= transect_longest:
            raise QgsProcessingException(
                "Invalid input: Please ensure you have selected the correct flowline"
                " and transect/cross-section layers.\n"
            )
        
        return

    def validate_dem_input(self, input_raster):
        """Reject the raster if it looks like a hillshade rather than a DEM.

        Flags it by name, or by a 0-255 value range with low standard deviation.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected raster layer is missing or invalid.\n\n"
                "Please ensure you have selected a valid DEM.\n"
            )

        # Check filename for "hillshade" or similar keywords
        hillshade_keywords = ["hillshade", "hillShade", "HillShade", "Hillshade", "HILLSHADE"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be valid DEM.\n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be valid DEM. \n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

    def validate_input_points(self, input_layer):
        """Check the ice thickness points layer carries the required fields.

        Required: cat, distance, prox_id, ice_thickness, ice_surface, fid,
        xcoord, ycoord, rvalue1. Shapefile-truncated names (first 10 characters)
        are accepted.
        """

        # Required fields
        required_fields = {'cat', 'distance', 'prox_id', 'ice_thickness', 'ice_surface',
                           'fid', 'xcoord', 'ycoord', 'rvalue1'}

        # Ensure the layer is valid
        if not input_layer or not input_layer.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected points layer is missing or invalid.\n\n"
                "Please ensure you have selected the correct layer."
            )

        # Check if required fields exist in the layer.
        # Accept Shapefile-truncated names (e.g. 'ice_surfac' for 'ice_surface').
        layer_fields = {field.name() for field in input_layer.fields()}
        missing_fields = {f for f in required_fields
                          if f not in layer_fields and f[:10] not in layer_fields}

        if missing_fields:
            raise QgsProcessingException(
                f"Invalid input: The selected points layer is missing required fields.\n\n"
                "Please execute, or re-execute, '2D FL Ice Thickness'.\n"
            )

        return True
    
    def log_initialization(self, feedback, dem_filename=None, ice_thick_name=None, 
                           distance=None, flowline_name=None, transects_name=None, 
                           shear=None, stage=None, valid_percentage=None, invalid_points=None):
        """Write initialisation details, or a stage-specific progress message when ``stage`` is given."""

        if stage is None:
            # Log initialisation details
            feedback.setProgress(0)
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initialising 2D shape-factor FL Ice Thickness Calculation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo('Input Parameters:')
            feedback.pushInfo(f'  - DEM: {dem_filename}')
            feedback.pushInfo(f'  - Ice flow thickness points: {ice_thick_name}')
            feedback.pushInfo(f"  - Resolution (map units): {distance:.2f}")
            feedback.pushInfo(f'  - Flowline: {flowline_name}')
            feedback.pushInfo(f'  - Transects: {transects_name}')
            feedback.pushInfo(f'  - Shear value: {shear}')
            feedback.pushInfo('-------------------------------------------------------------\n')
            feedback.setProgressText('Pre-processing input data...\n')
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "estimate_ffactor":
            feedback.setProgressText("Estimating the 2D shape-factor of given ice flow thickness...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "apply_ffactor":
            feedback.setProgressText("Applying and propagating 2D shape-factor...\n")
        elif stage == "calculate_corrected":
            feedback.setProgressText("Correcting ice surface and thickness with 2D shape-factor...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 80:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushWarning(f"Invalid driving stress points (fid): {invalid_points}\n")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def point_distance(self, ice_pts):
        """Return the point spacing as the distance between the first two points.

        Sorts features by 'fid' first; raises if the layer has fewer than two
        points.
        """

        if not ice_pts or ice_pts.featureCount() < 2:
            raise QgsProcessingException(
                "The ice thickness points layer must contain at least two points. "
                "Check that the correct layer has been selected."
            )
        
        # Extract features and sort by 'fid' to ensure sequential order
        features = sorted(ice_pts.getFeatures(), key=lambda f: f['fid'])

        # Get the first two points
        first_point = features[0]
        second_point = features[1]

        # Extract x and y coordinates
        x1, y1 = first_point['xcoord'], first_point['ycoord']
        x2, y2 = second_point['xcoord'], second_point['ycoord']

        # Calculate the Euclidean distance
        distance = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5

        return distance
         
    def add_xy_coordinates(self, input_layer_path, layer_name, feedback=None):
        """Load a point layer and add 'xcoord'/'ycoord' fields from each geometry."""

        # Load the layer from the input path
        layer = QgsVectorLayer(input_layer_path, layer_name, "ogr")

        if not layer.isValid():
            raise ValueError(f"Failed to load layer from path: {input_layer_path}")

        if layer.geometryType() != _POINT_GEOMETRY:
            raise ValueError("Expected a Point geometry layer, but got something else.")

        # Start editing to add attributes
        layer.startEditing()
        layer.addAttribute(QgsField('xcoord', _FIELD_DOUBLE))
        layer.addAttribute(QgsField('ycoord', _FIELD_DOUBLE))

        # Populate X and Y coordinates for each feature
        for feature in layer.getFeatures():
            geom = feature.geometry()
            if geom.isEmpty():
                feature['xcoord'] = None
                feature['ycoord'] = None
            else:
                point = geom.asPoint()
                feature['xcoord'] = point.x()
                feature['ycoord'] = point.y()
            layer.updateFeature(feature)

        layer.commitChanges()
        return layer
    
    def pre_process_dataframe(self, df):
        """Rename any id/name column ('fid', 'Id', 'name', ...) to 'grp_id'."""

        # Define the column names to check and replace
        columns_to_replace = ['FID', 'Fid', 'fid', 'ID', 'Id', 'id', 'NAME', 'Name', 'name']

        # Iterate through the columns and replace if necessary
        for column in columns_to_replace:
            if column in df.columns:
                df = df.rename(columns={column: 'grp_id'})

        return df
    
    def calculate_ffactor(self, df, feedback=None):
        """Compute the shape factor (F-factor) for each transect.

        Sorts by transect and along-transect distance, then integrates the
        cross-sectional area A and perimeter P between successive points and takes
        the height range HH. The F-factor is total_A / (HH * total_P), mapped back
        onto every point of the transect; flat or zero-perimeter transects give
        NaN rather than dividing by zero.

        Args:
            df: transect points with 'transect_id', 'distance' (along-transect,
                metres) and 'values1' (sampled elevation, metres).

        Returns:
            The frame with added 'A', 'P', 'HH' and 'ffactor' columns.
        """

        # Ensure DataFrame is sorted by transect_id and distance
        df = df.sort_values(['transect_id', 'distance'])

        # Group by transect_id
        grouped = df.groupby('transect_id')

        # Initialise columns for A, P, and HH
        df['A'] = np.nan
        df['P'] = np.nan
        df['HH'] = np.nan 

        # Calculate A and P for each group
        for transect_id, group in grouped:
            distances = group['distance'].values
            elevations = group['values1'].values

            # Calculate A (cross-sectional area)
            A_values = 0.5 * (np.diff(distances) *
                            ((elevations.max() - elevations[:-1]) +
                            (elevations.max() - elevations[1:])))
            df.loc[group.index[1:], 'A'] = A_values

            # Calculate P (perimeter)
            P_values = np.sqrt(np.diff(distances)**2 + np.diff(elevations)**2)
            df.loc[group.index[1:], 'P'] = P_values

            # Calculate HH (height difference)
            height_diff = elevations.max() - elevations.min()
            df.loc[group.index, 'HH'] = height_diff

        # Calculate total A, P, and HH for each group
        total_A = grouped['A'].sum()
        total_P = grouped['P'].sum()
        height_diff = grouped['HH'].max() 

        # Calculate F-Factor (guard against flat or zero-perimeter transects)
        denominator = (height_diff * total_P).replace(0, np.nan)
        f_factor = total_A / denominator

        # Map F-Factor back to the original DataFrame
        df['ffactor'] = df['transect_id'].map(f_factor)

        return df
        
    def assign_transect_id(self, ff_calc, intersection_df, ffactor_csv, transect_cat_map):
        """Assign a 'transect_id' to every flowline point.

        Anchors each transect to the nearest upstream point on the branch it
        crosses, propagates that id up each branch by along-channel distance, then
        carries ids across confluences via 'prox_id' until every point is covered.
        """
        
        if 'transect_id' not in ff_calc.columns:
            ff_calc['transect_id'] = np.nan

        self._log(f"assign_transect_id: {len(intersection_df)} intersection(s), "
                  f"{len(ff_calc)} flowline point(s), "
                  f"cats={sorted(ff_calc['cat'].unique().tolist())}")

        # Vectorized distance calculation for all intersections
        flowline_coords = ff_calc[['xcoord', 'ycoord']].values
        intersection_coords = intersection_df[['xcoord', 'ycoord']].values
        distances = np.linalg.norm(flowline_coords[:, np.newaxis, :] - intersection_coords[np.newaxis, :, :], axis=2)

        intersection_cats = []
        for _, row in intersection_df.iterrows():
            cat = transect_cat_map.get(row['transect_id'])
            if cat is None:
                int_xy = np.array([row['xcoord'], row['ycoord']])
                cat = ff_calc.iloc[np.linalg.norm(flowline_coords - int_xy, axis=1).argmin()]['cat']
            intersection_cats.append(cat)
        self._log(f"assign_transect_id: transect→cat: "
                  f"{list(zip(intersection_df['transect_id'].tolist(), intersection_cats))}")

        # Direct assignment: for each intersection independently, find the
        # closest upstream flowline point within the same segment and anchor it.
        for i, (_, intersection) in enumerate(intersection_df.iterrows()):
            transect_id = intersection['transect_id']
            intersection_cat = intersection_cats[i]

            same_segment_mask = ff_calc['cat'] == intersection_cat
            same_segment_points = ff_calc[same_segment_mask]

            # Spatial anchor: find closest flowline point in this cat to the intersection coordinate
            seg_distances_to_intersection = distances[same_segment_mask.values, i]
            closest_point_idx = seg_distances_to_intersection.argmin()
            closest_point_distance = same_segment_points.iloc[closest_point_idx]['distance']

            # Upstream = higher along-channel distance (upvalley from terminus)
            upstream_mask = same_segment_points['distance'] >= closest_point_distance
            upstream_candidates = same_segment_points[upstream_mask].copy()

            if not upstream_candidates.empty:
                segment_distances = distances[same_segment_mask.values, i][upstream_mask.values]
                upstream_candidates['weighted_distance'] = segment_distances
                closest_upstream_idx = upstream_candidates['weighted_distance'].idxmin()
                ff_calc.loc[closest_upstream_idx, 'transect_id'] = transect_id

        direct_assigned = ff_calc['transect_id'].notna().sum()
        self._log(f"assign_transect_id: {direct_assigned} point(s) assigned in direct step")

        # Segment-based propagation using distance ordering
        grouped = ff_calc.groupby('cat')
        for cat in ff_calc['cat'].unique():
            flowline_points = grouped.get_group(cat).sort_values(by='distance')
            segment_cross_sections = flowline_points[flowline_points['transect_id'].notna()].sort_values(by='distance')

            if segment_cross_sections.empty:
                continue

            for idx, point in flowline_points.iterrows():
                if pd.notna(point['transect_id']):
                    continue

                downstream_cross_sections = segment_cross_sections[
                    segment_cross_sections['distance'] <= point['distance']
                ]

                if not downstream_cross_sections.empty:
                    controlling_cross_section = downstream_cross_sections.loc[downstream_cross_sections['distance'].idxmax()]
                    ff_calc.loc[idx, 'transect_id'] = controlling_cross_section['transect_id']

        after_propagation = ff_calc['transect_id'].notna().sum()
        self._log(f"assign_transect_id: {after_propagation} point(s) assigned after segment propagation "
                  f"(unique transect_ids: {sorted(ff_calc['transect_id'].dropna().unique().tolist())})")

        # Tributary propagation using prox_id connections
        while True:
            updated_points = []
            transect_id_map = ff_calc.set_index('fid')['transect_id']
            valid_prox_mask = ff_calc['prox_id'].notna() & ff_calc['transect_id'].isna()
            points_to_update = ff_calc.loc[valid_prox_mask]

            for fid, prox_id in zip(points_to_update['fid'], points_to_update['prox_id']):
                if pd.isna(prox_id):
                    continue
                downstream_transect_id = transect_id_map.get(prox_id, None)
                if downstream_transect_id is not None and not pd.isna(downstream_transect_id):
                    ff_calc.loc[ff_calc['fid'] == fid, 'transect_id'] = downstream_transect_id
                    updated_points.append(fid)

            if not updated_points:
                break

        final_assigned = ff_calc['transect_id'].notna().sum()
        self._log(f"assign_transect_id: {final_assigned}/{len(ff_calc)} point(s) assigned after tributary propagation")
        return ff_calc

    def propagate_ffactor(self, ff_calc, ffactor_csv):
        """Map each point's 'transect_id' to its F-factor, defaulting to 1.0.

        Points with no transect (typically below the lowest cross-section) keep 1.0.
        """
        
        ff_calc['ffactor'] = 1.0
    
        # Create lookup dictionary for O(1) transect_id to ffactor mapping
        transect_to_ffactor = dict(zip(ffactor_csv['transect_id'], ffactor_csv['ffactor']))
    
        # Vectorized assignment using pandas .map()
        valid_transect_mask = ff_calc['transect_id'].notna()
        ff_calc.loc[valid_transect_mask, 'ffactor'] = ff_calc.loc[valid_transect_mask, 'transect_id'].map(transect_to_ffactor)
    
        return ff_calc
    
    def ice_reconstruction_with_ffactor(self, df, shear, feedback=None):
        """Reconstruct ice surface and thickness with F-factor adjusted shear.

        Marches the main flowline from the terminus and each tributary from its
        confluence, solving the quadratic equilibrium profile with the basal shear
        stress divided by the local F-factor. Thickness is the reconstructed
        surface minus the bed ('rvalue1'), floored at zero, with the terminus
        forced to zero; zero-thickness points are then backfilled from their
        nearest neighbour.

        Args:
            df: flowline points with 'fid', 'prox_id', 'cat', 'distance',
                'ffactor', 'rvalue1' (bed elevation), 'xcoord', 'ycoord'.
            shear: baseline basal shear stress in Pa, divided by the F-factor at
                each point.

        Returns:
            The frame with added 'ff_ice_surface' and 'ff_thickness' columns.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81  # Gravitational acceleration (m/s2)

        # Initialise a dictionary for storing ice surface values
        surface_dict = {}

        # Main flowline handling - sort by distance so reconstruction proceeds
        # terminus → head (distance = 0 at terminus, increases upstream).
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat].sort_values('distance').reset_index(drop=True)

        if main_flowline.empty:
            raise QgsProcessingException(
                "No main flowline points found. "
                "Check that the flowline and ice thickness points are correctly linked."
            )

        prev_surface = None
        for i, row in main_flowline.iterrows():
            if i == main_flowline.index[0]:
                surface_dict[row['fid']] = row['rvalue1']
                prev_surface = row['rvalue1']
            else:
                dx = row['xcoord'] - main_flowline.loc[i - 1, 'xcoord']
                dy = row['ycoord'] - main_flowline.loc[i - 1, 'ycoord']
                d = np.sqrt(dx**2 + dy**2)

                # Adjust shear stress using F-factor
                adjusted_shear = shear / row['ffactor']

                b = -(main_flowline.loc[i - 1, 'rvalue1'] + row['rvalue1'])
                c = prev_surface * (
                    row['rvalue1'] - (prev_surface - main_flowline.loc[i - 1, 'rvalue1'])
                ) - (2 * d * adjusted_shear) / (rho * g)

                discriminant = b**2 - 4 * c
                if discriminant >= 0:
                    prev_surface = (-b + np.sqrt(discriminant)) / 2
                else:
                    prev_surface = row['rvalue1']

                surface_dict[row['fid']] = prev_surface

        # Tributary handling - process in network order (multi-pass), not digitising
        # (cat) order: a tributary can only inherit its confluence surface once the
        # flowline it drains into has been reconstructed. Reconstruction proceeds
        # confluence -> headwall (confluence has smallest distance along network).
        tributaries = df[df['cat'] != main_flow_cat]
        pending = {cat: group.sort_values('distance').copy()
                   for cat, group in tributaries.groupby('cat')}

        def _reconstruct_tributary(group_sorted, confluence_surface):
            confluence_idx = group_sorted.index[0]
            surface_dict[group_sorted.loc[confluence_idx, 'fid']] = confluence_surface
            prev_surface = confluence_surface
            for i in range(1, len(group_sorted)):
                dx = group_sorted['xcoord'].iloc[i] - group_sorted['xcoord'].iloc[i - 1]
                dy = group_sorted['ycoord'].iloc[i] - group_sorted['ycoord'].iloc[i - 1]
                d = np.sqrt(dx**2 + dy**2)

                # Adjust shear stress using F-factor
                adjusted_shear = shear / group_sorted['ffactor'].iloc[i]

                b = -(group_sorted['rvalue1'].iloc[i - 1] + group_sorted['rvalue1'].iloc[i])
                c = prev_surface * (
                    group_sorted['rvalue1'].iloc[i] -
                    (prev_surface - group_sorted['rvalue1'].iloc[i - 1])
                ) - (2 * d * adjusted_shear) / (rho * g)

                discriminant = b**2 - 4 * c
                if discriminant >= 0:
                    prev_surface = (-b + np.sqrt(discriminant)) / 2
                else:
                    prev_surface = group_sorted['rvalue1'].iloc[i]

                surface_dict[group_sorted['fid'].iloc[i]] = prev_surface

        while pending:
            ready = [cat for cat, group_sorted in pending.items()
                     if group_sorted.iloc[0]['prox_id'] in surface_dict]
            if not ready:
                for cat, group_sorted in pending.items():
                    msg = (f"Tributary cat={cat}: downstream link (fid "
                           f"{group_sorted.iloc[0]['prox_id']}) was never reconstructed - "
                           "starting at bed elevation (zero ice thickness). Check the "
                           "flowline digitising direction and network connectivity.")
                    self._log(msg, level='warning')
                    if feedback is not None:
                        feedback.pushWarning(msg + "\n")
                    _reconstruct_tributary(group_sorted, group_sorted.iloc[0]['rvalue1'])
                break
            for cat in ready:
                group_sorted = pending.pop(cat)
                _reconstruct_tributary(group_sorted,
                                       surface_dict[group_sorted.iloc[0]['prox_id']])
        
        df['ff_ice_surface'] = df['fid'].map(surface_dict)
        df['ff_thickness'] = df['ff_ice_surface'] - df['rvalue1']
        df['ff_thickness'] = np.maximum(df['ff_thickness'], 0)

        # Replace zero ff_thickness with nearest neighbour values
        df = self.replace_zero_ff_thickness_with_nearest_neighbor(df)

        # Ensure terminus has zero ice thickness
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]
        
        if not main_flowline.empty:
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            terminus_idx = terminus_row.name
            df.at[terminus_idx, 'ff_thickness'] = 0
            df.at[terminus_idx, 'ff_ice_surface'] = df.at[terminus_idx, 'rvalue1']

        # Drop unwanted columns before returning df (keep 'distance' for validate_driving_stress)
        columns_to_drop = ['Shape_Leng', 'angle', 'rvalue1']
        df = df.drop(columns=columns_to_drop, errors='ignore')

        return df

    def replace_zero_ff_thickness_with_nearest_neighbor(self, df):
        """Backfill zero 'ff_thickness' values, keeping the true terminus at zero.

        Fills each zero first from the point named by its 'prox_id' (the confluence
        link) if that has thickness, otherwise from the nearest non-zero point. The
        minimum-distance point on the main flowline (the terminus) is left at zero.

        Args:
            df: points with 'ff_thickness', 'prox_id', 'xcoord', 'ycoord', 'fid',
                'cat', 'distance'.

        Returns:
            The frame with zero thicknesses replaced except at the terminus.
        """
        
        # Find the true terminus - point with minimum distance on main flowline
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]
        
        if not main_flowline.empty:
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            true_terminus_fid = terminus_row['fid']
        else:
            true_terminus_fid = None

        # Only replace zeros that are not at the true terminus
        if true_terminus_fid is not None:
            zero_mask = (df['ff_thickness'] == 0) & (df['fid'] != true_terminus_fid)
        else:
            zero_mask = (df['ff_thickness'] == 0)
        
        zero_thickness_points = df[zero_mask]
        non_zero_points = df[df['ff_thickness'] != 0]

        if zero_thickness_points.empty:
            return df

        if non_zero_points.empty:
            raise QgsProcessingException(
                "Cannot replace zero-thickness points: no non-zero thickness points exist in this dataset. "
                "Check that the input ice thickness data contains valid non-zero values."
            )

        # Coordinates of non-zero and zero thickness points
        non_zero_coords = np.array(non_zero_points[['xcoord', 'ycoord']])
        zero_coords = np.array(zero_thickness_points[['xcoord', 'ycoord']])

        for i, zero_point in enumerate(zero_coords):
            # Get the index of the current zero-thickness point in the original DataFrame
            zero_thickness_index = zero_thickness_points.index[i]
            current_row = df.loc[zero_thickness_index]

            # Check if the point is a tributary confluence
            prox_id = current_row['prox_id']
            if not pd.isna(prox_id):  
                if prox_id in df['fid'].values:
                    near_point_thickness = df.loc[df['fid'] == prox_id, 'ff_thickness'].values[0]
                    if near_point_thickness > 0:  
                        df.at[zero_thickness_index, 'ff_thickness'] = near_point_thickness
                        continue  

            # If not a confluence or valid `prox_id`, use the nearest neighbour logic
            distances = np.sqrt(np.sum((non_zero_coords - zero_point) ** 2, axis=1))
            nearest_idx = np.argmin(distances)
            nearest_thickness = non_zero_points['ff_thickness'].iloc[nearest_idx]

            # Update the ff_thickness for the zero-thickness point
            df.at[zero_thickness_index, 'ff_thickness'] = nearest_thickness

        return df

    def validate_driving_stress(self, df):
        """Flag points whose basal shear stress falls outside 50-200 kPa.

        Computes F * rho*g*H*sin(alpha) with the surface slope taken from
        successive 'ff_ice_surface' values within each flowline segment ('cat'),
        so a correctly reconstructed glacier returns values near the input shear.
        The first point of each segment has no slope and is excluded from the count.

        Args:
            df: points with 'cat', 'distance', 'ffactor', 'ff_thickness',
                'ff_ice_surface', 'xcoord', 'ycoord', 'fid'.

        Returns:
            (frame, valid_percentage, invalid_fids), with temporary columns removed.
        """
        
        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Sort within each flowline segment so diff() follows flow direction
        df = df.sort_values(['cat', 'distance']).copy()

        # Compute slope within each cat group - NaN for the first point of each
        # group (no predecessor within that segment).
        dx = df.groupby('cat')['xcoord'].diff()
        dy = df.groupby('cat')['ycoord'].diff()
        dz = df.groupby('cat')['ff_ice_surface'].diff()

        # Points where a slope can actually be computed (not first of group)
        slope_computable = dx.notna()
        d = np.sqrt(dx**2 + dy**2).where(slope_computable)
        d = d.replace(0, np.nan)  # avoid division by zero at coincident points
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate basal shear stress (F × ρgH sin α) only where slope is defined.
        # This matches what 'shear' represents in the reconstruction (F × driving stress),
        # so a correctly reconstructed glacier should yield values close to the input shear.
        driving_stress = df['ffactor'] * rho * g * df['ff_thickness'] * np.sin(surface_slope)

        # Validate only the points where slope could be computed; segment
        # boundary points (first of each cat) are excluded from the count.
        stress_valid = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        df['stress_valid'] = stress_valid

        evaluable = slope_computable
        invalid_points = df.loc[evaluable & ~stress_valid, 'fid'].tolist()
        valid_points = stress_valid[evaluable].sum()
        total_points = evaluable.sum()

        df = df.drop(columns=['stress_valid', 'distance', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')
        if total_points == 0:
            return df, 0.0, []
        valid_percentage = (valid_points / total_points) * 100

        return df, valid_percentage, invalid_points

    def postProcessAlgorithm(self, context, feedback):
        """Show a completion dialog once processing finishes."""

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("F-Factor Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)
    

