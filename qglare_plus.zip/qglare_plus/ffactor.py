"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D shape-factor FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, math, traceback, processing
from .qglare_base import QGlaReAlgorithmMixin
from .qglare_utils import normalise_shapefile_field_names
import numpy as np
import pandas as pd
from qgis.PyQt.QtCore import QVariant, QMetaType
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (Qgis,
                       QgsField,
                       QgsFields,
                       QgsProject,
                       QgsPointXY,
                       QgsFeature,
                       QgsGeometry,
                       QgsWkbTypes,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsRasterLayer,
                       QgsVectorLayer,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingUtils)

# QGIS version compatibility: GeometryType moved to Qgis enum in 3.30
try:
    _POINT_GEOMETRY = Qgis.GeometryType.Point
except AttributeError:                          # QGIS < 3.30
    _POINT_GEOMETRY = QgsWkbTypes.PointGeometry

# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38 —
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
_FIELD_DOUBLE = QMetaType.Type.Double if Qgis.QGIS_VERSION_INT >= 33800 else QVariant.Double

# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_RASTER = Qgis.ProcessingSourceType.Raster
    _SOURCE_VECTOR_POINT = Qgis.ProcessingSourceType.VectorPoint
    _SOURCE_VECTOR_LINE = Qgis.ProcessingSourceType.VectorLine
except AttributeError:                          # QGIS < 3.36
    _SOURCE_RASTER = QgsProcessing.TypeRaster
    _SOURCE_VECTOR_POINT = QgsProcessing.TypeVectorPoint
    _SOURCE_VECTOR_LINE = QgsProcessing.TypeVectorLine

class Ffactor(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for calculating and applying the shape friction factor (F-Factor).

    The F-Factor quantifies flow resistance caused by lateral drag and is calculated 
    using the glacier's cross-sectional area and perimeter length. This tool applies 
    the F-Factor to refine ice thickness and surface elevation estimates along flowlines.

    Key Features:
    - Validates input layers (DEM, flowlines, ice thickness points).
    - Computes the F-Factor based on glacier geometry.
    - Propagates F-Factor values to flowline points.
    - Adjusts ice thickness and surface elevation using the F-Factor.

    Inputs:
    - DEM: Raster representing glacier basal topography.
    - Flowlines: Vector file of glacier flowlines.
    - Ice Thickness Points: Vector file with pre-computed ice thickness and surface elevation.

    Output:
    - A vector layer with F-Factor-adjusted ice thickness and surface elevation.

    References:
    - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of Glaciology, 2, pp. 82–93.
    - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the Ice-Sheets. Nature, 169, pp. 529–530.
    - Nye, J.F., 1965. The flow of a glacier in a channel of rectangular, elliptic or parabolic cross-section. 
      Journal of Glaciology, 5, pp. 661–690.
    - Shilling, D.H., Hollin, J.T., 1981. Numerical reconstructions of valley glaciers and small icecaps. 
      In: Denton, G.H., Hughes, T.J. (Eds.), The Last Great Ice Sheets. Wiley, New York, pp. 207–220.
    - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program for reconstructing the surface 
      profile of former mountain glaciers and ice caps. Computers & Geosciences, 36, pp. 605–610.
    """ 

    N_STEPS = 18
    _log_tag = '2D shape-factor FL Ice Thickness Processing Log'

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    shear_stress = 'specify_shear_stress'
    input_flowline = 'input_flowline'
    input_transects = 'transects'
    ice_flow_thickness = 'ice_flow_thickness'

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return 'F-Factor'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """        
        
        return '3. 2D shape-factor FL Ice Thickness'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
       
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("2 F-Factor", text)

    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)

    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """  
        
        return self.tr(
            "The shape friction factor (F-Factor) quantifies flow resistance due to lateral drag. "
            "It is calculated based on the cross-sectional area and perimeter length of the glacier profile. "
            "The F-Factor is computed for all input points and applied to re-estimate ice thickness and "
            "surface elevation at each point.\n\n"
            "The specified shear stress value will be applied to all data. \n\n"
            "A new vector point file is created from the specified input data. \n\n"
            "N.B. See Nye (1952a, b), Nye (1965), Shilling and Hollin (1981), and Benn and Hulton (2010) "
            "for detailed information on the F-Factor.\n\n"
            "References:\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the Ice-Sheets. "
            "Nature 169, pp. 529–530.\n"
            "  - Nye, J.F., 1965. The flow of a glacier in a channel of rectangular, elliptic or parabolic cross-section. "
            "Journal of Glaciology 5, pp. 661–690.\n"
            "  - Shilling, D.H., Hollin, J.T., 1981. Numerical reconstructions of valley glaciers and small icecaps. "
            "In: Denton, G.H., Hughes, T.J. (Eds.), The Last Great Ice Sheets. Wiley, New York, pp. 207–220.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program for reconstructing the surface profile "
            "of former mountain glaciers and ice caps. Computers & Geosciences 36, pp. 605–610.")
    
    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            Ffactor: A new instance of the `Ffactor` class.
        """

        return Ffactor()

    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'ffactor.png')  # Ensure this is the correct filename

        # Return the QIcon
        return QIcon(icon_file)
        
    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """
        
        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem, 
        self.tr("\nSelect current topography elevation data (DSM/DTM)"),
        [_SOURCE_RASTER]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.ice_flow_thickness, 
        self.tr("\nSelect ice flow thickness points (vector point file)"),
        [_SOURCE_VECTOR_POINT]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_transects,
        self.tr("\nSelect transect lines (vector polyline file)"),
        [_SOURCE_VECTOR_LINE]))
        
        self.addParameter(QgsProcessingParameterVectorLayer( 
        self.input_flowline, 
        self.tr("\nSelect flow line (vector polyline file)"),
        [_SOURCE_VECTOR_LINE]))
        
        self.addParameter(QgsProcessingParameterNumber(
        self.shear_stress, 
        self.tr("\nSpecify shear stress value"),
        QgsProcessingParameterNumber.Integer, minValue=0, defaultValue=100000))

    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Executes the algorithm and performs an F-factor estimation for glacier valley transects
        and corrects ice thickness estimates based on user inputs.
        """
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)

        try:
            self._init_logger('ffactor', feedback)
            return self._run_algorithm_body(parameters, context, feedback)
        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )

    def _run_algorithm_body(self, parameters, context, feedback):
        # Preprocess and validate inputs
        inputs = self.preprocess_inputs(parameters, context, feedback)
        dem = inputs["dem"]
        dem_file = inputs["dem_file"]
        crs = inputs["crs"]
        crs_string = inputs["crs_string"]
        shear = inputs["shear"]
        ice_pts = inputs["ice_pts"]
        ice_thickness_pts_file = inputs["ice_thickness_pts_file"]
        flowline = inputs["flowline"]
        flowline_file = inputs["flowline_file"]
        transects = inputs["transects"]
        transects_file = inputs["transects_file"]

        # Generate the interval distance using the ice thickness points layer
        distance = self.point_distance(ice_pts)

        # Log initial parameters and start time
        start_time = time.time()
        self.log_initialization(feedback, dem_file, ice_thickness_pts_file, distance, flowline_file,
                                transects_file, shear)
        self._log_run_header({
            'DEM':                   f"{dem_file} ({dem.source()})",
            'Ice Thickness Points':   ice_thickness_pts_file,
            'Flowline':               flowline_file,
            'Transects':              transects_file,
            'Shear Stress (kPa)':     shear,
            'Point Interval (m)':     f"{distance:.1f}",
            'CRS':                    crs_string,
        })
        self._log_layer_crs([
            ('DEM',                  dem),
            ('Ice Thickness Points',  ice_pts),
            ('Flowline',              flowline),
            ('Transects',             transects),
        ])

        # Process transects
        transects_processed = self.process_transects(transects, context, feedback)

        # Generate points along transects
        transect_points = self.generate_points_along_transects(transects_processed, distance, dem, context, feedback)
        if feedback.isCanceled():
            return {}

        # Process intersections
        intersections = self.process_intersections(transects_processed, flowline, dem, context, feedback)
        if feedback.isCanceled():
            return {}

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        self.log_initialization(feedback, stage="input_processed")
        self.log_processing_duration("Pre-process input data", start_time)

        # Convert layers to DataFrame
        df_start_time = time.time()
        intersection_with_coords = self.add_xy_coordinates(intersections, "Intersection Points with X/Y", feedback)
        transect_points_with_coords = self.add_xy_coordinates(transect_points, "Sampled Points with X/Y", feedback)
        intersection_df = self.create_dataframe(intersection_with_coords, feedback=feedback)
        ice_pts_df = self.create_dataframe(transect_points_with_coords, feedback=feedback)
        ff_calc_df = self.create_dataframe(ice_pts, feedback=feedback)
        ff_calc_df = normalise_shapefile_field_names(ff_calc_df)
        ff_calc_df = self.correct_distance_order(ff_calc_df, feedback)   # guarantee terminus→headwall order
        transect_cat_map = self._map_transects_to_cats(transects_processed, ff_calc_df, context)
        transect_df = self.pre_process_dataframe(ice_pts_df)
        self.log_initialization(feedback, stage="data_prep")
        self.log_processing_duration("Data processed for calculation", df_start_time)

        # F-factor estimation
        ff_start_time = time.time()
        ffactor = self.calculate_ffactor(transect_df, feedback)
        ffactor_csv = ffactor.copy()
        self.log_initialization(feedback, stage="estimate_ffactor")
        self.log_processing_duration("F-factor calculation", ff_start_time)

        # Spatial linking flowlines and tributary branches
        link_start_time = time.time()
        ff_calc_linked = self.assign_transect_id(ff_calc_df, intersection_df, ffactor_csv, transect_cat_map)
        self.log_initialization(feedback, stage="tributary_centreline")
        self.log_processing_duration("Spatially linked tributary branches and centreline", link_start_time)

        # Propagate F-factor
        prop_start_time = time.time()
        ffactor_prop = self.propagate_ffactor(ff_calc_linked, ffactor_csv)
        self.log_initialization(feedback, stage="apply_ffactor")
        self.log_processing_duration("2D shape-factor propagation to ice thickness", prop_start_time)

        # Correct ice thickness
        recon_start_time = time.time()
        result_df = self.ice_reconstruction_with_ffactor(ffactor_prop, shear, feedback=feedback)
        self.log_initialization(feedback, stage="calculate_corrected")
        self.log_processing_duration("Calculate 2D shape-factor corrected ice thickness", recon_start_time)

        # Validate and load results
        val_start_time = time.time()
        validated_df, valid_percentage, invalid_points = self.validate_driving_stress(result_df)
        self.log_initialization(feedback, stage="validation", valid_percentage=valid_percentage, invalid_points=invalid_points)
        self.log_processing_duration("Ice surface and thickness validation", val_start_time)

        load_start_time = time.time()
        self.load_dataframe_to_qgis(validated_df, crs, QgsProject.instance(), feedback=feedback,
                                    layer_name="2D shape-factor FL Ice Thickness")
        self.log_initialization(feedback, stage="load_qgis")
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", load_start_time)

        self.log_final_results(feedback, crs_string, start_time)
        self._log_success(feedback)

        results = {"Status": "Complete"}
        return results

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieve and validate input layers and parameters for the F-factor estimation.

        This function:
        - Loads the input DEM and vector layers (ice thickness points, flowline, and transects).
        - Retrieves the shear stress value.
        - Extracts filenames or names for logging purposes.
        - Validates that the DEM, flowline, transects, and ice thickness points are valid.
        - Validates that all input layers share the same CRS.

        Parameters:
            parameters (dict): Dictionary of user-supplied parameters for the algorithm.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): Object for logging progress and messages.

        Returns:
            dict: A dictionary with the following keys and values:
                - "dem" (QgsRasterLayer): The input DEM layer.
                - "dem_file" (str or None): Source of the DEM, or None if DEM is missing.
                - "crs" (QgsCoordinateReferenceSystem): The DEM's CRS.
                - "crs_string" (str): The DEM's CRS AuthID, or "Unknown CRS" if invalid.
                - "shear" (int): The shear stress value.
                - "ice_pts" (QgsVectorLayer): The input ice thickness points layer.
                - "ice_thickness_pts_file" (str): The name of the ice thickness points layer.
                - "flowline" (QgsVectorLayer): The input flowline layer.
                - "flowline_file" (str): The name of the flowline layer.
                - "transects" (QgsVectorLayer): The input transects layer.
                - "transects_file" (str): The name of the transects layer.

        Raises:
            QgsProcessingException: If modify_values is enabled but no features are selected, or if the input layer is invalid.
        """

        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)
        if dem is None or not dem.isValid():
            raise QgsProcessingException(
                "The input DEM layer could not be retrieved or is not valid. "
                "Please select a valid raster layer."
            )
        dem_file = dem.source()
        crs = dem.crs()
        crs_string = crs.authid() if crs and crs.isValid() else 'Unknown CRS'

        shear = self.parameterAsInt(parameters, self.shear_stress, context)

        ice_pts = self.parameterAsVectorLayer(parameters, self.ice_flow_thickness, context)
        if ice_pts is None or not ice_pts.isValid():
            raise QgsProcessingException(
                "The ice thickness points layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        ice_thickness_pts_file = ice_pts.name()

        flowline = self.parameterAsVectorLayer(parameters, self.input_flowline, context)
        if flowline is None or not flowline.isValid():
            raise QgsProcessingException(
                "The input flowline layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        flowline_file = flowline.name()

        transects = self.parameterAsVectorLayer(parameters, self.input_transects, context)
        if transects is None or not transects.isValid():
            raise QgsProcessingException(
                "The input transects layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        transects_file = transects.name()

        if flowline.id() == transects.id() or flowline.source() == transects.source():
            raise QgsProcessingException(
                "The flowline and transects inputs appear to be the same layer. "
                "Please select different layers for each input."
            )

        # Clean geometries - remove any empty geometries
        transects_cleaned = self.remove_empty_geometries(transects, context)
        transects = transects_cleaned

        # Validate CRS first so that subsequent checks (e.g. flowline/transect
        # length comparison) use projected metres rather than the original units.
        flowline = self.validate_layer_crs(flowline, crs, context, feedback)
        transects = self.validate_layer_crs(transects, crs, context, feedback)
        ice_pts = self.validate_layer_crs(ice_pts, crs, context, feedback)
        self.validate_projected_crs(dem, feedback)

        # Validate layers (after reprojection so lengths are in map units)
        self.validate_flowline_and_transect(flowline, transects)
        self.validate_dem_input(dem)
        self.validate_input_points(ice_pts)

        return {
            "dem": dem,
            "dem_file": dem_file,
            "crs": crs,
            "crs_string": crs_string,
            "shear": shear,
            "ice_pts": ice_pts,
            "ice_thickness_pts_file": ice_thickness_pts_file,
            "flowline": flowline,
            "flowline_file": flowline_file,
            "transects": transects,
            "transects_file": transects_file
        }
    
    def process_transects(self, transects, context, feedback):
        """
        Add and remove specific fields in the transects layer and generate an auto-increment field.

        This function:
        - Adds a new 'Id' field to the transects layer using the field calculator.
        - Removes any existing 'id' field.
        - Creates an auto-increment field named 'transect_id' to serve as a transect identifier.

        Parameters:
            transects (QgsVectorLayer): The input transects layer.
            context (QgsProcessingContext): QGIS processing context for running child algorithms.
            feedback (QgsProcessingFeedback): Feedback object for progress reporting.

        Returns:
            QgsVectorLayer: The updated transects layer with the new auto-increment field and without the 'id' field.
        """


        # First, preserve the original 'Id' field if it exists
        params_preserve_id = {
            'FIELD_NAME': 'original_Id',
            'FIELD_TYPE': 1,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 0,
            'FORMULA': 'coalesce("Id", "ID", "id", @row_number)',  # Use original Id or fallback to row number
            'INPUT': transects,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        layer_with_original = self._run_algorithm(
            'native:fieldcalculator', params_preserve_id, context, feedback,
            output_key='OUTPUT', step_name='Preserve original transect Id field'
        )['OUTPUT']

        
        # Add new 'Id' field using the field calculator
        params_add_field = {
            'FIELD_NAME': 'Id',
            'FIELD_TYPE': 1,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 0,
            'FORMULA': '@row_number + 1',
            'INPUT': layer_with_original,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        layer_id = self._run_algorithm(
            'native:fieldcalculator', params_add_field, context, feedback,
            output_key='OUTPUT', step_name='Add transect Id field'
        )['OUTPUT']

        # Remove the unwanted 'id' field
        params_delete_field = {
            'INPUT': layer_id,
            'COLUMN': ['id'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        transects_no_id = self._run_algorithm(
            'native:deletecolumn', params_delete_field, context, feedback,
            output_key='OUTPUT', step_name='Remove duplicate id field from transects'
        )['OUTPUT']

        # Add auto-incremental field to create a proper transect identifier
        params_auto_field = {
            'FIELD_NAME': 'transect_id',
            'GROUP_FIELDS': None,
            'INPUT': transects_no_id,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        transects_with_id = self._run_algorithm(
            'native:addautoincrementalfield', params_auto_field, context, feedback,
            output_key='OUTPUT', step_name='Add transect_id incremental field'
        )['OUTPUT']

        return transects_with_id

    def generate_points_along_transects(self, transects_layer, distance, dem, context, feedback):
        """
        Create points along transect lines, sample DEM values at those points, and add X/Y coordinates.

        This function:
        - Breaks each transect line into points spaced by the specified distance.
        - Samples the input DEM at each generated point.
        - Appends X and Y coordinate fields to the output points layer.

        Parameters:
            transects_layer (QgsVectorLayer): The layer containing transect lines.
            distance (float): The interval at which points are generated along each line.
            dem (QgsRasterLayer): The DEM raster used for sampling elevation values.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Feedback object for progress reporting.

        Returns:
            QgsVectorLayer: A point layer with sampled DEM values and added X/Y coordinate fields.
        """

        # Break transect lines into points
        params_points = {
            'DISTANCE': distance,
            'END_OFFSET': 0,
            'INPUT': transects_layer,
            'START_OFFSET': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        points_result = self._run_algorithm(
            'native:pointsalonglines', params_points, context, feedback,
            output_key='OUTPUT', step_name='Break transects into points'
        )
        points_layer = points_result['OUTPUT']
        self._check_layer_features(
            points_layer, context, 'Break transects into points',
            "No points were generated along transects. "
            "Check that your point interval is smaller than your transect length."
        )
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Sample DEM values at the generated points
        params_sampling = {
            'COLUMN_PREFIX': 'values',
            'INPUT': points_layer,
            'RASTERCOPY': dem,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        sampling_result = self._run_algorithm(
            'native:rastersampling', params_sampling, context, feedback,
            output_key='OUTPUT', step_name='Sample DEM at transect points'
        )
        sampled_layer = sampling_result['OUTPUT']
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Add X and Y coordinate fields
        params_xy = {
            'CALC_METHOD': 0,  # 0 = Layer CRS
            'INPUT': sampled_layer,
            'OUTPUT': f'/vsimem/temp_x-y_coords_{id(self)}'
        }
        xy_result = self._run_algorithm(
            'qgis:exportaddgeometrycolumns', params_xy, context, feedback,
            output_key='OUTPUT', step_name='Add X/Y coordinates to transect points'
        )
        return xy_result['OUTPUT']

    def process_intersections(self, transects_layer, flowline, dem, context, feedback):
        """
        Compute intersections between transects and the flowline, and sample DEM values at those points.

        This function:
        - Computes the intersection points between the transects layer and the flowline layer.
        - Samples the input DEM at each intersection point to assign an elevation attribute.

        Parameters:
            transects_layer (QgsVectorLayer): The transects layer.
            flowline (QgsVectorLayer): The flowline layer.
            dem (QgsRasterLayer): The DEM for elevation sampling.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Feedback object for progress reporting.

        Returns:
            QgsVectorLayer: A points layer representing the intersections, with DEM values sampled.
        """

        params_intersect = {
            'INPUT': transects_layer,
            'INPUT_FIELDS': [''],
            'INTERSECT': flowline,
            'INTERSECT_FIELDS': [''],
            'INTERSECT_FIELDS_PREFIX': 'fl_',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        intersect_result = self._run_algorithm(
            'native:lineintersections', params_intersect, context, feedback,
            output_key='OUTPUT', step_name='Compute transect-flowline intersections'
        )
        intersection_layer = intersect_result['OUTPUT']
        self._check_layer_features(
            intersection_layer, context, 'Compute transect-flowline intersections',
            "No intersections found between transects and the flowline. "
            "Check that your transect lines cross the flowline."
        )
        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        params_sampling = {
            'COLUMN_PREFIX': 'rvalue',
            'INPUT': intersection_layer,
            'RASTERCOPY': dem,
            'OUTPUT': f'/vsimem/temp_intersect_pts_{id(self)}'
        }
        intersect_sampling = self._run_algorithm(
            'native:rastersampling', params_sampling, context, feedback,
            output_key='OUTPUT', step_name='Sample DEM at intersection points'
        )
        sampled_intersections = intersect_sampling['OUTPUT']
        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        return sampled_intersections

    def _map_transects_to_cats(self, transects_layer, ff_calc_df, context):
        """
        For each transect, find which ice_pts branch (cat) it was drawn for.

        Computes the minimum distance from each cat's ice_pts to each transect line.
        The transect physically crosses the target branch, so its ice_pts have near-zero
        distance; other branches are measurably further away.
        """
        ice_coords = ff_calc_df[['xcoord', 'ycoord']].values
        ice_cats   = ff_calc_df['cat'].values
        unique_cats = ff_calc_df['cat'].unique()
        cat_pts = {cat: ice_coords[ice_cats == cat] for cat in unique_cats}

        if isinstance(transects_layer, QgsVectorLayer):
            lyr = transects_layer
        else:
            lyr = QgsProcessingUtils.mapLayerFromString(transects_layer, context)

        transect_cat_map = {}
        for feat in lyr.getFeatures():
            tid = feat['transect_id']
            geom = feat.geometry()
            verts = np.array([[v.x(), v.y()] for v in geom.vertices()])
            if len(verts) < 2:
                continue

            # Segment vectors for the transect polyline
            a = verts[:-1]           # (S, 2) segment starts
            b = verts[1:]            # (S, 2) segment ends
            d = b - a                # (S, 2) directions
            seg_len_sq = (d ** 2).sum(axis=1)  # (S,)

            best_cat, best_dist = None, np.inf
            for cat, pts in cat_pts.items():
                # pts: (N, 2)  a, b, d: (S, 2)  seg_len_sq: (S,)
                pa = pts[:, np.newaxis, :] - a[np.newaxis, :, :]          # (N, S, 2)
                t  = (pa * d[np.newaxis, :, :]).sum(axis=2)               # (N, S)
                t  = np.clip(t / np.where(seg_len_sq > 0, seg_len_sq, 1), 0, 1)  # (N, S)
                proj = a[np.newaxis, :, :] + t[:, :, np.newaxis] * d[np.newaxis, :, :]  # (N, S, 2)
                dists = np.sqrt(((pts[:, np.newaxis, :] - proj) ** 2).sum(axis=2))  # (N, S)
                min_dist = dists.min()
                if min_dist < best_dist:
                    best_dist, best_cat = min_dist, cat

            transect_cat_map[tid] = best_cat

        self._log(f"_map_transects_to_cats: {transect_cat_map}")
        return transect_cat_map

    def get_longest_line_length(self, layer):
        """
        Determine the length of the longest line in a line or multi-line layer.

        This function:
        - Iterates over all features in the input layer.
        - For multi-part geometries, processes each part; for single-part, processes the line.
        - Tracks and returns the maximum measured line length.

        Parameters:
            layer (QgsVectorLayer): The vector layer containing line or multi-line geometries.

        Returns:
            float: The length of the longest line in the layer; 0.0 if no valid geometry is found.
        """
        
        longest = 0.0
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            # Get a list of polylines (one for single-part, many for multi-part)
            lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]

            # Compute lengths and update 'longest' if we find a longer one
            for line in lines:
                length = QgsGeometry.fromPolylineXY(line).length()
                if length > longest:
                    longest = length

        return longest

    def remove_empty_geometries(self, layer, context):
        """
        Remove features with empty or null geometries from a vector layer.

        This function:
        - Iterates through all features in the input layer.
        - Identifies features with empty or null geometries.
        - Creates a new memory layer containing only features with valid, non-empty geometries.
        - Preserves all attribute fields from the original layer.

        Parameters:
            layer (QgsVectorLayer): The input vector layer to clean.
            context (QgsProcessingContext): The QGIS processing context.

        Returns:
            QgsVectorLayer: A new memory layer containing only features with valid geometries.
        """
        
        # Filter valid geometries
        valid_features = []
        for f in layer.getFeatures():
            if f.geometry() and not f.geometry().isEmpty():
                valid_features.append(f)
        
        # Create clean layer, preserving the original layer name
        clean = QgsVectorLayer(
            f"LineString?crs={layer.crs().authid()}",
            layer.name(),
            "memory"
        )
        clean.dataProvider().addAttributes(layer.fields())
        clean.updateFields()
        clean.dataProvider().addFeatures(valid_features)
        
        return clean
    
    def validate_flowline_and_transect(self, flowline_layer, transect_layer):
        """
        Validate that the longest line in the flowline layer is strictly longer than the longest
        line in the transect layer.

        This function:
        - Computes the longest line length for both flowline and transect layers.
        - Raises an exception if the flowline's longest line is not strictly longer than the transect's.

        Parameters:
            flowline_layer (QgsVectorLayer): The glacier flowline layer.
            transect_layer (QgsVectorLayer): The transect (cross-section) layer.

        Returns:
            None

        Raises:
            QgsProcessingException: If the flowline's longest line is not longer than the transect's.
        """

        flowline_longest = self.get_longest_line_length(flowline_layer)
        transect_longest = self.get_longest_line_length(transect_layer)

        # Check that the input flowline layer is longer than the input transect layer.
        if flowline_longest <= transect_longest:
            raise QgsProcessingException(
                "Invalid input: Please ensure you have selected the correct flowline"
                " and transect/cross-section layers.\n"
            )
        
        return

    def validate_dem_input(self, input_raster):
        """
        Determine whether the input raster is a valid DEM rather than a hillshade.

        This function:
        - Checks that the raster is valid.
        - Scans the raster's filename for common hillshade keywords.
        - Evaluates raster statistics (value range, standard deviation) to detect hillshade-like data.

        Parameters:
            input_raster (QgsRasterLayer): The raster layer to validate.

        Returns:
            bool: True if the raster appears to be a valid DEM; False otherwise.

        Raises:
            QgsProcessingException: If the input raster is invalid or appears to be a hillshade.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected raster layer is missing or invalid.\n\n"
                "Please ensure you have selected a valid DEM.\n"
            )

        # Check filename for "hillshade" or similar keywords
        hillshade_keywords = ["hillshade", "hillShade", "HillShade", "Hillshade", "HILLSHADE"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be valid DEM.\n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

        # Get raster statistics
        provider = input_raster.dataProvider()
        # No explicit stats argument: any explicit value binds to the int overload
        # of bandStatistics(), deprecated in QGIS 3.40. The default is All anyway.
        stats = provider.bandStatistics(1)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be valid DEM. \n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

    def validate_input_points(self, input_layer):
        """
        Confirm that a vector layer contains all required fields for ice flow thickness calculations.

        This function:
        - Verifies that the layer is valid.
        - Checks that the layer includes the required fields:
            'cat', 'distance', 'prox_id', 'ice_thickness', and 'ice_surface'.

        Parameters:
            input_layer (QgsVectorLayer): The input vector layer to validate.

        Returns:
            bool: True if the layer contains all required fields; otherwise, raises an exception.

        Raises:
            QgsProcessingException: If the input layer is invalid or missing required fields.
        """

        # Required fields
        required_fields = {'cat', 'distance', 'prox_id', 'ice_thickness', 'ice_surface',
                           'fid', 'xcoord', 'ycoord', 'rvalue1'}

        # Ensure the layer is valid
        if not input_layer or not input_layer.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected points layer is missing or invalid.\n\n"
                "Please ensure you have selected the correct layer."
            )

        # Check if required fields exist in the layer.
        # Accept Shapefile-truncated names (e.g. 'ice_surfac' for 'ice_surface').
        layer_fields = {field.name() for field in input_layer.fields()}
        missing_fields = {f for f in required_fields
                          if f not in layer_fields and f[:10] not in layer_fields}

        if missing_fields:
            raise QgsProcessingException(
                f"Invalid input: The selected points layer is missing required fields.\n\n"
                "Please execute, or re-execute, '2D FL Ice Thickness'.\n"
            )

        return True
    
    def log_initialization(self, feedback, dem_filename=None, ice_thick_name=None, 
                           distance=None, flowline_name=None, transects_name=None, 
                           shear=None, stage=None, valid_percentage=None, invalid_points=None):
        """
        Log initialization details and stage-specific messages to the QGIS feedback console.

        This function:
        - When stage is None, logs initial parameters (DEM filename, ice flow thickness points, resolution,
        flowline, transects, and shear value).
        - For specific stages (e.g., "input_processed", "data_prep", "estimate_ffactor", etc.), updates
        the progress text accordingly.
        - Optionally reports warnings during validation if the valid percentage is below a threshold.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for logging messages.
            dem_filename (str, optional): The DEM filename.
            ice_thick_name (str, optional): The ice thickness points layer name.
            distance (float, optional): The spatial resolution (map units).
            flowline_name (str, optional): The flowline layer name.
            transects_name (str, optional): The transects layer name.
            shear (float, optional): The shear stress value.
            stage (str, optional): The current processing stage; if None, initial parameters are logged.
            valid_percentage (float, optional): Percentage of valid points (used for validation stage).
            invalid_points (list, optional): List of invalid point IDs (used for validation stage).

        Returns:
            None
        """

        if stage is None:
            # Log initialization details
            feedback.setProgress(0)
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initialising 2D shape-factor FL Ice Thickness Calculation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo('Input Parameters:')
            feedback.pushInfo(f'  - DEM: {dem_filename}')
            feedback.pushInfo(f'  - Ice flow thickness points: {ice_thick_name}')
            feedback.pushInfo(f"  - Resolution (map units): {distance:.2f}")
            feedback.pushInfo(f'  - Flowline: {flowline_name}')
            feedback.pushInfo(f'  - Transects: {transects_name}')
            feedback.pushInfo(f'  - Shear value: {shear}')
            feedback.pushInfo('-------------------------------------------------------------\n')
            feedback.setProgressText('Pre-processing input data...\n')
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "estimate_ffactor":
            feedback.setProgressText("Estimating the 2D shape-factor of given ice flow thickness...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "apply_ffactor":
            feedback.setProgressText("Applying and propagating 2D shape-factor...\n")
        elif stage == "calculate_corrected":
            feedback.setProgressText("Correcting ice surface and thickness with 2D shape-factor...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 80:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushWarning(f"Invalid driving stress points (fid): {invalid_points}")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def point_distance(self, ice_pts):
        """
        Compute the Euclidean distance between the first two points in the given point layer.

        This function:
        - Sorts the features by the 'fid' field.
        - Retrieves the coordinates of the first and second points.
        - Computes and returns the Euclidean distance between them.

        Parameters:
            ice_pts (QgsVectorLayer): A point layer with at least two features, including 'xcoord' and 'ycoord'.

        Returns:
            float: The Euclidean distance between the first two points.

        Raises:
            ValueError: If the layer has fewer than two points.
        """

        if not ice_pts or ice_pts.featureCount() < 2:
            raise QgsProcessingException(
                "The ice thickness points layer must contain at least two points. "
                "Check that the correct layer has been selected."
            )
        
        # Extract features and sort by 'fid' to ensure sequential order
        features = sorted(ice_pts.getFeatures(), key=lambda f: f['fid'])

        # Get the first two points
        first_point = features[0]
        second_point = features[1]

        # Extract x and y coordinates
        x1, y1 = first_point['xcoord'], first_point['ycoord']
        x2, y2 = second_point['xcoord'], second_point['ycoord']

        # Calculate the Euclidean distance
        distance = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5

        return distance
         
    def add_xy_coordinates(self, input_layer_path, layer_name, feedback=None):
        """
        Append 'xcoord' and 'ycoord' fields to a point layer, storing each feature's geometry coordinates.

        This function:
        - Loads the layer from the given file path.
        - Validates that the layer is of point geometry.
        - Adds 'xcoord' and 'ycoord' fields to the layer.
        - Iterates through features to populate these fields with the corresponding X and Y coordinates.

        Parameters:
            input_layer_path (str): The file path of the point layer.
            layer_name (str): The name to assign to the loaded/modified layer.
            feedback (QgsProcessingFeedback, optional): For logging progress.

        Returns:
            QgsVectorLayer: The modified point layer with 'xcoord' and 'ycoord' attributes.

        Raises:
            ValueError: If the layer is invalid or is not a point layer.
        """

        # Load the layer from the input path
        layer = QgsVectorLayer(input_layer_path, layer_name, "ogr")

        if not layer.isValid():
            raise ValueError(f"Failed to load layer from path: {input_layer_path}")

        if layer.geometryType() != _POINT_GEOMETRY:
            raise ValueError("Expected a Point geometry layer, but got something else.")

        # Start editing to add attributes
        layer.startEditing()
        layer.addAttribute(QgsField('xcoord', _FIELD_DOUBLE))
        layer.addAttribute(QgsField('ycoord', _FIELD_DOUBLE))

        # Populate X and Y coordinates for each feature
        for feature in layer.getFeatures():
            geom = feature.geometry()
            if geom.isEmpty():
                feature['xcoord'] = None
                feature['ycoord'] = None
            else:
                point = geom.asPoint()
                feature['xcoord'] = point.x()
                feature['ycoord'] = point.y()
            layer.updateFeature(feature)

        layer.commitChanges()
        return layer
    
    def pre_process_dataframe(self, df):
        """
        Rename specific column headers in the DataFrame to ensure consistency.

        This function:
        - Checks if columns such as 'FID', 'Fid', 'fid', 'ID', 'Id', 'id', 'NAME', 'Name', or 'name'
        exist in the DataFrame.
        - Renames any of those columns to 'grp_id' for uniformity.

        Parameters:
            df (pd.DataFrame): The input DataFrame.

        Returns:
            pd.DataFrame: A copy of the DataFrame with renamed columns where applicable.
        """

        # Define the column names to check and replace
        columns_to_replace = ['FID', 'Fid', 'fid', 'ID', 'Id', 'id', 'NAME', 'Name', 'name']

        # Iterate through the columns and replace if necessary
        for column in columns_to_replace:
            if column in df.columns:
                df = df.rename(columns={column: 'grp_id'})

        return df
    
    def calculate_ffactor(self, df, feedback=None):
        """
        Compute the shape factor (F-factor) for each transect based on 
        cross-sectional area, perimeter, and height difference.

        This function:
        - Sorts the DataFrame by 'transect_id' and 'distance'.
        - Calculates partial areas (A) and perimeter segments (P) between consecutive points.
        - Determines the total height difference (HH) across each transect.
        - Computes the F-factor as total_A divided by (HH * total_P).
        - Maps the F-factor back to each transect in the DataFrame.

        Parameters:
            df (pd.DataFrame): A DataFrame containing transect data, including 'transect_id', 'distance', and 'values1' (elevations).
            feedback (QgsProcessingFeedback, optional): For logging progress.

        Returns:
            pd.DataFrame: The updated DataFrame with new columns 'A', 'P', 'HH', and 'ffactor'.
        """

        # Ensure DataFrame is sorted by transect_id and distance
        df = df.sort_values(['transect_id', 'distance'])

        # Group by transect_id
        grouped = df.groupby('transect_id')

        # Initialize columns for A, P, and HH
        df['A'] = np.nan
        df['P'] = np.nan
        df['HH'] = np.nan 

        # Calculate A and P for each group
        for transect_id, group in grouped:
            distances = group['distance'].values
            elevations = group['values1'].values

            # Calculate A (cross-sectional area)
            A_values = 0.5 * (np.diff(distances) *
                            ((elevations.max() - elevations[:-1]) +
                            (elevations.max() - elevations[1:])))
            df.loc[group.index[1:], 'A'] = A_values

            # Calculate P (perimeter)
            P_values = np.sqrt(np.diff(distances)**2 + np.diff(elevations)**2)
            # dist_diff = np.diff(distances).astype(float)
            # elev_diff = np.diff(elevations).astype(float)
            # P_values = np.sqrt(dist_diff**2 + elev_diff**2)
            df.loc[group.index[1:], 'P'] = P_values

            # Calculate HH (height difference)
            height_diff = elevations.max() - elevations.min()
            df.loc[group.index, 'HH'] = height_diff

        # Calculate total A, P, and HH for each group
        total_A = grouped['A'].sum()
        total_P = grouped['P'].sum()
        height_diff = grouped['HH'].max() 

        # Calculate F-Factor (guard against flat or zero-perimeter transects)
        denominator = (height_diff * total_P).replace(0, np.nan)
        f_factor = total_A / denominator

        # Map F-Factor back to the original DataFrame
        df['ffactor'] = df['transect_id'].map(f_factor)

        return df
        
    def assign_transect_id(self, ff_calc, intersection_df, ffactor_csv, transect_cat_map):
        """
        Assign transect identifiers to flowline points within the same flowline segment and propagate assignments upstream.

        This function:
        - Maps each intersection to its corresponding flowline segment using spatial proximity.
        - Assigns transect IDs to the closest upstream flowline points within the same segment (cat).
        - Propagates transect IDs upstream within each flowline segment using elevation-based ordering.
        - Handles tributary propagation using prox_id linkages to ensure complete coverage.
        - Uses vectorized distance calculations for improved performance.

        Parameters:
            ff_calc (pd.DataFrame): DataFrame of flowline points with columns 'fid', 'cat', 'prox_id', 'xcoord', 'ycoord', and 'rvalue1'.
            intersection_df (pd.DataFrame): DataFrame of transect intersection points, including 'transect_id', 'xcoord', 'ycoord', and 'rvalue1'.
            ffactor_csv (pd.DataFrame): DataFrame mapping 'transect_id' to 'ffactor' (used for compatibility, not directly used in this function).

        Returns:
            pd.DataFrame: The updated flowline points DataFrame with 'transect_id' column assigned to flowline points.
        """
        
        if 'transect_id' not in ff_calc.columns:
            ff_calc['transect_id'] = np.nan

        self._log(f"assign_transect_id: {len(intersection_df)} intersection(s), "
                  f"{len(ff_calc)} flowline point(s), "
                  f"cats={sorted(ff_calc['cat'].unique().tolist())}")

        # Vectorized distance calculation for all intersections
        flowline_coords = ff_calc[['xcoord', 'ycoord']].values
        intersection_coords = intersection_df[['xcoord', 'ycoord']].values
        distances = np.linalg.norm(flowline_coords[:, np.newaxis, :] - intersection_coords[np.newaxis, :, :], axis=2)

        intersection_cats = []
        for _, row in intersection_df.iterrows():
            cat = transect_cat_map.get(row['transect_id'])
            if cat is None:
                int_xy = np.array([row['xcoord'], row['ycoord']])
                cat = ff_calc.iloc[np.linalg.norm(flowline_coords - int_xy, axis=1).argmin()]['cat']
            intersection_cats.append(cat)
        self._log(f"assign_transect_id: transect→cat: "
                  f"{list(zip(intersection_df['transect_id'].tolist(), intersection_cats))}")

        # Direct assignment: for each intersection independently, find the
        # closest upstream flowline point within the same segment and anchor it.
        for i, (_, intersection) in enumerate(intersection_df.iterrows()):
            transect_id = intersection['transect_id']
            intersection_cat = intersection_cats[i]

            same_segment_mask = ff_calc['cat'] == intersection_cat
            same_segment_points = ff_calc[same_segment_mask]

            # Spatial anchor: find closest flowline point in this cat to the intersection coordinate
            seg_distances_to_intersection = distances[same_segment_mask.values, i]
            closest_point_idx = seg_distances_to_intersection.argmin()
            closest_point_distance = same_segment_points.iloc[closest_point_idx]['distance']

            # Upstream = higher along-channel distance (upvalley from terminus)
            upstream_mask = same_segment_points['distance'] >= closest_point_distance
            upstream_candidates = same_segment_points[upstream_mask].copy()

            if not upstream_candidates.empty:
                segment_distances = distances[same_segment_mask.values, i][upstream_mask.values]
                upstream_candidates['weighted_distance'] = segment_distances
                closest_upstream_idx = upstream_candidates['weighted_distance'].idxmin()
                ff_calc.loc[closest_upstream_idx, 'transect_id'] = transect_id

        direct_assigned = ff_calc['transect_id'].notna().sum()
        self._log(f"assign_transect_id: {direct_assigned} point(s) assigned in direct step")

        # Segment-based propagation using distance ordering
        grouped = ff_calc.groupby('cat')
        for cat in ff_calc['cat'].unique():
            flowline_points = grouped.get_group(cat).sort_values(by='distance')
            segment_cross_sections = flowline_points[flowline_points['transect_id'].notna()].sort_values(by='distance')

            if segment_cross_sections.empty:
                continue

            for idx, point in flowline_points.iterrows():
                if pd.notna(point['transect_id']):
                    continue

                downstream_cross_sections = segment_cross_sections[
                    segment_cross_sections['distance'] <= point['distance']
                ]

                if not downstream_cross_sections.empty:
                    controlling_cross_section = downstream_cross_sections.loc[downstream_cross_sections['distance'].idxmax()]
                    ff_calc.loc[idx, 'transect_id'] = controlling_cross_section['transect_id']

        after_propagation = ff_calc['transect_id'].notna().sum()
        self._log(f"assign_transect_id: {after_propagation} point(s) assigned after segment propagation "
                  f"(unique transect_ids: {sorted(ff_calc['transect_id'].dropna().unique().tolist())})")

        # Tributary propagation using prox_id connections
        while True:
            updated_points = []
            transect_id_map = ff_calc.set_index('fid')['transect_id']
            valid_prox_mask = ff_calc['prox_id'].notna() & ff_calc['transect_id'].isna()
            points_to_update = ff_calc.loc[valid_prox_mask]

            for fid, prox_id in zip(points_to_update['fid'], points_to_update['prox_id']):
                if pd.isna(prox_id):
                    continue
                downstream_transect_id = transect_id_map.get(prox_id, None)
                if downstream_transect_id is not None and not pd.isna(downstream_transect_id):
                    ff_calc.loc[ff_calc['fid'] == fid, 'transect_id'] = downstream_transect_id
                    updated_points.append(fid)

            if not updated_points:
                break

        final_assigned = ff_calc['transect_id'].notna().sum()
        self._log(f"assign_transect_id: {final_assigned}/{len(ff_calc)} point(s) assigned after tributary propagation")
        return ff_calc

    def propagate_ffactor(self, ff_calc, ffactor_csv):
        """
        Propagate F-factor values to all flowline points based on their assigned transect identifiers.

        This function:
        - Initializes all flowline points with a default F-factor value of 1.0.
        - Creates an optimized lookup dictionary mapping transect IDs to their calculated F-factors.
        - Uses vectorized pandas operations to assign F-factors to points with valid transect IDs.
        - Maintains the default F-factor for points without transect assignments (typically below the lowermost cross-section).

        Parameters:
            ff_calc (pd.DataFrame): DataFrame of flowline points with 'transect_id' column assigned.
            ffactor_csv (pd.DataFrame): DataFrame containing 'transect_id' and corresponding 'ffactor' values from cross-section analysis.

        Returns:
            pd.DataFrame: The updated DataFrame with 'ffactor' column populated for all flowline points.
        """
        
        ff_calc['ffactor'] = 1.0
    
        # Create lookup dictionary for O(1) transect_id to ffactor mapping
        transect_to_ffactor = dict(zip(ffactor_csv['transect_id'], ffactor_csv['ffactor']))
    
        # Vectorized assignment using pandas .map()
        valid_transect_mask = ff_calc['transect_id'].notna()
        ff_calc.loc[valid_transect_mask, 'ffactor'] = ff_calc.loc[valid_transect_mask, 'transect_id'].map(transect_to_ffactor)
    
        return ff_calc
    
    def ice_reconstruction_with_ffactor(self, df, shear, feedback=None):
        """
        Reconstruct ice surface and calculate ice thickness along flowlines using an F-factor adjusted shear stress.

        This function:
        - Processes the main flowline (points with prox_id as NaN) sequentially to compute the ice surface.
        - Processes each tributary from its confluence point, using the inherited ice surface value.
        - Adjusts the shear stress by dividing by the F-factor.
        - Computes new ice surface values using a quadratic model.
        - Calculates 'ff_thickness' as the difference between the reconstructed surface and the DEM value ('rvalue1'),
        ensuring non-negative thickness.
        - Replaces any zero thickness values using a nearest neighbor approach.

        Parameters:
            df (pd.DataFrame): Flowline data containing at least 'fid', 'prox_id', 'ffactor', 'rvalue1', 'xcoord', and 'ycoord'.
            shear (float): The baseline shear stress value.

        Returns:
            pd.DataFrame: The updated DataFrame with new columns 'ff_ice_surface' and 'ff_thickness'.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81  # Gravitational acceleration (m/s2)

        # Initialize a dictionary for storing ice surface values
        surface_dict = {}

        # Main flowline handling — sort by distance so reconstruction proceeds
        # terminus → head (distance = 0 at terminus, increases upstream).
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat].sort_values('distance').reset_index(drop=True)

        if main_flowline.empty:
            raise QgsProcessingException(
                "No main flowline points found. "
                "Check that the flowline and ice thickness points are correctly linked."
            )

        prev_surface = None
        for i, row in main_flowline.iterrows():
            if i == main_flowline.index[0]:
                surface_dict[row['fid']] = row['rvalue1']
                prev_surface = row['rvalue1']
            else:
                dx = row['xcoord'] - main_flowline.loc[i - 1, 'xcoord']
                dy = row['ycoord'] - main_flowline.loc[i - 1, 'ycoord']
                d = np.sqrt(dx**2 + dy**2)

                # Adjust shear stress using F-factor
                adjusted_shear = shear / row['ffactor']

                b = -(main_flowline.loc[i - 1, 'rvalue1'] + row['rvalue1'])
                c = prev_surface * (
                    row['rvalue1'] - (prev_surface - main_flowline.loc[i - 1, 'rvalue1'])
                ) - (2 * d * adjusted_shear) / (rho * g)

                discriminant = b**2 - 4 * c
                if discriminant >= 0:
                    prev_surface = (-b + np.sqrt(discriminant)) / 2
                else:
                    prev_surface = row['rvalue1']

                surface_dict[row['fid']] = prev_surface

        # Tributary handling - process in NETWORK order (multi-pass), not digitising
        # (cat) order: a tributary can only inherit its confluence surface once the
        # flowline it drains into has been reconstructed. Reconstruction proceeds
        # confluence -> headwall (confluence has smallest distance along network).
        tributaries = df[df['cat'] != main_flow_cat]
        pending = {cat: group.sort_values('distance').copy()
                   for cat, group in tributaries.groupby('cat')}

        def _reconstruct_tributary(group_sorted, confluence_surface):
            confluence_idx = group_sorted.index[0]
            surface_dict[group_sorted.loc[confluence_idx, 'fid']] = confluence_surface
            prev_surface = confluence_surface
            for i in range(1, len(group_sorted)):
                dx = group_sorted['xcoord'].iloc[i] - group_sorted['xcoord'].iloc[i - 1]
                dy = group_sorted['ycoord'].iloc[i] - group_sorted['ycoord'].iloc[i - 1]
                d = np.sqrt(dx**2 + dy**2)

                # Adjust shear stress using F-factor
                adjusted_shear = shear / group_sorted['ffactor'].iloc[i]

                b = -(group_sorted['rvalue1'].iloc[i - 1] + group_sorted['rvalue1'].iloc[i])
                c = prev_surface * (
                    group_sorted['rvalue1'].iloc[i] -
                    (prev_surface - group_sorted['rvalue1'].iloc[i - 1])
                ) - (2 * d * adjusted_shear) / (rho * g)

                discriminant = b**2 - 4 * c
                if discriminant >= 0:
                    prev_surface = (-b + np.sqrt(discriminant)) / 2
                else:
                    prev_surface = group_sorted['rvalue1'].iloc[i]

                surface_dict[group_sorted['fid'].iloc[i]] = prev_surface

        while pending:
            ready = [cat for cat, group_sorted in pending.items()
                     if group_sorted.iloc[0]['prox_id'] in surface_dict]
            if not ready:
                for cat, group_sorted in pending.items():
                    msg = (f"Tributary cat={cat}: downstream link (fid "
                           f"{group_sorted.iloc[0]['prox_id']}) was never reconstructed - "
                           "starting at BED elevation (zero ice thickness). Check the "
                           "flowline digitising direction and network connectivity.")
                    self._log(msg, level='warning')
                    if feedback is not None:
                        feedback.pushWarning(msg)
                    _reconstruct_tributary(group_sorted, group_sorted.iloc[0]['rvalue1'])
                break
            for cat in ready:
                group_sorted = pending.pop(cat)
                _reconstruct_tributary(group_sorted,
                                       surface_dict[group_sorted.iloc[0]['prox_id']])
        
        # # Tributary handling — sort by distance so reconstruction proceeds
        # # confluence → headwall (confluence has smallest distance along network).
        # tributaries = df[df['cat'] != main_flow_cat]
        # for cat, group in tributaries.groupby('cat'):
        #     group_sorted = group.sort_values('distance').copy()

        #     confluence_idx = group_sorted.index[0]
        #     confluence_fid = group_sorted.loc[confluence_idx, 'fid']
        #     prox_id = group_sorted.loc[confluence_idx, 'prox_id']

        #     if prox_id in surface_dict:
        #         confluence_surface = surface_dict[prox_id]
        #     else:
        #         confluence_surface = group_sorted.loc[confluence_idx, 'rvalue1']

        #     surface_dict[confluence_fid] = confluence_surface

        #     prev_surface = confluence_surface
        #     for i in range(1, len(group_sorted)):
        #         dx = group_sorted['xcoord'].iloc[i] - group_sorted['xcoord'].iloc[i - 1]
        #         dy = group_sorted['ycoord'].iloc[i] - group_sorted['ycoord'].iloc[i - 1]
        #         d = np.sqrt(dx**2 + dy**2)

        #         # Adjust shear stress using F-factor
        #         adjusted_shear = shear / group_sorted['ffactor'].iloc[i]

        #         b = -(group_sorted['rvalue1'].iloc[i - 1] + group_sorted['rvalue1'].iloc[i])
        #         c = prev_surface * (
        #             group_sorted['rvalue1'].iloc[i] - 
        #             (prev_surface - group_sorted['rvalue1'].iloc[i - 1])
        #         ) - (2 * d * adjusted_shear) / (rho * g)

        #         discriminant = b**2 - 4 * c
        #         if discriminant >= 0:
        #             prev_surface = (-b + np.sqrt(discriminant)) / 2
        #         else:
        #             prev_surface = group_sorted['rvalue1'].iloc[i]

        #         surface_dict[group_sorted['fid'].iloc[i]] = prev_surface

        df['ff_ice_surface'] = df['fid'].map(surface_dict)
        df['ff_thickness'] = df['ff_ice_surface'] - df['rvalue1']
        df['ff_thickness'] = np.maximum(df['ff_thickness'], 0)

        # Replace zero ff_thickness with nearest neighbor values
        df = self.replace_zero_ff_thickness_with_nearest_neighbor(df)

        # Ensure terminus has zero ice thickness
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]
        
        if not main_flowline.empty:
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            terminus_idx = terminus_row.name
            df.at[terminus_idx, 'ff_thickness'] = 0
            df.at[terminus_idx, 'ff_ice_surface'] = df.at[terminus_idx, 'rvalue1']

        # Drop unwanted columns before returning df (keep 'distance' for validate_driving_stress)
        columns_to_drop = ['Shape_Leng', 'angle', 'rvalue1']
        df = df.drop(columns=columns_to_drop, errors='ignore')

        return df

    def replace_zero_ff_thickness_with_nearest_neighbor(self, df):
        """
        Replace zero F-factor thickness values using prox_id mapping and nearest neighbor search,
        but preserve zero thickness only at the true glacier terminus (end of main flowline).

        This function:
        - Identifies the true glacier terminus as the minimum distance point on the main flowline.
        - Replaces zero F-factor thickness values first by checking the thickness of the point referenced by 'prox_id'.
        - For remaining zero values, performs a nearest neighbor search among non-zero thickness points.
        - Preserves zero thickness at the true glacier terminus to maintain glaciological accuracy.

        Parameters:
            df (pd.DataFrame): DataFrame containing 'ff_thickness', 'prox_id', 'xcoord', 'ycoord', 'fid', 'cat', and 'distance' columns.

        Returns:
            pd.DataFrame: The updated DataFrame with zero 'ff_thickness' values replaced by valid values, except at the terminus.
        """
        
        # Find the true terminus - point with minimum distance on main flowline
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]
        
        if not main_flowline.empty:
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            true_terminus_fid = terminus_row['fid']
        else:
            true_terminus_fid = None

        # Only replace zeros that are NOT at the true terminus
        if true_terminus_fid is not None:
            zero_mask = (df['ff_thickness'] == 0) & (df['fid'] != true_terminus_fid)
        else:
            zero_mask = (df['ff_thickness'] == 0)
        
        zero_thickness_points = df[zero_mask]
        non_zero_points = df[df['ff_thickness'] != 0]

        if zero_thickness_points.empty:
            return df

        if non_zero_points.empty:
            raise QgsProcessingException(
                "Cannot replace zero-thickness points: no non-zero thickness points exist in this dataset. "
                "Check that the input ice thickness data contains valid non-zero values."
            )

        # Coordinates of non-zero and zero thickness points
        non_zero_coords = np.array(non_zero_points[['xcoord', 'ycoord']])
        zero_coords = np.array(zero_thickness_points[['xcoord', 'ycoord']])

        for i, zero_point in enumerate(zero_coords):
            # Get the index of the current zero-thickness point in the original DataFrame
            zero_thickness_index = zero_thickness_points.index[i]
            current_row = df.loc[zero_thickness_index]

            # Check if the point is a tributary confluence
            prox_id = current_row['prox_id']
            if not pd.isna(prox_id):  
                if prox_id in df['fid'].values:
                    near_point_thickness = df.loc[df['fid'] == prox_id, 'ff_thickness'].values[0]
                    if near_point_thickness > 0:  
                        df.at[zero_thickness_index, 'ff_thickness'] = near_point_thickness
                        continue  

            # If not a confluence or valid `prox_id`, use the nearest neighbor logic
            distances = np.sqrt(np.sum((non_zero_coords - zero_point) ** 2, axis=1))
            nearest_idx = np.argmin(distances)
            nearest_thickness = non_zero_points['ff_thickness'].iloc[nearest_idx]

            # Update the ff_thickness for the zero-thickness point
            df.at[zero_thickness_index, 'ff_thickness'] = nearest_thickness

        return df

    def validate_driving_stress(self, df):
        """
        Validate computed driving stress to ensure values are within 50 kPa to 200 kPa.

        This function:
        - Calculates the surface slope using differences in 'xcoord', 'ycoord', and 'ice_surface' between consecutive points.
        - Computes driving stress as rho * g * ice_thickness * sin(slope), where rho is ice density and g is gravitational acceleration.
        - Flags points that have driving stress outside of the 50 kPa to 200 kPa range.
        - Returns the updated DataFrame (after dropping temporary columns), the percentage of points with valid driving stress, and a list of invalid point IDs.

        Parameters:
            df (pd.DataFrame): DataFrame containing 'ice_thickness', 'xcoord', 'ycoord', 'ice_surface', and 'fid'.

        Returns:
            tuple: A tuple containing:
                - (pd.DataFrame) The updated DataFrame without temporary columns.
                - (float) Percentage of points with valid driving stress.
                - (list) List of 'fid' values for points outside the valid range.
        """
        
        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Sort within each flowline segment so diff() follows flow direction
        df = df.sort_values(['cat', 'distance']).copy()

        # Compute slope within each cat group — NaN for the first point of each
        # group (no predecessor within that segment).
        dx = df.groupby('cat')['xcoord'].diff()
        dy = df.groupby('cat')['ycoord'].diff()
        dz = df.groupby('cat')['ff_ice_surface'].diff()

        # Points where a slope can actually be computed (not first of group)
        slope_computable = dx.notna()
        d = np.sqrt(dx**2 + dy**2).where(slope_computable)
        d = d.replace(0, np.nan)  # avoid division by zero at coincident points
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate basal shear stress (F × ρgH sin α) only where slope is defined.
        # This matches what 'shear' represents in the reconstruction (F × driving stress),
        # so a correctly reconstructed glacier should yield values close to the input shear.
        driving_stress = df['ffactor'] * rho * g * df['ff_thickness'] * np.sin(surface_slope)

        # Validate only the points where slope could be computed; segment
        # boundary points (first of each cat) are excluded from the count.
        stress_valid = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        df['stress_valid'] = stress_valid

        evaluable = slope_computable
        invalid_points = df.loc[evaluable & ~stress_valid, 'fid'].tolist()
        valid_points = stress_valid[evaluable].sum()
        total_points = evaluable.sum()

        df = df.drop(columns=['stress_valid', 'distance', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')
        if total_points == 0:
            return df, 0.0, []
        valid_percentage = (valid_points / total_points) * 100

        return df, valid_percentage, invalid_points

    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message after processing and perform any necessary post-processing tasks.

        This function:
        - Creates and displays a QMessageBox with a completion message.
        - Sets the processing progress to 100% and updates the progress text.
        - Returns a dictionary indicating the status of post-processing.

        Parameters:
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): The feedback object for progress updates.

        Returns:
            dict: A dictionary reflecting the post-processing completion status.
        """

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("F-Factor Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)
    

