"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D shape-factor FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, math, processing
import numpy as np
import pandas as pd
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (QgsField,
                       QgsFields,
                       QgsProject,
                       QgsPointXY,
                       QgsFeature,
                       QgsGeometry,
                       QgsWkbTypes,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsVectorLayer,
                       QgsRasterBandStats,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer)
                       
class Ffactor(QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for calculating and applying the shape friction factor (F-Factor).

    The F-Factor quantifies flow resistance caused by lateral drag and is calculated 
    using the glacier's cross-sectional area and perimeter length. This tool applies 
    the F-Factor to refine ice thickness and surface elevation estimates along flowlines.

    Key Features:
    - Validates input layers (DEM, flowlines, ice thickness points).
    - Computes the F-Factor based on glacier geometry.
    - Propagates F-Factor values to flowline points.
    - Adjusts ice thickness and surface elevation using the F-Factor.

    Inputs:
    - DEM: Raster representing glacier basal topography.
    - Flowlines: Vector file of glacier flowlines.
    - Ice Thickness Points: Vector file with pre-computed ice thickness and surface elevation.

    Output:
    - A vector layer with F-Factor-adjusted ice thickness and surface elevation.

    References:
    - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of Glaciology, 2, pp. 82–93.
    - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the Ice-Sheets. Nature, 169, pp. 529–530.
    - Nye, J.F., 1965. The flow of a glacier in a channel of rectangular, elliptic or parabolic cross-section. 
      Journal of Glaciology, 5, pp. 661–690.
    - Shilling, D.H., Hollin, J.T., 1981. Numerical reconstructions of valley glaciers and small icecaps. 
      In: Denton, G.H., Hughes, T.J. (Eds.), The Last Great Ice Sheets. Wiley, New York, pp. 207–220.
    - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program for reconstructing the surface 
      profile of former mountain glaciers and ice caps. Computers & Geosciences, 36, pp. 605–610.
    """ 

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    shear_stress = 'specify_shear_stress'
    input_flowline = 'input_flowline'
    input_transects = 'transects'
    ice_flow_thickness = 'ice_flow_thickness'

    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return 'F-Factor'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """        
        
        return '3. 2D shape-factor FL Ice Thickness'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
       
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("2 F-Factor", text)

    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)

    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """  
        
        return self.tr(
            "The shape friction factor (F-Factor) quantifies flow resistance due to lateral drag. "
            "It is calculated based on the cross-sectional area and perimeter length of the glacier profile. "
            "The F-Factor is computed for all input points and applied to re-estimate ice thickness and "
            "surface elevation at each point.\n\n"
            "N.B. See Nye (1952a, b), Nye (1965), Shilling and Hollin (1981), and Benn and Hulton (2010) "
            "for detailed information on the F-Factor.\n\n"
            "References:\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the Ice-Sheets. "
            "Nature 169, pp. 529–530.\n"
            "  - Nye, J.F., 1965. The flow of a glacier in a channel of rectangular, elliptic or parabolic cross-section. "
            "Journal of Glaciology 5, pp. 661–690.\n"
            "  - Shilling, D.H., Hollin, J.T., 1981. Numerical reconstructions of valley glaciers and small icecaps. "
            "In: Denton, G.H., Hughes, T.J. (Eds.), The Last Great Ice Sheets. Wiley, New York, pp. 207–220.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program for reconstructing the surface profile "
            "of former mountain glaciers and ice caps. Computers & Geosciences 36, pp. 605–610.")
    
    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            Ffactor: A new instance of the `Ffactor` class.
        """

        return Ffactor()

    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        # Construct the path to the icons folder relative to this file
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'ffactor.png')  # Ensure this is the correct filename

        # Return the QIcon
        return QIcon(icon_file)
        
    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """
        
        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem, 
        self.tr("\nSelect current topography elevation data (DSM/DTM)"),
        [QgsProcessing.TypeRaster])) 
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.ice_flow_thickness, 
        self.tr("\nSelect ice flow thickness points (vector point file)"),
        [QgsProcessing.TypeVectorPoint])) 
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_transects,
        self.tr("\nSelect transect lines (vector polyline file)"),
        [QgsProcessing.TypeVectorLine]))
        
        self.addParameter(QgsProcessingParameterVectorLayer( 
        self.input_flowline, 
        self.tr("\nSelect flow line (vector polyline file)"),
        [QgsProcessing.TypeVectorLine]))
        
        self.addParameter(QgsProcessingParameterNumber(
        self.shear_stress, 
        self.tr("\nSpecify shear stress value"),
        QgsProcessingParameterNumber.Integer, minValue=0, defaultValue=100000))

    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Executes the algorithm and performs an F-factor estimation for glacier valley transects
        and corrects ice thickness estimates based on user inputs.
        """
        feedback = QgsProcessingMultiStepFeedback(18, model_feedback)
        results = {}

        # Preprocess and validate inputs
        inputs = self.preprocess_inputs(parameters, context, feedback)
        dem = inputs["dem"]
        dem_file = inputs["dem_file"]
        crs = inputs["crs"]
        crs_string = inputs["crs_string"]
        shear = inputs["shear"]
        ice_pts = inputs["ice_pts"]
        ice_thickness_pts_file = inputs["ice_thickness_pts_file"]
        flowline = inputs["flowline"]
        flowline_file = inputs["flowline_file"]
        transects = inputs["transects"]
        transects_file = inputs["transects_file"]

        # Generate the interval distance using the ice thickness points layer
        distance = self.point_distance(ice_pts)

        # Log initial parameters and start time
        start_time = time.time()
        self.log_initialization(feedback, dem_file, ice_thickness_pts_file, distance, flowline_file,
                                transects_file, shear)

        # Process transects
        transects_processed = self.process_transects(transects, context, feedback)

        # Generate points along transects
        transect_points = self.generate_points_along_transects(transects_processed, distance, dem, context, feedback)
        if feedback.isCanceled():
            return {}

        # Process intersections
        intersections = self.process_intersections(transects_processed, flowline, dem, context, feedback)
        if feedback.isCanceled():
            return {}

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        self.log_initialization(feedback, stage="input_processed")
        self.log_processing_duration("Pre-process input data", start_time)

        # Convert layers to DataFrame
        df_start_time = time.time()
        intersection_with_coords = self.add_xy_coordinates(intersections, "Intersection Points with X/Y", feedback)
        transect_points_with_coords = self.add_xy_coordinates(transect_points, "Sampled Points with X/Y", feedback)
        intersection_df = self.create_dataframe(intersection_with_coords, feedback=feedback)
        ice_pts_df = self.create_dataframe(transect_points_with_coords, feedback=feedback)
        ff_calc_df = self.create_dataframe(ice_pts, feedback=feedback)
        transect_df = self.pre_process_dataframe(ice_pts_df)
        self.log_initialization(feedback, stage="data_prep")
        self.log_processing_duration("Data processed for calculation", df_start_time)

        # F-factor estimation
        ff_start_time = time.time()
        ffactor = self.calculate_ffactor(transect_df, feedback)
        ffactor_csv = ffactor.copy()
        self.log_initialization(feedback, stage="estimate_ffactor")
        self.log_processing_duration("F-factor calculation", ff_start_time)

        # Spatial linking flowlines and tributary branches
        link_start_time = time.time()
        ff_calc_linked = self.assign_upstream_id(ff_calc_df, intersection_df, ffactor_csv)
        self.log_initialization(feedback, stage="tributary_centreline")
        self.log_processing_duration("Spatially linked tributary branches and centreline", link_start_time)

        # Propagate F-factor
        prop_start_time = time.time()
        ffactor_prop = self.propagate_ffactor(ff_calc_linked)
        self.log_initialization(feedback, stage="apply_ffactor")
        self.log_processing_duration("2D shape-factor propagation to ice thickness", prop_start_time)

        # Correct ice thickness
        recon_start_time = time.time()
        result_df = self.ice_reconstruction_with_ffactor(ffactor_prop, shear)
        self.log_initialization(feedback, stage="calculate_corrected")
        self.log_processing_duration("Calculate 2D shape-factor corrected ice thickness", recon_start_time)

        # Validate and load results
        val_start_time = time.time()
        validated_df, valid_percentage, invalid_points = self.validate_driving_stress(result_df)
        self.log_initialization(feedback, stage="validation", valid_percentage=valid_percentage, invalid_points=invalid_points)
        self.log_processing_duration("Ice surface and thickness validation", val_start_time)

        load_start_time = time.time()
        self.load_dataframe_to_qgis(validated_df, crs, QgsProject.instance(), feedback=feedback,
                                    layer_name="2D shape-factor FL Ice Thickness")
        self.log_initialization(feedback, stage="load_qgis")
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", load_start_time)

        self.log_final_results(feedback, crs_string, start_time)

        results = {"Status": "Complete"}
        return results

    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieve and validate input layers and parameters for the F-factor estimation.

        This function:
        - Loads the input DEM and vector layers (ice thickness points, flowline, and transects).
        - Retrieves the shear stress value.
        - Extracts filenames or names for logging purposes.
        - Validates that the DEM, flowline, transects, and ice thickness points are valid.
        - Validates that all input layers share the same CRS.

        Parameters:
            parameters (dict): Dictionary of user-supplied parameters for the algorithm.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): Object for logging progress and messages.

        Returns:
            dict: A dictionary with the following keys and values:
                - "dem" (QgsRasterLayer): The input DEM layer.
                - "dem_file" (str or None): Source of the DEM, or None if DEM is missing.
                - "crs" (QgsCoordinateReferenceSystem): The DEM's CRS.
                - "crs_string" (str): The DEM's CRS AuthID, or "Unknown CRS" if invalid.
                - "shear" (int): The shear stress value.
                - "ice_pts" (QgsVectorLayer): The input ice thickness points layer.
                - "ice_thickness_pts_file" (str): The name of the ice thickness points layer.
                - "flowline" (QgsVectorLayer): The input flowline layer.
                - "flowline_file" (str): The name of the flowline layer.
                - "transects" (QgsVectorLayer): The input transects layer.
                - "transects_file" (str): The name of the transects layer.

        Raises:
            QgsProcessingException: If modify_values is enabled but no features are selected, or if the input layer is invalid.
        """

        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)
        dem_file = dem.source() if dem else None
        crs = dem.crs() if dem else None
        crs_string = crs.authid() if crs and crs.isValid() else 'Unknown CRS'

        shear = self.parameterAsInt(parameters, self.shear_stress, context)

        ice_pts = self.parameterAsVectorLayer(parameters, self.ice_flow_thickness, context)
        ice_thickness_pts_file = ice_pts.name() if ice_pts else ""

        flowline = self.parameterAsVectorLayer(parameters, self.input_flowline, context)
        flowline_file = flowline.name() if flowline else ""

        transects = self.parameterAsVectorLayer(parameters, self.input_transects, context)
        transects_file = transects.name() if transects else ""

        # Validate layers
        self.validate_flowline_and_transect(flowline, transects)
        self.validate_dem_input(dem)
        self.validate_input_points(ice_pts)

        # Validate CRS consistency
        self.validate_layer_crs(flowline, crs)
        self.validate_layer_crs(transects, crs)
        self.validate_layer_crs(ice_pts, crs)

        return {
            "dem": dem,
            "dem_file": dem_file,
            "crs": crs,
            "crs_string": crs_string,
            "shear": shear,
            "ice_pts": ice_pts,
            "ice_thickness_pts_file": ice_thickness_pts_file,
            "flowline": flowline,
            "flowline_file": flowline_file,
            "transects": transects,
            "transects_file": transects_file
        }

    def process_transects(self, transects, context, feedback):
        """
        Add and remove specific fields in the transects layer and generate an auto-increment field.

        This function:
        - Adds a new 'Id' field to the transects layer using the field calculator.
        - Removes any existing 'id' field.
        - Creates an auto-increment field named 'transect_id' to serve as a transect identifier.

        Parameters:
            transects (QgsVectorLayer): The input transects layer.
            context (QgsProcessingContext): QGIS processing context for running child algorithms.
            feedback (QgsProcessingFeedback): Feedback object for progress reporting.

        Returns:
            QgsVectorLayer: The updated transects layer with the new auto-increment field and without the 'id' field.
        """


        # Add new 'Id' field using the field calculator
        params_add_field = {
            'FIELD_NAME': 'Id',
            'FIELD_TYPE': 1,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 0,
            'FORMULA': '@row_number + 1',
            'INPUT': transects,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        layer_id = processing.run('native:fieldcalculator', params_add_field,
                                context=context, feedback=None, is_child_algorithm=True)['OUTPUT']

        # Remove the unwanted 'id' field
        params_delete_field = {
            'INPUT': layer_id,
            'COLUMN': ['id'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        transects_no_id = processing.run('native:deletecolumn', params_delete_field,
                                        context=context, feedback=None, is_child_algorithm=True)['OUTPUT']

        # Add auto-incremental field to create a proper transect identifier
        params_auto_field = {
            'FIELD_NAME': 'transect_id',
            'GROUP_FIELDS': None,
            'INPUT': transects_no_id,
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        transects_with_id = processing.run('native:addautoincrementalfield', params_auto_field,
                                            context=context, feedback=None, is_child_algorithm=True)['OUTPUT']

        return transects_with_id

    def generate_points_along_transects(self, transects_layer, distance, dem, context, feedback):
        """
        Create points along transect lines, sample DEM values at those points, and add X/Y coordinates.

        This function:
        - Breaks each transect line into points spaced by the specified distance.
        - Samples the input DEM at each generated point.
        - Appends X and Y coordinate fields to the output points layer.

        Parameters:
            transects_layer (QgsVectorLayer): The layer containing transect lines.
            distance (float): The interval at which points are generated along each line.
            dem (QgsRasterLayer): The DEM raster used for sampling elevation values.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Feedback object for progress reporting.

        Returns:
            QgsVectorLayer: A point layer with sampled DEM values and added X/Y coordinate fields.
        """

        # Break transect lines into points
        params_points = {
            'DISTANCE': distance,
            'END_OFFSET': 0,
            'INPUT': transects_layer,
            'START_OFFSET': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        points_result = processing.run('native:pointsalonglines', params_points,
                                    context=context, feedback=None, is_child_algorithm=True)
        points_layer = points_result['OUTPUT']
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Sample DEM values at the generated points
        params_sampling = {
            'COLUMN_PREFIX': 'values',
            'INPUT': points_layer,
            'RASTERCOPY': dem,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        sampling_result = processing.run('native:rastersampling', params_sampling,
                                        context=context, feedback=None, is_child_algorithm=True)
        sampled_layer = sampling_result['OUTPUT']
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Add X and Y coordinate fields
        params_xy = {
            'CALC_METHOD': 0,  # 0 = Layer CRS
            'INPUT': sampled_layer,
            'OUTPUT': '/vsimem/temp_x-y_coords'
        }
        xy_result = processing.run('qgis:exportaddgeometrycolumns', params_xy,
                                context=context, feedback=None, is_child_algorithm=True)
        return xy_result['OUTPUT']

    def process_intersections(self, transects_layer, flowline, dem, context, feedback):
        """
        Compute intersections between transects and the flowline, and sample DEM values at those points.

        This function:
        - Computes the intersection points between the transects layer and the flowline layer.
        - Samples the input DEM at each intersection point to assign an elevation attribute.

        Parameters:
            transects_layer (QgsVectorLayer): The transects layer.
            flowline (QgsVectorLayer): The flowline layer.
            dem (QgsRasterLayer): The DEM for elevation sampling.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): Feedback object for progress reporting.

        Returns:
            QgsVectorLayer: A points layer representing the intersections, with DEM values sampled.
        """

        params_intersect = {
            'INPUT': transects_layer,
            'INPUT_FIELDS': [''],
            'INTERSECT': flowline,
            'INTERSECT_FIELDS': [''],
            'INTERSECT_FIELDS_PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        intersect_result = processing.run('native:lineintersections', params_intersect,
                                            context=context, feedback=None, is_child_algorithm=True)
        intersection_layer = intersect_result['OUTPUT']
        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        params_sampling = {
            'COLUMN_PREFIX': 'rvalue',
            'INPUT': intersection_layer,
            'RASTERCOPY': dem,
            'OUTPUT': '/vsimem/temp_intersect_pts'
        }
        intersect_sampling = processing.run('native:rastersampling', params_sampling,
                                            context=context, feedback=None, is_child_algorithm=True)
        sampled_intersections = intersect_sampling['OUTPUT']
        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        return sampled_intersections

    def get_longest_line_length(self, layer):
        """
        Determine the length of the longest line in a line or multi-line layer.

        This function:
        - Iterates over all features in the input layer.
        - For multi-part geometries, processes each part; for single-part, processes the line.
        - Tracks and returns the maximum measured line length.

        Parameters:
            layer (QgsVectorLayer): The vector layer containing line or multi-line geometries.

        Returns:
            float: The length of the longest line in the layer; 0.0 if no valid geometry is found.
        """
        
        longest = 0.0
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            # Get a list of polylines (one for single-part, many for multi-part)
            lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]

            # Compute lengths and update 'longest' if we find a longer one
            for line in lines:
                length = QgsGeometry.fromPolylineXY(line).length()
                if length > longest:
                    longest = length

        return longest

    def validate_flowline_and_transect(self, flowline_layer, transect_layer):
        """
        Validate that the longest line in the flowline layer is strictly longer than the longest
        line in the transect layer.

        This function:
        - Computes the longest line length for both flowline and transect layers.
        - Raises an exception if the flowline's longest line is not strictly longer than the transect's.

        Parameters:
            flowline_layer (QgsVectorLayer): The glacier flowline layer.
            transect_layer (QgsVectorLayer): The transect (cross-section) layer.

        Returns:
            None

        Raises:
            QgsProcessingException: If the flowline's longest line is not longer than the transect's.
        """

        flowline_longest = self.get_longest_line_length(flowline_layer)
        transect_longest = self.get_longest_line_length(transect_layer)

        # Check that the input flowline layer is longer than the input transect layer.
        if flowline_longest <= transect_longest:
            raise QgsProcessingException(
                "Invalid input: Please ensure you have selected the correct flowline"
                " and transect/cross-section layers.\n"
            )
        
        return

    def validate_dem_input(self, input_raster):
        """
        Determine whether the input raster is a valid DEM rather than a hillshade.

        This function:
        - Checks that the raster is valid.
        - Scans the raster's filename for common hillshade keywords.
        - Evaluates raster statistics (value range, standard deviation) to detect hillshade-like data.

        Parameters:
            input_raster (QgsRasterLayer): The raster layer to validate.

        Returns:
            bool: True if the raster appears to be a valid DEM; False otherwise.

        Raises:
            QgsProcessingException: If the input raster is invalid or appears to be a hillshade.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected raster layer is missing or invalid.\n\n"
                "Please ensure you have selected a valid DEM.\n"
            )

        # Check filename for "hillshade" or similar keywords
        hillshade_keywords = ["hillshade", "hillShade", "HillShade", "Hillshade", "HILLSHADE"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be valid DEM.\n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1, QgsRasterBandStats.All)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be valid DEM. \n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

    def validate_input_points(self, input_layer):
        """
        Confirm that a vector layer contains all required fields for ice flow thickness calculations.

        This function:
        - Verifies that the layer is valid.
        - Checks that the layer includes the required fields:
            'cat', 'distance', 'prox_id', 'ice_thickness', and 'ice_surface'.

        Parameters:
            input_layer (QgsVectorLayer): The input vector layer to validate.

        Returns:
            bool: True if the layer contains all required fields; otherwise, raises an exception.

        Raises:
            QgsProcessingException: If the input layer is invalid or missing required fields.
        """

        # Required fields
        required_fields = {'cat', 'distance', 'prox_id', 'ice_thickness', 'ice_surface'}

        # Ensure the layer is valid
        if not input_layer or not input_layer.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected points layer is missing or invalid.\n\n"
                "Please ensure you have selected the correct layer."
            )

        # Check if required fields exist in the layer
        layer_fields = {field.name() for field in input_layer.fields()}
        missing_fields = required_fields - layer_fields

        if missing_fields:
            raise QgsProcessingException(
                f"Invalid input: The selected points layer is missing required fields.\n\n"
                "Please execute, or re-execute, '2D FL Ice Thickness'.\n"
            )

        return True
    
    def validate_layer_crs(self, layer, target_crs):
        """
        Ensure that the layer's CRS matches the specified target CRS.

        This function:
        - Validates the input layer.
        - Compares the layer's CRS against the target CRS.
        - Raises an exception if there is a mismatch.

        Parameters:
            layer (QgsVectorLayer or QgsRasterLayer): The layer to check.
            target_crs (QgsCoordinateReferenceSystem): The expected CRS.

        Returns:
            None

        Raises:
            QgsProcessingException: If the layer is invalid or its CRS does not match the target.
        """

        if not layer or not layer.isValid():
            raise QgsProcessingException("Invalid input layer.")
        
        if layer.crs().authid() != target_crs.authid():
            raise QgsProcessingException(
                f"CRS mismatch:  All input layers and data must use the same projected CRS."
                "\n\nPlease ensure all input data share the same projected CRS.\n"
            )

    def log_initialization(self, feedback, dem_filename=None, ice_thick_name=None, 
                           distance=None, flowline_name=None, transects_name=None, 
                           shear=None, stage=None, valid_percentage=None, invalid_points=None):
        """
        Log initialization details and stage-specific messages to the QGIS feedback console.

        This function:
        - When stage is None, logs initial parameters (DEM filename, ice flow thickness points, resolution,
        flowline, transects, and shear value).
        - For specific stages (e.g., "input_processed", "data_prep", "estimate_ffactor", etc.), updates
        the progress text accordingly.
        - Optionally reports warnings during validation if the valid percentage is below a threshold.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for logging messages.
            dem_filename (str, optional): The DEM filename.
            ice_thick_name (str, optional): The ice thickness points layer name.
            distance (float, optional): The spatial resolution (map units).
            flowline_name (str, optional): The flowline layer name.
            transects_name (str, optional): The transects layer name.
            shear (float, optional): The shear stress value.
            stage (str, optional): The current processing stage; if None, initial parameters are logged.
            valid_percentage (float, optional): Percentage of valid points (used for validation stage).
            invalid_points (list, optional): List of invalid point IDs (used for validation stage).

        Returns:
            None
        """

        if stage is None:
            # Log initialization details
            feedback.setProgress(0)
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initialising 2D shape-factor FL Ice Thickness Calculation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo('Input Parameters:')
            feedback.pushInfo(f'  - DEM: {dem_filename}')
            feedback.pushInfo(f'  - Ice flow thickness points: {ice_thick_name}')
            feedback.pushInfo(f"  - Resolution (map units): {distance:.2f}")
            feedback.pushInfo(f'  - Flowline: {flowline_name}')
            feedback.pushInfo(f'  - Transects: {transects_name}')
            feedback.pushInfo(f'  - Shear value: {shear}')
            feedback.pushInfo('-------------------------------------------------------------\n')
            feedback.setProgressText('Pre-processing input data...\n')
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "estimate_ffactor":
            feedback.setProgressText("Estimating the 2D shape-factor of given ice flow thickness...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "apply_ffactor":
            feedback.setProgressText("Applying and propagating 2D shape-factor...\n")
        elif stage == "calculate_corrected":
            feedback.setProgressText("Correcting ice surface and thickness with 2D shape-factor...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 95:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushInfo(f"Invalid driving stress points (fid): {invalid_points}")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")        
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")

    def log_processing_duration(self, process_name, start_time):
        """
        Log the duration of a process to the QGIS message log.

        This function:
        - Calculates the elapsed time since the given start time.
        - Logs a message with the process name and execution time.

        Parameters:
            process_name (str): The name of the process.
            start_time (float): The start time (in seconds) of the process.

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"{process_name} completed in {duration:.4f} seconds", "2D shape-factor FL Ice Thickness Processing Log", level=3)

    def log_final_results(self, feedback, crs_string, start_time):
        """
        Log final results of the processing, including total duration and CRS information.

        This function:
        - Calculates total processing time since the provided start time.
        - Logs final messages including the CRS and runtime to both the QGIS message log and the feedback.
        - Sets progress to 100% and updates the progress text.

        Parameters:
            feedback (QgsProcessingFeedback): Feedback object for progress updates.
            crs_string (str): The CRS identifier of the processed data.
            start_time (float): The overall start time (in seconds) of the process.

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"All data calculated in projection: {crs_string}", "2D shape-factor FL Ice Thickness Processing Log", level=3)
        QgsMessageLog.logMessage("-----------------------------------------END PROCESS-----------------------------------------\n", 
                                "2D shape-factor FL Ice Thickness Processing Log", level=0)
        feedback.pushInfo(f"All data processed in: {duration:.4f} seconds.\n")
        feedback.pushInfo(f"All data processed and projected in: {crs_string}\n")
        feedback.setProgress(100)
        feedback.setProgressText("Processing Complete!\n")
        
    def point_distance(self, ice_pts):
        """
        Compute the Euclidean distance between the first two points in the given point layer.

        This function:
        - Sorts the features by the 'fid' field.
        - Retrieves the coordinates of the first and second points.
        - Computes and returns the Euclidean distance between them.

        Parameters:
            ice_pts (QgsVectorLayer): A point layer with at least two features, including 'xcoord' and 'ycoord'.

        Returns:
            float: The Euclidean distance between the first two points.

        Raises:
            ValueError: If the layer has fewer than two points.
        """

        if not ice_pts or ice_pts.featureCount() < 2:
            raise ValueError("The ice_flow_thickness layer must have at least two points.")
        
        # Extract features and sort by 'fid' to ensure sequential order
        features = sorted(ice_pts.getFeatures(), key=lambda f: f['fid'])

        # Get the first two points
        first_point = features[0]
        second_point = features[1]

        # Extract x and y coordinates
        x1, y1 = first_point['xcoord'], first_point['ycoord']
        x2, y2 = second_point['xcoord'], second_point['ycoord']

        # Calculate the Euclidean distance
        distance = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5

        return distance
         
    def add_xy_coordinates(self, input_layer_path, layer_name, feedback=None):
        """
        Append 'xcoord' and 'ycoord' fields to a point layer, storing each feature's geometry coordinates.

        This function:
        - Loads the layer from the given file path.
        - Validates that the layer is of point geometry.
        - Adds 'xcoord' and 'ycoord' fields to the layer.
        - Iterates through features to populate these fields with the corresponding X and Y coordinates.

        Parameters:
            input_layer_path (str): The file path of the point layer.
            layer_name (str): The name to assign to the loaded/modified layer.
            feedback (QgsProcessingFeedback, optional): For logging progress.

        Returns:
            QgsVectorLayer: The modified point layer with 'xcoord' and 'ycoord' attributes.

        Raises:
            ValueError: If the layer is invalid or is not a point layer.
        """

        # Load the layer from the input path
        layer = QgsVectorLayer(input_layer_path, layer_name, "ogr")

        if layer.geometryType() != QgsWkbTypes.PointGeometry:
            raise ValueError("Expected a Point geometry layer, but got something else.")


        if not layer.isValid():
            raise ValueError(f"Failed to load layer from path: {input_layer_path}")

        # Start editing to add attributes
        layer.startEditing()
        layer.addAttribute(QgsField('xcoord', QVariant.Double))
        layer.addAttribute(QgsField('ycoord', QVariant.Double))

        # Populate X and Y coordinates for each feature
        for feature in layer.getFeatures():
            geom = feature.geometry()
            if geom.isEmpty():
                feature['xcoord'] = None
                feature['ycoord'] = None
            else:
                point = geom.asPoint()
                feature['xcoord'] = point.x()
                feature['ycoord'] = point.y()
            layer.updateFeature(feature)

        layer.commitChanges()
        return layer
    
    def create_dataframe(self, temp_layer, attribute_names=None, feedback=None):
        """
        Generate a Pandas DataFrame from a QGIS vector layer, optionally extracting specific fields.

        This function:
        - Iterates through each feature in the input layer.
        - Extracts attributes specified by 'attribute_names' (or all fields if None).
        - Returns a DataFrame where each row represents a feature.

        Parameters:
            temp_layer (QgsVectorLayer): The vector layer to convert.
            attribute_names (list, optional): List of attribute names to extract. If None, all fields are used.
            feedback (QgsProcessingFeedback, optional): For progress reporting.

        Returns:
            pd.DataFrame: A DataFrame containing a row per feature with the selected attributes.
        """

        # Validate input layer
        if not isinstance(temp_layer, QgsVectorLayer):
            raise ValueError("Input must be a QgsVectorLayer.")

        data = [] 
        total_features = temp_layer.featureCount()

        # Extract all fields if attribute_names is None
        if attribute_names is None:
            attribute_names = [field.name() for field in temp_layer.fields()]

        for current_feature, feature in enumerate(temp_layer.getFeatures()):
            row = {name: feature.attribute(name) for name in attribute_names}
            data.append(row)

            # Update progress
            if feedback:
                progress_percentage = int((current_feature + 1) / total_features * 100)
                feedback.setProgress(progress_percentage)

        # Convert to DataFrame
        return pd.DataFrame(data)

    
    def pre_process_dataframe(self, df):
        """
        Rename specific column headers in the DataFrame to ensure consistency.

        This function:
        - Checks if columns such as 'FID', 'Fid', 'fid', 'ID', 'Id', 'id', 'NAME', 'Name', or 'name'
        exist in the DataFrame.
        - Renames any of those columns to 'grp_id' for uniformity.

        Parameters:
            df (pd.DataFrame): The input DataFrame.

        Returns:
            pd.DataFrame: A copy of the DataFrame with renamed columns where applicable.
        """

        # Define the column names to check and replace
        columns_to_replace = ['FID', 'Fid', 'fid', 'ID', 'Id', 'id', 'NAME', 'Name', 'name']

        # Iterate through the columns and replace if necessary
        for column in columns_to_replace:
            if column in df.columns:
                df = df.rename(columns={column: 'grp_id'})

        return df
    
    def calculate_ffactor(self, df, feedback=None):
        """
        Compute the shape factor (F-factor) for each transect based on 
        cross-sectional area, perimeter, and height difference.

        This function:
        - Sorts the DataFrame by 'transect_id' and 'distance'.
        - Calculates partial areas (A) and perimeter segments (P) between consecutive points.
        - Determines the total height difference (HH) across each transect.
        - Computes the F-factor as total_A divided by (HH * total_P).
        - Maps the F-factor back to each transect in the DataFrame.

        Parameters:
            df (pd.DataFrame): A DataFrame containing transect data, including 'transect_id', 'distance', and 'values1' (elevations).
            feedback (QgsProcessingFeedback, optional): For logging progress.

        Returns:
            pd.DataFrame: The updated DataFrame with new columns 'A', 'P', 'HH', and 'ffactor'.
        """

        # Ensure DataFrame is sorted by transect_id and distance
        df.sort_values(['transect_id', 'distance'], inplace=True, ignore_index=True)

        # Group by transect_id
        grouped = df.groupby('transect_id')

        # Initialize columns for A, P, and HH
        df['A'] = np.nan
        df['P'] = np.nan
        df['HH'] = np.nan 

        # Calculate A and P for each group
        for transect_id, group in grouped:
            distances = group['distance'].values
            elevations = group['values1'].values

            # Calculate A (cross-sectional area)
            A_values = 0.5 * (np.diff(distances) *
                            ((elevations.max() - elevations[:-1]) +
                            (elevations.max() - elevations[1:])))
            df.loc[group.index[1:], 'A'] = A_values

            # Calculate P (perimeter)
            P_values = np.sqrt(np.diff(distances)**2 + np.diff(elevations)**2)
            df.loc[group.index[1:], 'P'] = P_values

            # Calculate HH (height difference)
            height_diff = elevations.max() - elevations.min()
            df.loc[group.index, 'HH'] = height_diff

        # Calculate total A, P, and HH for each group
        total_A = grouped['A'].sum()
        total_P = grouped['P'].sum()
        height_diff = grouped['HH'].max() 

        # Calculate F-Factor 
        f_factor = total_A / (height_diff * total_P)

        # Map F-Factor back to the original DataFrame
        df['ffactor'] = df['transect_id'].map(f_factor)

        return df

    def assign_upstream_id(self, ff_calc, intersection_df, ffactor_csv):
        """
        Link flowline points to the nearest transect intersection and assign the transect ID and F-factor.

        This function:
        - Builds a lookup from 'transect_id' to 'ffactor' using the ffactor_csv DataFrame.
        - For each intersection point, finds the closest flowline point (using Euclidean distance)
        and assigns the intersection's transect ID and corresponding F-factor.
        
        Parameters:
            ff_calc (pd.DataFrame): DataFrame of flowline points with columns 'xcoord', 'ycoord', and 'fid'.
            intersection_df (pd.DataFrame): DataFrame of transect intersection points, including 'xcoord', 'ycoord', and 'transect_id'.
            ffactor_csv (pd.DataFrame): DataFrame mapping 'transect_id' to 'ffactor'.

        Returns:
            pd.DataFrame: The updated flowline points DataFrame with 'source_transect' and 'ffactor' assigned.
        """

        ff_calc = ff_calc.copy()
        ff_calc['source_transect'] = None
        ff_calc['ffactor'] = np.nan
        
        # Build a lookup for transect ffactor.
        transect_to_ffactor = dict(zip(ffactor_csv['transect_id'], ffactor_csv['ffactor']))
        
        # For each transect, find the closest flowline point by Euclidean distance and assign it.
        for _, transect in intersection_df.iterrows():
            tid = transect['transect_id']
            transect_pt = np.array([transect['xcoord'], transect['ycoord']])
            flowline_coords = ff_calc[['xcoord', 'ycoord']].values
            dists = np.linalg.norm(flowline_coords - transect_pt, axis=1)
            nearest_index = np.argmin(dists)
            ff_calc.at[nearest_index, 'source_transect'] = tid
            ff_calc.at[nearest_index, 'ffactor'] = transect_to_ffactor.get(tid, np.nan)
        
        return ff_calc

    def propagate_ffactor(self, ff_calc):
        """
        Propagate F-factor values along the flowline network using the downstream linkage.

        This function:
        - Uses the 'prox_id' to recursively follow the downstream chain of each flowline point.
        - Inherits the F-factor from the first point encountered in the chain with a non-null 'source_transect'.
        - Assigns a default F-factor (1.0) if no valid candidate is found.
        - Returns the DataFrame with updated 'ffactor' and 'source_transect' values.

        Parameters:
            ff_calc (pd.DataFrame): DataFrame containing 'fid', 'prox_id', 'ffactor', and 'source_transect' columns.

        Returns:
            pd.DataFrame: The updated DataFrame with propagated F-factor values along the flowline.
        """

        default_ffactor=1.0
        
        ff_calc = ff_calc.copy()
        
        # Build a lookup
        fid_to_prox = {}
        for idx, row in ff_calc.iterrows():
            fid = row['fid']
            prox = row['prox_id']
            fid_to_prox[fid] = prox if pd.notna(prox) else None
        
        # Build a dictionary of direct candidate info.
        # For nodes that are direct candidates, store (ffactor, source_transect).
        direct_candidates = {}
        for idx, row in ff_calc.iterrows():
            fid = row['fid']
            if pd.notna(row['source_transect']):
                direct_candidates[fid] = (row['ffactor'], row['source_transect'])
        
        # Use memoization to cache the inherited candidate for each fid.
        memo = {}
        
        def get_candidate(fid):
            """
            Recursively follow the downstream chain (using prox_id) until a direct candidate is found.
            Returns a tuple: (ffactor, source_transect).
            """
            if fid in memo:
                return memo[fid]
            
            # If this node is a direct candidate, return its info.
            if fid in direct_candidates:
                memo[fid] = direct_candidates[fid]
                return memo[fid]
            
            # Get the prox_id for this fid.
            prox = fid_to_prox.get(fid)
            if prox is None or prox not in fid_to_prox:
                # No downstream connection; assign default.
                memo[fid] = (default_ffactor, None)
                return memo[fid]
            
            # Otherwise, follow the downstream chain.
            candidate = get_candidate(prox)
            memo[fid] = candidate
            return candidate
        
        # For every flowline point, assign the propagated candidate.
        propagated_ffactor = []
        propagated_source = []
        
        for idx, row in ff_calc.iterrows():
            fid = row['fid']
            candidate_ff, candidate_source = get_candidate(fid)
            propagated_ffactor.append(candidate_ff)
            propagated_source.append(candidate_source)
        
        ff_calc['ffactor'] = propagated_ffactor
        ff_calc['source_transect'] = propagated_source
        
        return ff_calc
    
    def ice_reconstruction_with_ffactor(self, df, shear):
        """
        Reconstruct ice surface and calculate ice thickness along flowlines using an F-factor adjusted shear stress.

        This function:
        - Processes the main flowline (points with prox_id as NaN) sequentially to compute the ice surface.
        - Processes each tributary from its confluence point, using the inherited ice surface value.
        - Adjusts the shear stress by dividing by the F-factor.
        - Computes new ice surface values using a quadratic model.
        - Calculates 'ff_thickness' as the difference between the reconstructed surface and the DEM value ('rvalue1'),
        ensuring non-negative thickness.
        - Replaces any zero thickness values using a nearest neighbor approach.

        Parameters:
            df (pd.DataFrame): Flowline data containing at least 'fid', 'prox_id', 'ffactor', 'rvalue1', 'xcoord', and 'ycoord'.
            shear (float): The baseline shear stress value.

        Returns:
            pd.DataFrame: The updated DataFrame with new columns 'ff_ice_surface' and 'ff_thickness'.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81  # Gravitational acceleration (m/s2)

        # Initialize a dictionary for storing ice surface values
        surface_dict = {}

        # Main flowline handling 
        main_flow_cat = df['prox_id'].isna()
        main_flowline = df[main_flow_cat].sort_index().reset_index(drop=True)

        prev_surface = None
        for i, row in main_flowline.iterrows():
            if i == main_flowline.index[0]:
                surface_dict[row['fid']] = row['rvalue1']
                prev_surface = row['rvalue1']
            else:
                dx = row['xcoord'] - main_flowline.loc[i - 1, 'xcoord']
                dy = row['ycoord'] - main_flowline.loc[i - 1, 'ycoord']
                d = np.sqrt(dx**2 + dy**2)

                # Adjust shear stress using F-factor
                adjusted_shear = shear / row['ffactor']

                b = -(main_flowline.loc[i - 1, 'rvalue1'] + row['rvalue1'])
                c = prev_surface * (
                    row['rvalue1'] - (prev_surface - main_flowline.loc[i - 1, 'rvalue1'])
                ) - (2 * d * adjusted_shear) / (rho * g)

                discriminant = b**2 - 4 * c
                if discriminant >= 0:
                    prev_surface = (-b + np.sqrt(discriminant)) / 2
                else:
                    prev_surface = row['rvalue1']

                surface_dict[row['fid']] = prev_surface

        # Tributary handling
        tributaries = df[~main_flow_cat]
        for cat, group in tributaries.groupby('cat'):
            group_sorted = group.sort_index().copy()

            confluence_idx = group_sorted.index[0]
            confluence_fid = group_sorted.loc[confluence_idx, 'fid']
            prox_id = group_sorted.loc[confluence_idx, 'prox_id']

            if prox_id in surface_dict:
                confluence_surface = surface_dict[prox_id]
            else:
                confluence_surface = group_sorted.loc[confluence_idx, 'rvalue1']

            surface_dict[confluence_fid] = confluence_surface

            prev_surface = confluence_surface
            for i in range(1, len(group_sorted)):
                dx = group_sorted['xcoord'].iloc[i] - group_sorted['xcoord'].iloc[i - 1]
                dy = group_sorted['ycoord'].iloc[i] - group_sorted['ycoord'].iloc[i - 1]
                d = np.sqrt(dx**2 + dy**2)

                # Adjust shear stress using F-factor
                adjusted_shear = shear / group_sorted['ffactor'].iloc[i]

                b = -(group_sorted['rvalue1'].iloc[i - 1] + group_sorted['rvalue1'].iloc[i])
                c = prev_surface * (
                    group_sorted['rvalue1'].iloc[i] - 
                    (prev_surface - group_sorted['rvalue1'].iloc[i - 1])
                ) - (2 * d * adjusted_shear) / (rho * g)

                discriminant = b**2 - 4 * c
                if discriminant >= 0:
                    prev_surface = (-b + np.sqrt(discriminant)) / 2
                else:
                    prev_surface = group_sorted['rvalue1'].iloc[i]

                surface_dict[group_sorted['fid'].iloc[i]] = prev_surface

        df['ff_ice_surface'] = df['fid'].map(surface_dict)
        df['ff_thickness'] = df['ff_ice_surface'] - df['rvalue1']
        df['ff_thickness'] = np.maximum(df['ff_thickness'], 0)

        # Replace zero ff_thickness with nearest neighbor values
        df = self.replace_zero_ff_thickness_with_nearest_neighbor(df)

        # Drop unwanted columns before returning df
        columns_to_drop = ['Shape_Leng', 'distance', 'angle', 'rvalue1'] 
        df = df.drop(columns=columns_to_drop, errors='ignore')

        return df

    def replace_zero_ff_thickness_with_nearest_neighbor(self, df):
        """
        Replace zero F-factor thickness values in the DataFrame using prox_id and nearest neighbor search.

        This function:
        - Identifies rows where 'ff_thickness' is zero.
        - Attempts to replace the zero values by first checking the thickness of the point indicated by 'prox_id'.
        - For remaining zero values, performs a nearest neighbor search among non-zero thickness points and assigns the nearest non-zero value.

        Parameters:
            df (pd.DataFrame): DataFrame containing 'ff_thickness', 'prox_id', 'xcoord', 'ycoord', and 'fid' columns.

        Returns:
            pd.DataFrame: The updated DataFrame with zero 'ff_thickness' values replaced by valid values.
        """

        # Extract non-zero thickness points and zero-thickness points
        non_zero_points = df[df['ff_thickness'] != 0]
        zero_thickness_points = df[df['ff_thickness'] == 0]

        if zero_thickness_points.empty:
            return df  
        # Coordinates of non-zero and zero thickness points
        non_zero_coords = np.array(non_zero_points[['xcoord', 'ycoord']])
        zero_coords = np.array(zero_thickness_points[['xcoord', 'ycoord']])

        for i, zero_point in enumerate(zero_coords):
            # Get the index of the current zero-thickness point in the original DataFrame
            zero_thickness_index = zero_thickness_points.index[i]
            current_row = df.loc[zero_thickness_index]

            # Check if the point is a tributary confluence
            prox_id = current_row['prox_id']
            if not pd.isna(prox_id):  
                if prox_id in df['fid'].values:
                    near_point_thickness = df.loc[df['fid'] == prox_id, 'ff_thickness'].values[0]
                    if near_point_thickness > 0:  
                        df.at[zero_thickness_index, 'ff_thickness'] = near_point_thickness
                        continue  

            # If not a confluence or valid `prox_id`, use the nearest neighbor logic
            distances = np.sqrt(np.sum((non_zero_coords - zero_point) ** 2, axis=1))
            nearest_idx = np.argmin(distances)
            nearest_thickness = non_zero_points['ff_thickness'].iloc[nearest_idx]

            # Update the ff_thickness for the zero-thickness point
            df.at[zero_thickness_index, 'ff_thickness'] = nearest_thickness

        return df

    def validate_driving_stress(self, df):
        """
        Validate computed driving stress to ensure values are within 50 kPa to 200 kPa.

        This function:
        - Calculates the surface slope using differences in 'xcoord', 'ycoord', and 'ice_surface' between consecutive points.
        - Computes driving stress as rho * g * ice_thickness * sin(slope), where rho is ice density and g is gravitational acceleration.
        - Flags points that have driving stress outside of the 50 kPa to 200 kPa range.
        - Returns the updated DataFrame (after dropping temporary columns), the percentage of points with valid driving stress, and a list of invalid point IDs.

        Parameters:
            df (pd.DataFrame): DataFrame containing 'ice_thickness', 'xcoord', 'ycoord', 'ice_surface', and 'fid'.

        Returns:
            tuple: A tuple containing:
                - (pd.DataFrame) The updated DataFrame without temporary columns.
                - (float) Percentage of points with valid driving stress.
                - (list) List of 'fid' values for points outside the valid range.
        """
        
        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Calculate surface slope
        dx = df['xcoord'].diff().fillna(0)  # Difference in x
        dy = df['ycoord'].diff().fillna(0)  # Difference in y
        dz = df['ice_surface'].diff().fillna(0)  # Difference in surface elevation
        d = np.sqrt(dx**2 + dy**2 + 1e-6)  # Avoid division by zero
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate driving stress
        driving_stress = rho * g * df['ice_thickness'] * np.sin(surface_slope)

        # Validate driving stress
        df['stress_valid'] = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        invalid_points = df.loc[~df['stress_valid'], 'fid'].tolist()  
        valid_points = df['stress_valid'].sum()
        total_points = len(df)
        valid_percentage = (valid_points / total_points) * 100

        # Clean up temporary columns
        df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')

        return df, valid_percentage, invalid_points

    def load_dataframe_to_qgis(self, dataframe, crs, project_instance, layer_name='DataFrameLayer', feedback=None):
        """
        Import a Pandas DataFrame into QGIS as a memory vector layer with point geometry.

        This function:
        - Analyzes the DataFrame columns to create appropriate QgsFields (with Double, Int, or String types).
        - Creates a memory point layer using the provided CRS.
        - Inserts each row of the DataFrame as a feature with geometry derived from 'xcoord' and 'ycoord' columns.
        - Adds the constructed layer to the current QGIS project.

        Parameters:
            dataframe (pd.DataFrame): The DataFrame to import, which must include 'xcoord' and 'ycoord' columns.
            crs (QgsCoordinateReferenceSystem): The target CRS for the new layer.
            project_instance (QgsProject): The QGIS project instance.
            layer_name (str, optional): The desired name for the created layer (default is 'DataFrameLayer').
            feedback (QgsProcessingFeedback, optional): For logging progress.

        Returns:
            None
        """

        fields = QgsFields()

        # Dynamically detect column data types and create corresponding QgsFields
        for column in dataframe.columns:
            sample_value = dataframe[column].dropna().iloc[0] if not dataframe[column].dropna().empty else None
            
            if isinstance(sample_value, (float, np.floating)):
                field_type = QVariant.Double
            elif isinstance(sample_value, (int, np.integer)):
                field_type = QVariant.Int
            else:
                field_type = QVariant.String
            
            fields.append(QgsField(column, field_type))

        # Create a memory vector layer
        vector_layer = QgsVectorLayer('Point?crs={}'.format(crs.authid()), layer_name, 'memory')
        vector_layer.dataProvider().addAttributes(fields)
        vector_layer.updateFields()

        # Add features to the memory vector layer
        features = []

        total_features = len(dataframe)
        current_feature = 0

        # Iterate over each row in the DataFrame
        for row in dataframe.itertuples(index=False):
            feature = QgsFeature(fields)
            x_coord = float(row.xcoord)
            y_coord = float(row.ycoord)
            geometry = QgsGeometry.fromPointXY(QgsPointXY(x_coord, y_coord))
            feature.setGeometry(geometry)

            # Set attributes for each field
            for column, value in zip(dataframe.columns, row):
                if pd.isna(value):
                    feature.setAttribute(column, None)  # Handle NaN values
                else:
                    feature.setAttribute(column, value)

            features.append(feature)

            # Update progress
            current_feature += 1
            progress_percentage = int(current_feature / total_features * 100)
            if feedback:
                feedback.setProgress(progress_percentage)

            # Check for user cancellation
            if feedback and feedback.isCanceled():
                break

        vector_layer.dataProvider().addFeatures(features)

        # Add the memory vector layer to the map
        QgsProject.instance().addMapLayer(vector_layer)
           
    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message after processing and perform any necessary post-processing tasks.

        This function:
        - Creates and displays a QMessageBox with a completion message.
        - Sets the processing progress to 100% and updates the progress text.
        - Returns a dictionary indicating the status of post-processing.

        Parameters:
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): The feedback object for progress updates.

        Returns:
            dict: A dictionary reflecting the post-processing completion status.
        """

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("F-Factor Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec_()
        
        return super().postProcessAlgorithm(context, feedback)
    

