"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Q-GlaRe+  —  plugin package
===========================


"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris '
__date__ = '2025-05-29'
__copyright__ = '(C) 2025 Brian S. Burnham'
__email__ = 'brian.burnham@abdn.ac.uk'

__revision__ = '$Format:%H$'
__version__ = '0.1.2'

def classFactory(iface):  # pylint: disable=invalid-name
    """Load and return the QGlaRe+ plugin instance for QGIS."""

    from .qglare_plus import QglarePlusPlugin
    return QglarePlusPlugin(iface)
    