# -*- coding: utf-8 -*-
"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

grouped_dialog  —  collapsible parameters panel
===============================================

Shared dialog builder for the QGlaRe+ tools.

Re-arranges the standard Processing parameters panel: the tool icon at the top, the
inputs grouped into collapsible sections, and fields that only show when their
toggle or choice is set. The algorithm and its outputs are untouched - this only
changes how the dialog looks.

A tool calls build_grouped_dialog(...) from createCustomParametersWidget() and
returns the result. If anything here fails it returns None and QGIS uses the normal
dialog.
"""
import os

from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QLabel, QScrollArea
from qgis.core import Qgis, QgsMessageLog
from qgis.gui import QgsCollapsibleGroupBox

from processing.gui.AlgorithmDialog import AlgorithmDialog
from processing.gui.ParametersPanel import ParametersPanel
from processing.gui.wrappers import WidgetWrapper


# truthy test, for boolean toggles
def truthy(value):
    return bool(value)


def _field_row(wrapper):
    """Build a small row widget (label above field) for one parameter wrapper."""
    if issubclass(wrapper.__class__, WidgetWrapper):   # deprecated python wrapper
        widget, label = wrapper.widget, wrapper.label
    else:                                              # modern C++ wrapper
        widget, label = wrapper.wrappedWidget(), wrapper.createWrappedLabel()

    row = QWidget()
    v = QVBoxLayout(row)
    v.setContentsMargins(0, 3, 0, 3)
    v.setSpacing(3)
    if label is not None:
        v.addWidget(label)
    if widget is not None:
        v.addWidget(widget)
    return row


def build_grouped_dialog(plugin_dir, icon_name, title, sections, conditionals=None):
    """Return an AlgorithmDialog subclass with its parameters grouped into collapsible sections.

    The panel gets an icon header and titled collapsible groups, and rows that
    only appear when their controller passes a predicate.

    Args:
        plugin_dir: folder of the calling module, used to locate icons/.
        icon_name: file name inside icons/ for the header image.
        sections: list of (section_title, start_collapsed, [param names in order]).
        conditionals: list of (target_param, controller_param, predicate); the
            target row shows only when predicate(controller_value) is True.

    Returns:
        The dialog subclass; return it from createCustomParametersWidget().
    """
    conditionals = conditionals or []

    class _GroupedPanel(ParametersPanel):
        def initWidgets(self):
            super().initWidgets()
            # Re-lay the widgets into groups. A failure here propagates so the tool
            # falls back to the standard dialog.
            self._rows = {}
            self._regroup()

        def _regroup(self):
            scroll = self.findChild(QScrollArea)
            if scroll is None:
                raise RuntimeError("standard parameters panel has no scroll area")

            container = QWidget()
            outer = QVBoxLayout(container)
            outer.setContentsMargins(10, 10, 10, 10)
            outer.setSpacing(9)

            icon_url = QUrl.fromLocalFile(
                os.path.join(plugin_dir, "icons", icon_name)).toString()
            header = QLabel(
                '<img src="%s" width="30" height="29"/>&nbsp;&nbsp;'
                '<span style="font-size:15px; font-weight:600;">%s</span>'
                % (icon_url, title))
            header.setTextFormat(Qt.TextFormat.RichText)
            outer.addWidget(header)

            for sec_title, collapsed, names in sections:
                box = QgsCollapsibleGroupBox(sec_title)
                box.setObjectName("qglare_grp_" + sec_title.split()[0].lower())
                inner = QVBoxLayout()
                inner.setContentsMargins(9, 6, 9, 8)
                inner.setSpacing(5)
                for pname in names:
                    wrapper = self.wrappers.get(pname)
                    if wrapper is None:
                        continue
                    row = _field_row(wrapper)
                    self._rows[pname] = row
                    inner.addWidget(row)
                box.setLayout(inner)
                try:
                    box.setCollapsed(collapsed)
                except Exception as exc:
                    # cosmetic only - log and leave the box in its default state
                    QgsMessageLog.logMessage(
                        "grouped dialog: could not set collapsed state: %s" % exc,
                        "Q-GlaRe+", Qgis.MessageLevel.Info)
                outer.addWidget(box)

            outer.addStretch(1)
            scroll.setWidget(container)

            self._wire_conditionals()

        def _wire_conditionals(self):
            for target, controller, predicate in conditionals:
                ctrl = self.wrappers.get(controller)
                if ctrl is None or target not in self._rows:
                    continue

                def updater(target=target, ctrl=ctrl, predicate=predicate):
                    try:
                        visible = bool(predicate(ctrl.parameterValue()))
                    except Exception:
                        visible = True
                    self._rows[target].setVisible(visible)

                try:
                    ctrl.widgetValueHasChanged.connect(lambda *a, u=updater: u())
                except Exception as exc:
                    # if the signal is unavailable, the field just stays visible
                    QgsMessageLog.logMessage(
                        "grouped dialog: conditional signal unavailable: %s" % exc,
                        "Q-GlaRe+", Qgis.MessageLevel.Info)
                updater()  # set initial state

    class _GroupedDialog(AlgorithmDialog):
        def getParametersPanel(self, alg, parent):
            return _GroupedPanel(parent, alg)

    return _GroupedDialog
