# Q-GlaRe+

![Q-GlaRe+](qglare_icon.png)

Q-GlaRe+ is a QGIS plugin that provides tools to reconstruct palaeoglacier surface elevation and thickness, and calculate ELA of palaeo- and/or extant glaciers.

## Installation

Q-GlaRe+ is available for QGIS version 3.x. Q-GlaRe+ is written in python 3.20 and QGIS Processing Framework, as well as the libraries: _numpy_ and _pandas_. Q-GlaRe+ also integrates the GDAL library and tools from the System for Automated Geoscientific Analyses (SAGA).

1. The plugin can be installed from a ZIP file.

   - In QGIS, navigate to the Plugin manager: `Plugins > Manage and Install Plugins`
   - If installing from ZIP choose `Install from ZIP`.
   - If installing from the Plugin Repository, simply search for `Q-GlaRe+`

2. Select the ZIP file and click Install.

## Usage

1. Open Q-GlaRe+ from the QGIS toolbar.

2. Double left+click on the desired tool to use.

   - **1. 2D FL Ice Thickness**
   - **2. 2D shape-factor FL Ice Thickness**
   - **3. 2D Modified FL Ice Thickness**
   - **4. 3D Interpolation**
   - **5. Q-ELA**

3. Add input data when prompted by the QGIS processing GUI.

4. Click `Run` to begin processing.

## Dependencies

- GDAL
- SAGA GIS
- Pandas
- Numpy

## License

This plugin is licensed under the GNU General Public License v3. See [`LICENSE.txt`](./LICENSE.txt) for details.

## Author

- Brian S. Burnham
- Email: brian.burnham@abdn.ac.uk
- GitHub: [GitHub Repository](https://github.com/bsburnham)

## Citation
