"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

Name : 2D FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, math, processing
import numpy as np
import pandas as pd
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication 
from qgis.core import (QgsField,
                       QgsFields,
                       QgsProject,
                       QgsFeature,
                       QgsPointXY,
                       QgsWkbTypes,
                       QgsGeometry,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsVectorLayer,
                       QgsRasterLayer,
                       QgsSpatialIndex,
                       QgsRasterBandStats,
                       QgsProcessingException,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterBoolean,  
                       QgsProcessingParameterNumber,                    
                       QgsProcessingMultiStepFeedback,                       
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer)

class IceFlowThickness(QgsProcessingAlgorithm):
    """
    QGIS Processing Algorithm for calculating glacier ice thickness.

    This tool reconstructs glacier ice thickness along flowlines using a 
    simplified equilibrium ice surface profile model (Benn and Hulton, 2010)
    and adapted by Pellitero et al., (2015). The calculation relies on 
    user-supplied DEM data, flowlines, and basal shear stress to estimate 
    ice thickness and surface elevation at regular intervals.

    Key Features:
    - Calculates ice thickness and surface elevation along flowlines.
    - Validates results using driving stress (50–200 kPa).
    - Outputs a vector layer with calculated ice thickness and elevation.

    Inputs:
    - DEM: Raster representing glacier basal topography.
    - Flowlines: Vector file of glacier flowlines.
    - Shear Stress: Basal shear stress (default: 100,000 Pa).
    - Interval: Point spacing along flowlines (default: 10 map units).

    Output:
    - A vector point layer with ice thickness, surface elevation, and attributes.

    References:
    - Benn, D.I., Hulton, N.R.J., 2010. An Excel™ spreadsheet program for 
      reconstructing the surface profile of former mountain glaciers and ice caps. 
      Computers & Geosciences, 36, pp. 605–610.
    - Nye, J.F., 1952. The Mechanics of Glacier Flow. Journal of Glaciology, 2, pp. 82–93.
    """

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    shear_stress = 'specify_shear_stress'
    input_flowline = 'input_flowline'
    extant_glacier = 'use_glacier_polygons'
    extant_glacier_polygon = 'extant_glacier_polygons'


    def name(self):
        """
        Returns the algorithm name, used internally by QGIS.
        
        Returns:
            str: Internal name for the algorithm.
        """

        return 'Ice Flow Thickness Extant'

    def displayName(self):
        """
        Returns the user-friendly name of the algorithm.

        Returns:
            str: Display name of the algorithm.
        """

        return '1. 2D FL Ice Thickness'

    def group(self):
        """
        Returns the group name under which this algorithm is listed in QGIS.

        Returns:
            str: Group name for the algorithm.
        """

        return '\u200aQ-GlaRe'

    def groupId(self):
        """
        Returns the unique ID of the group under which this algorithm is listed.

        Returns:
            str: Group ID for the algorithm.
        """

        return '1_q-glare'
        
    def tr(self, text):
        """
        Translates the input text for localization.

        Parameters:
            text (str): Text to translate.

        Returns:
            str: Translated text.
        """

        return QCoreApplication.translate("1 Ice Flow Thickness", text)
    
    def setProgressText(self, text):
        """
        Logs progress text for debugging or feedback purposes.

        Parameters:
            text (str): Progress text to log.

        Returns:
            None
        """

        print(text)
     
    def shortHelpString(self):
        """
        Provide a short help description for the algorithm.

        Returns:
            str: A brief description of the tool and its methodology.
        """

        return self.tr(
            "A tool to reconstruct glacier ice thickness. Points are generated "
            "along a flowline at regular user-specified intervals. An ice "
            "thickness value is attributed to each point.\n\n"
            "If extant glaciers are present, this tool will estimate the associated ice thickness "
            "of given extant glacier outlines outlines. \n\n"
            "This tool is based on the equilibrium ice surface profile model developed by "
            "Nye (1952a, b) and adapted by Benn and Hulton (2010) to work with glacier "
            "basal topography and shear stress as inputs. Extant glacier thickness estimation is"
            "adapted from VOLTA model (James & Carrivick, 2016). \n\n"
            "References:\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of "
            "Glaciology 2, pp. 82–93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the "
            "Ice-Sheets. Nature 169, pp. 529–530.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program "
            "for reconstructing the surface profile of former mountain glaciers "
            "and ice caps. Computers & Geosciences 36, pp. 605–610."
            "  - James, W.H.M., Carrivick, J.L., 2016. Automated modelling "
            "of spatially-distributed glacier ice thickness and volume. "
            "Computers & Geosciences 92, 90–103.")

    def createInstance(self):
        """
        Creates and returns a new instance of the algorithm.

        Returns:
            IceFlowThickness: A new instance of the `IceFlowThickness` class.
        """
        return IceFlowThickness()
    
    def icon(self):
        """
        Returns the icon associated with this algorithm.

        Returns:
            QIcon: The icon for this algorithm.
        """
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'ice_thick.png') 

        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """
        Initializes the algorithm by defining its input parameters.
        """

        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem, 
        self.tr("\nSelect present day topography DSM/DTM raster"), 
        [QgsProcessing.TypeRaster]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_flowline, 
        self.tr("\nSelect flowline(s) (vector polyline file)"), 
        [QgsProcessing.TypeVectorLine]))
        
        self.addParameter(QgsProcessingParameterNumber(
        self.shear_stress, 
        self.tr("\nSpecify shear stress in Pascals (100,000 as default)"), 
        QgsProcessingParameterNumber.Integer, minValue=0, defaultValue=100000))

        self.addParameter(QgsProcessingParameterNumber(
        self.user_interval, 
        self.tr("\nSpecify the distance between calculated ice thickness points along the " 
                "flowline in map units. Leave blank or 0 to use input DEM resolution)"), 
        QgsProcessingParameterNumber.Integer, defaultValue=None))

        self.addParameter(QgsProcessingParameterBoolean(
        self.extant_glacier, 
        self.tr("\nEstimate extant glacier(s) ice thickness"),
        defaultValue=False,
        optional=True))

        self.addParameter(QgsProcessingParameterVectorLayer(
        self.extant_glacier_polygon, 
        self.tr("\nSelect extant glacier(s) outline (vector polygon file)"), 
        [QgsProcessing.TypeVectorPolygon],
        optional=True))
        
    def processAlgorithm(self, parameters, context, model_feedback):
        """
        Executes the algorithm and performs ice thickness reconstruction based on user inputs.
        """
        feedback = QgsProcessingMultiStepFeedback(9, model_feedback)
        results = {}

        # Pre-process and validate inputs
        dem, flowline, shear, user_interval = self.preprocess_inputs(parameters, context, feedback)

        # Log initialisation and processing start
        overall_start = time.time()
        self.log_initialization(feedback, dem, user_interval, shear, stage="start")

        # Process flowline: snap, add ID, break into points, and sample raster values
        sampled_layer = self.process_flowline(flowline, user_interval, dem, context, feedback)
        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Create temporary layer and dataframe from sampled output
        raster_sampled_layer = self.create_temp_layer_from_output(sampled_layer, "Raster Sampled Points Layer", feedback)
        flowline_points_df = self.create_dataframe(raster_sampled_layer, None, feedback, user_shear=shear)
        self.log_initialization(feedback, dem, user_interval, shear, stage="data_prep")
        self.log_processing_duration("Data processed for calculation", overall_start)

        # Spatial linking: tributary and centreline association
        prox_id_df = self.link_flowline_points(flowline_points_df, dem, user_interval, shear, feedback)

        # Estimate ice thickness and surface elevation
        reconstructed_df = self.ice_reconstruction(prox_id_df, shear)
        self.log_initialization(feedback, dem, user_interval, shear, stage="ice_calculation")

        # Validate driving stress estimates
        validated_df, valid_percentage, invalid_points = self.validate_driving_stress(reconstructed_df)
        self.log_initialization(feedback, dem, user_interval, shear, stage="validation",
                                valid_percentage=valid_percentage, invalid_points=invalid_points)

        # Process extant glacier polygons if requested
        validated_df = self.process_extant_glaciers(parameters, context, dem, validated_df, feedback)

        # Load final dataframe to QGIS
        self.load_results(validated_df, dem, context, feedback)
        self.log_initialization(feedback, dem, user_interval, shear, stage="load_qgis")
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", overall_start)

        self.log_final_results(feedback, dem.crs().authid() if dem.crs().isValid() else "Unknown CRS", overall_start)

        results = {"Status": "Complete"}
        return results
    
    def preprocess_inputs(self, parameters, context, feedback):
        """
        Retrieve and validate DEM, flowline, shear stress, and interval parameters from user inputs.

        This function:
        - Loads the DEM and flowline layers from the provided parameters.
        - Retrieves the shear stress value.
        - Determines the user-defined interval (or uses the DEM resolution if unspecified).
        - Validates that the flowline layer and DEM are valid and share the same CRS.

        Parameters:
            parameters (dict): Dictionary of parameter values passed to the algorithm.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): For logging messages and progress.

        Returns:
            tuple: (dem, flowline, shear, user_interval), where:
                - dem (QgsRasterLayer): The validated DEM layer.
                - flowline (QgsVectorLayer): The validated flowline layer.
                - shear (int): The basal shear stress value.
                - user_interval (float): The distance interval used for sampling.

        Raises:
            QgsProcessingException: If validation fails.
        """

        # Get DEM layer and CRS information
        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)

        # Retrieve flowline vector layer and shear stress
        flowline = self.parameterAsVectorLayer(parameters, self.input_flowline, context)
        shear = self.parameterAsInt(parameters, self.shear_stress, context)

        # Determine user interval, falling back to DEM resolution if needed
        user_interval = self.parameterAsInt(parameters, self.user_interval, context)
        dem_resolution = min(dem.rasterUnitsPerPixelX(), dem.rasterUnitsPerPixelY())
        if user_interval is None or user_interval == 0:
            user_interval = dem_resolution
    
        # Clean flowline - remove any empty geometries
        flowline = self.remove_empty_geometries(flowline, context)
        
        # Validate input layers
        self.validate_flowline_layer(flowline, feedback=feedback)
        self.validate_dem_input(dem)

        # Validate CRS
        flowline = self.validate_layer_crs(flowline, dem.crs(), context, feedback)
        self.validate_projected_crs(dem, feedback)

        return dem, flowline, shear, user_interval

    def process_flowline(self, flowline, user_interval, dem, context, feedback):
        """
        Run QGIS native algorithms on the flowline to generate a point layer with DEM values.

        This function:
        - Snaps geometries in the flowline layer for improved connectivity.
        - Adds an auto-incremental field ("cat") to the snapped geometry layer.
        - Breaks the flowline into equally spaced points based on the specified interval.
        - Samples the DEM at each generated point to assign an elevation value.

        Parameters:
            flowline (QgsVectorLayer): The input flowline layer.
            user_interval (float): The spacing interval for point creation.
            dem (QgsRasterLayer): The DEM layer used to sample elevation.
            context (QgsProcessingContext): QGIS processing context.
            feedback (QgsProcessingFeedback): For logging progress.

        Returns:
            QgsVectorLayer: A temporary vector layer containing points along the flowline with sampled DEM values.
        """

        outputs = {}

        # Snap geometries to ensure connectivity
        snap_params = {
            'INPUT': flowline,
            'REFERENCE_LAYER': flowline,
            'TOLERANCE': 1.0,
            'BEHAVIOR': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SnapGeometries'] = processing.run('native:snapgeometries', snap_params, context=context, feedback=None)
        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Add auto-incremental field
        autoinc_params = {
            'FIELD_NAME': 'cat',
            'GROUP_FIELDS': None,
            'INPUT': outputs['SnapGeometries']['OUTPUT'],
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AddAutoincrementalField'] = processing.run(
            'native:addautoincrementalfield', autoinc_params, context=context, feedback=None, is_child_algorithm=True
        )
        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Break the line into points
        points_params = {
            'DISTANCE': user_interval,
            'END_OFFSET': 0,
            'INPUT': outputs['AddAutoincrementalField']['OUTPUT'],
            'START_OFFSET': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BreakTheLineIntoPoints'] = processing.run(
            'native:pointsalonglines', points_params, context=context, feedback=None, is_child_algorithm=True
        )
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Sample raster values along the line
        raster_params = {
            'COLUMN_PREFIX': 'rvalue',
            'INPUT': outputs['BreakTheLineIntoPoints']['OUTPUT'],
            'RASTERCOPY': dem,
            'OUTPUT': '/vsimem/temp_raster_sampling'
        }
        outputs['RasterSampling'] = processing.run(
            'native:rastersampling', raster_params, context=context, feedback=None, is_child_algorithm=True
        )

        return outputs['RasterSampling']['OUTPUT'] 

    def link_flowline_points(self, df, dem, user_interval, shear, feedback):
        """
        Establish downstream links among flowline points by calculating a proximity-based identifier.

        This function:
        - Uses a cost function (combining horizontal distance and an elevation penalty) to compute a 'prox_id' for each point.
        - Logs the linking process and its duration.
        - Returns the DataFrame updated with the new 'prox_id' column.

        Parameters:
            df (pd.DataFrame): DataFrame of flowline points.
            dem (QgsRasterLayer): DEM used for reference (for logging only).
            user_interval (float): The spacing interval used to generate points.
            shear (int or float): The basal shear stress value.
            feedback (QgsProcessingFeedback): For logging messages and progress.

        Returns:
            pd.DataFrame: The updated DataFrame with an additional 'prox_id' column.
        """

        start_time = time.time()
        #prox_id_df = self.calculate_prox_id(df)
        prox_id_df = self.calculate_prox_id_flow_based(df)
        self.log_initialization(feedback, dem, user_interval, shear, stage="tributary_centreline")
        self.log_processing_duration("Spatially linked tributary branches and centreline", start_time)
        return prox_id_df

    def process_extant_glaciers(self, parameters, context, dem, df, feedback):
        """
        Adjust ice thickness for points within extant glacier polygons.

        This function:
        - Checks if glacier polygons should be used (via a Boolean parameter).
        - Validates and loads the glacier polygon layer.
        - Ensures the glacier polygons share the same CRS as the DEM.
        - Recalculates ice thickness for points that fall within the glacier polygon boundaries.

        Parameters:
            parameters (dict): Dictionary of parameter values.
            context (QgsProcessingContext): QGIS processing context.
            dem (QgsRasterLayer): The DEM raster used for reference.
            df (pd.DataFrame): DataFrame containing flowline or point data.
            feedback (QgsProcessingFeedback): For logging progress.

        Returns:
            pd.DataFrame: The updated DataFrame with adjusted ice thickness values for points inside glacier polygons.
        """

        use_glacier_polygons = self.parameterAsBoolean(parameters, self.extant_glacier, context)
        if use_glacier_polygons:
            glacier_polygons = self.parameterAsVectorLayer(parameters, self.extant_glacier_polygon, context)
            if not glacier_polygons:
                raise QgsProcessingException(
                    "No valid polygon layer was provided. "
                    "Please provide a valid polygon for extant glacier outlines.")
            self.validate_layer_crs(glacier_polygons, dem.crs())
            feedback.pushInfo("Processing extant glaciers...\n")
            df = self.extant_ice_thickness(df, glacier_polygons, dem)
            feedback.pushInfo("Ice thickness adjusted for extant glaciers.\n")
        return df

    def load_results(self, df, dem, context, feedback):
        """
        Load the final ice thickness results into QGIS as a memory vector layer.

        This function:
        - Converts the provided DataFrame into a memory vector layer with Point geometry.
        - Applies the DEM's CRS to the new layer.
        - Adds the new layer to the QGIS project.
        - Logs the duration of the loading process.

        Parameters:
            df (pd.DataFrame): The DataFrame containing final ice thickness results, including x/y coordinates.
            dem (QgsRasterLayer): The DEM whose CRS is applied to the new layer.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): For progress updates and logging.

        Returns:
            None
        """

        start_time = time.time()
        self.load_dataframe_to_qgis(
            df, dem.crs(), QgsProject.instance(), layer_name="2D FL Ice Thickness", feedback=feedback
        )
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", start_time)
    
    def log_initialization(self, feedback, dem, user_interval, shear, 
                           stage=None, valid_percentage=None, invalid_points=None):
        """
        Log initialization details and stage-specific messages to the QGIS feedback console.

        This function:
        - Logs the initial input parameters (DEM name, resolution, shear stress) if no stage is provided.
        - Updates progress text for specific workflow stages (e.g., 'input_processed', 'data_prep', 'tributary_centreline', etc.).
        - Optionally logs warnings when validation results fall below a specified threshold.

        Parameters:
            feedback (QgsProcessingFeedback): Object for logging messages and updating progress.
            dem (QgsRasterLayer): The DEM layer being processed.
            user_interval (float): The sampling or resolution interval in map units.
            shear (float or int): The shear stress value used in calculations.
            stage (str, optional): A keyword indicating the current workflow stage; if None, logs initial parameters.
            valid_percentage (float, optional): Percentage of valid points (used during validation).
            invalid_points (list, optional): List of point IDs with invalid results (used during validation).

        Returns:
            None
        """

        if stage is None:
            # Log initialization details
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initialising 2D FL Ice Thickness Calculation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - DEM: {dem.name()}")
            feedback.pushInfo(f"  - Resolution (map units): {user_interval:.2f}")
            feedback.pushInfo(f"  - Shear value: {shear}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText("Pre-processing input data...\n")
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "ice_calculation":
            feedback.setProgressText("Calculating ice surface and thickness...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 95:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushInfo(f"Invalid driving stress points (fid): {invalid_points}")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")
   
    def validate_flowline_layer(self, input_layer, feedback):
        """
        Validate that the flowline layer is suitable for ice thickness calculations.
        
        This function:
        - Checks the layer is valid and not empty.
        - Verifies the geometry type is LineString/MultiLineString.
        - Ensures at least one feature exists.
        - Warns about unusually short flowlines.
        
        Parameters:
            input_layer (QgsVectorLayer): The flowline layer.
            feedback (QgsProcessingFeedback): For logging warnings.
        
        Raises:
            QgsProcessingException: If validation fails.
        """
        
        # Check layer validity
        if not input_layer or not input_layer.isValid():
            raise QgsProcessingException("The input flowline layer is invalid or empty.")
        
        # Check geometry type
        if input_layer.geometryType() != QgsWkbTypes.LineGeometry:
            raise QgsProcessingException(
                "Invalid geometry type: Flowline must be a line layer.\n\n"
                "Please select a polyline/linestring layer, not points or polygons.\n"
            )
        
        # Check feature count
        if input_layer.featureCount() == 0:
            raise QgsProcessingException(
                "Empty layer: The flowline layer contains no features.\n\n"
                "Please provide a valid flowline with at least one feature.\n"
            )
        
        # Optional: Warn about very short flowlines
        min_length = 10  # Minimum reasonable length in map units
        short_count = 0
        
        for feature in input_layer.getFeatures():
            geom = feature.geometry()
            if geom and not geom.isEmpty() and geom.length() < min_length:
                short_count += 1
        
        if short_count > 0:
            feedback.pushWarning(
                f"Warning: {short_count} flowline(s) are very short (< {min_length} units).\n"
                "This may cause issues with point generation.\n"
            )

    def remove_empty_geometries(self, layer, context):
        """
        Remove features with empty or null geometries from a vector layer.

        This function:
        - Iterates through all features in the input layer.
        - Identifies features with empty or null geometries.
        - Creates a new memory layer containing only features with valid, non-empty geometries.
        - Preserves all attribute fields from the original layer.

        Parameters:
            layer (QgsVectorLayer): The input vector layer to clean.
            context (QgsProcessingContext): The QGIS processing context.

        Returns:
            QgsVectorLayer: A new memory layer containing only features with valid geometries.
        """
        
        # Filter valid geometries
        valid_features = []
        for f in layer.getFeatures():
            if f.geometry() and not f.geometry().isEmpty():
                valid_features.append(f)
        
        # Create clean layer
        clean = QgsVectorLayer(
            f"LineString?crs={layer.crs().authid()}",
            "clean_transects",
            "memory"
        )
        clean.dataProvider().addAttributes(layer.fields())
        clean.updateFields()
        clean.dataProvider().addFeatures(valid_features)
        
        return clean
    
    def validate_dem_input(self, input_raster):
        """
        Determine whether the input raster layer is a valid DEM rather than a hillshade.

        This function:
        - Checks the validity of the raster layer.
        - Scans the raster name for hillshade-related keywords.
        - Evaluates raster statistics (value range, standard deviation) to detect if the data are consistent with a DEM.

        Parameters:
            input_raster (QgsRasterLayer): The candidate DEM layer.

        Returns:
            bool: True if the raster appears to be a valid DEM; False otherwise.

        Raises:
            QgsProcessingException: If the input raster is invalid or appears to be a hillshade.
        """

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected raster layer is missing or invalid.\n\n"
                "Please ensure you have selected a valid DEM.\n"
            )

        # Check filename for "hillshade" or similar keywords
        hillshade_keywords = ["hillshade", "hillShade", "HillShade", "Hillshade", "HILLSHADE"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be a valid DEM. \n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1, QgsRasterBandStats.All)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be a valid DEM. \n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

    def validate_layer_crs(self, layer, target_crs, context, feedback):
        """
        Validate that the provided layer's CRS matches the specified target CRS, and auto-reproject if needed.

        This function:
        - Ensures the layer is valid.
        - Compares the layer's CRS to the target CRS.
        - If they don't match, automatically reprojects the layer to the target CRS.
        - Returns the layer (either original if CRS matches, or reprojected version).

        Parameters:
            layer (QgsVectorLayer or QgsRasterLayer): The layer to validate.
            target_crs (QgsCoordinateReferenceSystem): The expected CRS for all input data.
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): For logging messages.

        Returns:
            QgsVectorLayer or QgsRasterLayer: The layer with correct CRS (original or reprojected).

        Raises:
            QgsProcessingException: If the layer is invalid.
        """

        if not layer or not layer.isValid():
            raise QgsProcessingException("Invalid input layer.")
        
        layer_name = layer.name() if layer else "Unknown layer"
        
        # Check if CRS matches
        if layer.crs().authid() == target_crs.authid():
            return layer  # CRS matches, return original
        
        # CRS mismatch - auto-reproject
        feedback.pushWarning(
            f"CRS mismatch: '{layer_name}' is in {layer.crs().authid()}, "
            f"expecting {target_crs.authid()}.\n"
            f"Automatically reprojecting '{layer_name}' to {target_crs.authid()}\n"
        )
        
        # Reproject using QGIS processing
        reproject_params = {
            'INPUT': layer,
            'TARGET_CRS': target_crs,
            'OUTPUT': 'memory:'
        }
        
        result = processing.run(
            'native:reprojectlayer',
            reproject_params,
            context=context,
            feedback=None,
            is_child_algorithm=True
        )
        
        reprojected_layer = result['OUTPUT']
        feedback.pushInfo(f"Successfully reprojected '{layer_name}' to {target_crs.authid()}.\n")
        
        return reprojected_layer
        
    def validate_projected_crs(self, layer, feedback):
        """
        Validate that the provided layer uses a projected coordinate system with properly transformed coordinates.
        
        This function:
        - Checks if the layer has a valid CRS defined.
        - Checks if the layer's CRS is geographic (lat/long).
        - Checks if the actual coordinate values match the CRS type (detects incorrect reprojection).
        - Raises an exception if the CRS is invalid, undefined, geographic, or if coordinates don't match the CRS.
        
        Parameters:
            layer (QgsVectorLayer or QgsRasterLayer): The layer to validate.
            feedback (QgsProcessingFeedback): For logging messages.
        
        Returns:
            None
        
        Raises:
            QgsProcessingException: If the layer has CRS issues or coordinate mismatches.
        """
        
        if not layer or not layer.isValid():
            raise QgsProcessingException("Invalid input layer.")
        
        layer_crs = layer.crs()
        layer_name = layer.name() if layer else "Unknown layer"
        is_raster = isinstance(layer, QgsRasterLayer)
        
        # Check if CRS is defined and valid
        if not layer_crs or not layer_crs.isValid():
            reproject_instruction = "Raster -> Projections -> Warp (Reproject)" if is_raster else "Vector -> Data Management Tools -> Reproject Layer"
            raise QgsProcessingException(
                f"Missing CRS: The input layer '{layer_name}' has no coordinate reference system defined.\n\n"
                "This algorithm requires that all input data have a valid projected CRS assigned.\n\n"
                "Please assign a projected coordinate system to your layer.\n"
                f"{reproject_instruction}\n"
            )
        
        # Check if CRS is geographic (lat/long)
        if layer_crs.isGeographic():
            reproject_instruction = "Raster -> Projections -> Warp (Reproject)" if is_raster else "Vector -> Data Management Tools -> Reproject Layer"
            raise QgsProcessingException(
                f"Invalid CRS: The layer '{layer_name}' uses a geographic coordinate system ({layer_crs.authid()}).\n\n"
                "This algorithm requires projected coordinates in meters (e.g., UTM).\n"
                "Geographic coordinates (latitude/longitude in degrees) will produce incorrect results.\n\n"
                "Please reproject your data to an appropriate projected coordinate system.\n"
                f"{reproject_instruction}\n"
            )
        
        # Check if coordinates look like geographic despite CRS claiming to be projected
        extent = layer.extent()
        if (abs(extent.xMinimum()) < 360 and abs(extent.xMaximum()) < 360 and 
            abs(extent.yMinimum()) < 90 and abs(extent.yMaximum()) < 90):
            
            reproject_instruction = "Raster -> Projections -> Warp (Reproject)" if is_raster else "Vector -> Data Management Tools -> Reproject Layer"
            
            raise QgsProcessingException(
                f"CRS mismatch detected: The layer '{layer_name}' is set to projected CRS ({layer_crs.authid()}), "
                "but the coordinates appear to be in geographic format (lat/long).\n\n"
                f"Extent: X[{extent.xMinimum():.2f}, {extent.xMaximum():.2f}], "
                f"Y[{extent.yMinimum():.2f}, {extent.yMaximum():.2f}]\n\n"
                "This occurs when the CRS is assigned without transforming the coordinate values.\n\n"
                f"{reproject_instruction}\n"
            )

    def log_processing_duration(self, process_name, start_time):
        """
        Log the duration of a process to the QGIS message log.

        This function:
        - Calculates the elapsed time since the provided start time.
        - Logs a message including the process name and the duration in seconds.

        Parameters:
            process_name (str): The name of the process.
            start_time (float): The start time of the process (in seconds).

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"{process_name} completed in {duration:.4f} seconds", "2D FL Ice Thickness Processing Log", level=3)

    def log_final_results(self, feedback, crs_string, start_time):
        """
        Log the final processing results, including total runtime and CRS information, to the QGIS message log.

        This function:
        - Calculates the total duration of processing since the start time.
        - Logs final messages including the CRS identifier and runtime.
        - Updates the feedback to reflect 100% progress and a completion message.

        Parameters:
            feedback (QgsProcessingFeedback): The feedback object for progress and logging.
            crs_string (str): The CRS identifier of the processed data.
            start_time (float): The overall start time of the process (in seconds).

        Returns:
            None
        """

        duration = time.time() - start_time
        QgsMessageLog.logMessage(f"All data calculated in projection: {crs_string}", "2D FL Ice Thickness Processing Log", level=3)
        QgsMessageLog.logMessage("-----------------------------------------END PROCESS-----------------------------------------\n", 
                                "2D FL Ice Thickness Processing Log", level=0)
        feedback.pushInfo(f"All data processed in: {duration:.4f} seconds.\n")
        feedback.pushInfo(f"All data processed and projected in: {crs_string}\n")
        feedback.setProgress(100)
        feedback.setProgressText("Processing Complete!\n")

    def create_temp_layer_from_output(self, output_path, layer_name, feedback=None):
        """
        Create a temporary vector layer from a file path and add X/Y coordinate attributes.

        This function:
        - Loads the vector layer from the specified output path.
        - Adds new fields 'xcoord' and 'ycoord' to the layer.
        - Populates these fields with the corresponding geometry coordinates of each feature.

        Parameters:
            output_path (str): The file path to the vector data source.
            layer_name (str): The name to assign to the temporary layer.
            feedback (QgsProcessingFeedback, optional): Object for progress logging.

        Returns:
            QgsVectorLayer: The newly created vector layer with added X/Y coordinate fields.

        Raises:
            ValueError: If the layer cannot be created or is invalid.
        """

        # Load the layer from the output path
        temp_layer = QgsVectorLayer(output_path, layer_name, "ogr")

        if not temp_layer.isValid():
            raise ValueError(f"Failed to create layer: {layer_name} from path: {output_path}")

        # Add xcoord and ycoord fields
        temp_layer.dataProvider().addAttributes([QgsField('xcoord', QVariant.Double), QgsField('ycoord', QVariant.Double)])
        temp_layer.updateFields()  

        # Prepare bulk updates for features
        features = temp_layer.getFeatures()
        updates = {}

        for feature in features:
            geom = feature.geometry().asPoint()
            updates[feature.id()] = {'xcoord': geom.x(), 'ycoord': geom.y()}

        # Perform the bulk update
        temp_layer.dataProvider().changeAttributeValues(updates)

        return temp_layer
    
    def create_dataframe(self, temp_layer, attribute_names=None, feedback=None, user_shear=None):
        """
        Generate a Pandas DataFrame from a QGIS vector layer, optionally extracting specified attributes.

        This function:
        - Iterates over each feature in the provided layer.
        - Extracts attributes specified by 'attribute_names' (or all if None).
        - Appends the X/Y coordinates of each feature.
        - Optionally adds a 'shear_stress' column if a shear value is provided.
        
        Parameters:
            temp_layer (QgsVectorLayer): The source vector layer.
            attribute_names (list, optional): List of attribute names to extract (or all fields if None).
            feedback (QgsProcessingFeedback, optional): Object for progress reporting.
            user_shear (float, optional): A shear stress value to assign to all features.

        Returns:
            pd.DataFrame: A DataFrame with one row per feature, including the selected attributes and X/Y coordinates.
        """

        # Validate input layer
        if not isinstance(temp_layer, QgsVectorLayer):
            raise ValueError("Input must be a QgsVectorLayer.")

        data = [] 

        # Extract all fields if attribute_names is None
        if attribute_names is None:
            attribute_names = [field.name() for field in temp_layer.fields()]

        for feature in temp_layer.getFeatures():
            # Extract attributes
            row = {name: feature.attribute(name) for name in attribute_names}
            # Add geometry
            geom = feature.geometry().asPoint()
            row.update({'xcoord': geom.x(), 'ycoord': geom.y()})

            if user_shear is not None:
                row['shear_stress'] = user_shear

            data.append(row)

        # Convert to DataFrame
        return pd.DataFrame(data)
    
    def correct_distance_order(self, df):
        """
        Ensure that distance values for each flowline segment increase from smallest to largest.

        This function:
        - Resets the index of the DataFrame for unique integer indexing.
        - Groups the DataFrame by the 'cat' column representing flowline segments.
        - Checks if the 'distance' values in each group are in ascending order, and if they appear reversed,
        adjusts them accordingly.
        - Re-sorts and re-indexes the DataFrame by 'cat' and 'distance'.

        Parameters:
            df (pd.DataFrame): A DataFrame containing flowline segment data that must include columns 'cat' and 'distance'.

        Returns:
            pd.DataFrame: A corrected DataFrame where within each segment, the 'distance' values increase from smallest to largest.
        """

        # Reset index globally to ensure unique integer indices
        df = df.reset_index(drop=True)

        def fix_group(group):
            # Sort by 'distance' (in ascending order)
            group = group.sort_values('distance')
            
            if group['distance'].iloc[0] > group['distance'].iloc[-1]:
                d_min = group['distance'].min()
                d_max = group['distance'].max()
                group['distance'] = d_max + d_min - group['distance']
            return group

        # Group by 'cat' without resetting indices inside the function
        corrected_df = df.groupby('cat', group_keys=False).apply(fix_group)
        corrected_df = corrected_df.sort_values(['cat', 'distance']).reset_index(drop=True)
        
        return corrected_df
    
    def estimate_tributary_flow_direction(self, group_df):
        """
        Estimate the general flow direction of a tributary using multiple points along its flowline.

        This function:
        - Sorts the tributary points by distance to establish upstream-to-downstream order.
        - For short tributaries (< 3 points), calculates a simple start-to-end direction vector.
        - For longer tributaries, computes a weighted average of multiple flow segments for improved accuracy.
        - Normalizes the resulting vector to produce a unit direction vector.

        Parameters:
            group_df (pd.DataFrame): DataFrame containing points from a single tributary flowline with columns:
                - 'distance': Distance along the flowline.
                - 'xcoord', 'ycoord': Spatial coordinates of each point.

        Returns:
            np.ndarray: A normalized 2D unit vector representing the tributary's flow direction.
                    Returns [0, 1] as default if calculation fails.
        """

        # Sort by distance to get upstream -> downstream order
        sorted_group = group_df.sort_values('distance')
        
        if len(sorted_group) < 3:
            # Use simple start-to-end vector for short tributaries
            start = sorted_group.iloc[0]
            end = sorted_group.iloc[-1]
            flow_vector = np.array([end['xcoord'] - start['xcoord'], 
                                end['ycoord'] - start['ycoord']])
        else:
            # Use weighted average of multiple segments for better estimate
            vectors = []
            weights = []
            for i in range(len(sorted_group) - 1):
                p1 = sorted_group.iloc[i]
                p2 = sorted_group.iloc[i + 1]
                vector = np.array([p2['xcoord'] - p1['xcoord'], 
                                p2['ycoord'] - p1['ycoord']])
                distance = np.linalg.norm(vector)
                if distance > 0:
                    vectors.append(vector / distance)  # Normalize
                    weights.append(distance)
            
            if vectors:
                # Weighted average of unit vectors
                flow_vector = np.average(vectors, axis=0, weights=weights)
            else:
                return np.array([0, 1])  # Default downslope
        
        # Normalize
        norm = np.linalg.norm(flow_vector)
        return flow_vector / norm if norm > 0 else np.array([0, 1])
       
    def calculate_prox_id_flow_based(self, df):
        """
        Assign proximity-based identifiers using flow direction compatibility and glaciological constraints.

        This function:
        - Processes the main flowline first, setting the terminus point (minimum distance) to have no upstream connection.
        - For each tributary, estimates its flow direction and connects the first point to the most compatible downstream target.
        - Uses a cost function combining horizontal distance, elevation penalties, and flow direction alignment.
        - Chains subsequent tributary points to their preceding point within the same flowline segment.

        Parameters:
            df (pd.DataFrame): DataFrame containing flowline data with columns:
                - 'cat': Flowline category identifier (0 = main flowline).
                - 'distance': Distance along each flowline segment.
                - 'xcoord', 'ycoord': Spatial coordinates.
                - 'fid': Unique feature identifier.
                - 'rvalue1': DEM elevation values.

        Returns:
            pd.DataFrame: The updated DataFrame with an additional 'prox_id' column indicating downstream linkages
                        based on flow compatibility rather than simple distance-elevation ratios.
        """

        if not df.empty:
            df = self.correct_distance_order(df)

        df['prox_id'] = np.nan

        # Process main flowline first
        main_flow_cat = 0
        main_flowline = df[df['cat'] == main_flow_cat].sort_values('distance')
        if not main_flowline.empty:
            df.loc[main_flowline.index[0], 'prox_id'] = np.nan

        # Process each tributary
        for cat, group in df.groupby('cat'):
            if cat == main_flow_cat:
                continue
                
            group_sorted = group.sort_values('distance').copy()
            group_fids = group_sorted['fid'].values
            
            # Estimate flow direction for this tributary
            trib_flow_dir = self.estimate_tributary_flow_direction(group_sorted)

            for idx, (i, row) in enumerate(group_sorted.iterrows()):
                if idx == 0:
                    # Connection point: use flow compatibility
                    trib_point = np.array([row['xcoord'], row['ycoord']])
                    trib_elev = row['rvalue1']

                    # Consider all other flowlines as potential connections
                    potential_targets = df[df['cat'] != cat][['xcoord', 'ycoord', 'fid', 'rvalue1']]

                    if not potential_targets.empty:
                        candidates = potential_targets.to_numpy()
                        
                        # Calculate flow compatibility
                        flow_compatibility = self.calculate_flow_compatibility(
                            trib_point, trib_flow_dir, candidates)
                        
                        # Calculate elevation-based cost
                        elevation_cost = self.calculate_elevation_cost(
                            trib_elev, candidates[:, 3])
                        
                        # Calculate distance cost
                        distance_cost = np.sqrt((trib_point[0] - candidates[:, 0])**2 + 
                                            (trib_point[1] - candidates[:, 1])**2)
                        
                        # Combined cost prioritizing flow compatibility
                        total_cost = (distance_cost + 
                                    elevation_cost * 20 +  # Moderate elevation penalty
                                    flow_compatibility * 100)  # Strong flow penalty
                        
                        best_idx = np.argmin(total_cost)
                        df.at[row.name, 'prox_id'] = candidates[best_idx, 2]
                    else:
                        df.at[row.name, 'prox_id'] = np.nan
                else:
                    # Chain to previous point in same tributary
                    prev_fid = group_fids[idx - 1]
                    df.at[row.name, 'prox_id'] = prev_fid

        return df
    
    def calculate_flow_compatibility(self, trib_point, trib_flow_dir, candidates):
        """
        Calculate flow direction compatibility between a tributary point and potential connection targets.

        This function:
        - Computes unit vectors from the tributary point to each candidate connection point.
        - Calculates dot products between the tributary flow direction and connection vectors.
        - Converts alignment scores to cost values where lower costs indicate better flow compatibility.

        Parameters:
            trib_point (np.ndarray): 2D coordinates [x, y] of the tributary connection point.
            trib_flow_dir (np.ndarray): Normalized 2D unit vector representing tributary flow direction.
            candidates (np.ndarray): Array of candidate points with shape (n, 4) containing [x, y, fid, elevation].

        Returns:
            np.ndarray: Array of flow compatibility costs where 0 = perfect alignment, 2 = opposite direction.
                    Lower values indicate better glaciological flow compatibility.
        """
        # Vectors from tributary point to each candidate
        connection_vectors = candidates[:, :2] - trib_point
        distances = np.linalg.norm(connection_vectors, axis=1)
        
        # Avoid division by zero
        valid_mask = distances > 1e-6
        connection_vectors[valid_mask] /= distances[valid_mask, np.newaxis]
        
        # Dot product: 1 = same direction, -1 = opposite, 0 = perpendicular
        dot_products = np.dot(connection_vectors, trib_flow_dir)
        
        # Convert to cost: 0 = perfect alignment, 2 = opposite direction
        flow_cost = 1 - dot_products
        
        return flow_cost
    
    def calculate_elevation_cost(self, trib_elev, candidate_elevs):
        """
        Calculate elevation-based connection costs with glaciologically realistic penalties.

        This function:
        - Heavily penalizes uphill connections (ice cannot flow uphill).
        - Applies minimal penalties for downhill connections to allow natural glacier flow.
        - Uses asymmetric weighting to reflect physical constraints of ice flow dynamics.

        Parameters:
            trib_elev (float): Elevation of the tributary connection point.
            candidate_elevs (np.ndarray): Array of elevation values for potential connection targets.

        Returns:
            np.ndarray: Array of elevation-based costs where uphill connections receive 2x penalty
                    and extreme downhill connections receive 0.1x penalty.
        """
        elev_diff = candidate_elevs - trib_elev
        
        # Heavily penalize uphill connections, moderately penalize extreme downhill
        uphill_penalty = np.maximum(0, elev_diff) * 2  # 2x penalty for uphill
        downhill_penalty = np.maximum(0, -elev_diff) * 0.1  # Small penalty for downhill
        
        return uphill_penalty + downhill_penalty
        
    def ice_reconstruction(self, df, shear=None):
        """
        Compute ice thickness and reconstruct the ice surface for flowlines using a quadratic model.

        This function:
        - Processes the main flowline (points with no 'prox_id') sequentially to compute the ice surface.
        - Processes tributaries by inheriting the ice surface from a downstream confluence.
        - Calculates ice thickness as the difference between the reconstructed ice surface and the DEM value ('rvalue1'),
        ensuring that no negative thickness values are produced.
        
        Parameters:
            df (pd.DataFrame): DataFrame containing flowline data with columns: 'cat', 'xcoord', 'ycoord', 'rvalue1', 'prox_id', 'fid', 'shear_stress'.
            shear (float, optional): The constant basal shear stress value; if None, each point's 'shear_stress' is used.

        Returns:
            pd.DataFrame: The updated DataFrame with new columns 'ice_surface' and 'ice_thickness'.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81   # Gravitational acceleration (m/s2)

        # helper function to compute the next ice surface using the quadratic model.
        def compute_next_surface(prev_surface, r_prev, r_curr, d, local_shear):
            """
            Compute the next ice surface value using the quadratic model.
            """

            b = -(r_prev + r_curr)
            c = prev_surface * (r_curr - (prev_surface - r_prev)) - (2 * d * local_shear) / (rho * g)
            disc = b**2 - 4 * c
            if disc >= 0:
                return (-b + np.sqrt(disc)) / 2
            else:
                return r_curr

        # helper function to process a single flowline segment.
        def process_flowline_segment(segment_df, initial_surface=None):
            """
            Process a sorted flowline segment (main or tributary) to compute reconstructed ice surface values.

            This function:
            - Sorts the input DataFrame to replicate the original ordering.
            - Uses an optionally provided initial surface value, or defaults to the first point's DEM value ('rvalue1').
            - Iterates sequentially over the segment and computes the ice surface for each point using a quadratic model.
            - Uses the preceding computed ice surface value and the current point’s data (e.g., distance and shear stress) to calculate a new ice surface value via an external function (compute_next_surface).
            - Returns a mapping of each point's 'fid' to its computed ice surface value.

            Parameters:
                segment_df (pd.DataFrame): DataFrame representing a single flowline segment. It must include at least the columns:
                    - 'fid': Unique feature identifier.
                    - 'xcoord', 'ycoord': Spatial coordinates.
                    - 'rvalue1': DEM value used as a reference for the ice surface.
                    - 'shear_stress': Shear stress value for each point.
                initial_surface (float, optional): The initial ice surface elevation to assign to the first point.
                    If not provided, the first point's 'rvalue1' is used.

            Returns:
                dict: A dictionary mapping feature IDs (int) to the computed ice surface elevation (float) for the segment.
            """

            surface_map = {}
            seg = segment_df.sort_index().reset_index(drop=True)
            first = seg.iloc[0]
            init_surf = initial_surface if initial_surface is not None else first['rvalue1']
            surface_map[first['fid']] = init_surf
            prev_surface = init_surf
            # Process remaining points sequentially.
            for i in range(1, len(seg)):
                curr = seg.iloc[i]
                prev = seg.iloc[i - 1]
                dx = curr['xcoord'] - prev['xcoord']
                dy = curr['ycoord'] - prev['ycoord']
                d = np.sqrt(dx**2 + dy**2)
                local_shear = shear if shear is not None else curr['shear_stress']
                new_surface = compute_next_surface(prev_surface, prev['rvalue1'], curr['rvalue1'], d, local_shear)
                surface_map[curr['fid']] = new_surface
                prev_surface = new_surface
            return surface_map

        surface_dict = {}

        # Process main flowline
        main_mask = df['prox_id'].isna()
        main_flowline = df[main_mask].copy()
        if not main_flowline.empty:
            main_surfaces = process_flowline_segment(main_flowline)
            surface_dict.update(main_surfaces)

        # Process tributaries
        tributaries = df[~main_mask].copy()
        for cat, group in tributaries.groupby('cat'):
            group = group.copy().reset_index(drop=True)
            # The first point in the tributary (confluence) should inherit its ice surface from its
            # downstream connection via prox_id. If that is not available, use its own DEM value.
            confluence = group.iloc[0]
            prox_id = confluence['prox_id']
            if prox_id in surface_dict:
                init_surface = surface_dict[prox_id]
            else:
                init_surface = confluence['rvalue1']
            trib_surfaces = process_flowline_segment(group, initial_surface=init_surface)
            surface_dict.update(trib_surfaces)

        # Map the computed surfaces back to the DataFrame.
        df['ice_surface'] = df['fid'].map(surface_dict)
        df['ice_thickness'] = np.maximum(df['ice_surface'] - df['rvalue1'], 0)
        
        # Locate and replace zero ice thickness values using nearest neighbor approach
        df = self.replace_zero_thickness_with_nearest_neighbor(df)

        # Ensure terminus has zero thickness
        main_flow_cat = 0
        main_flowline = df[df['cat'] == main_flow_cat]

        if not main_flowline.empty:
            # Find terminus (minimum distance point on main flowline)
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            terminus_idx = terminus_row.name  # Get the DataFrame index
            
            # Force terminus to zero thickness
            df.at[terminus_idx, 'ice_thickness'] = 0
            df.at[terminus_idx, 'ice_surface'] = df.at[terminus_idx, 'rvalue1']
        
        return df
        
    def replace_zero_thickness_with_nearest_neighbor(self, df):
        """
        Replace zero ice thickness values using prox_id mapping and nearest neighbor search,
        but preserve zero thickness only at the true glacier terminus (end of main flowline).
        
        This function:
        - Identifies points with zero ice thickness.
        - Replaces zero values first by checking the thickness of the point referenced by 'prox_id'.
        - For any remaining zeros, performs a vectorized nearest neighbor search among points with non-zero thickness.
        - Preserves zero thickness at the true glacier terminus (minimum distance point on main flowline).
    
        Parameters:
            df (pd.DataFrame): DataFrame that includes 'fid', 'prox_id', 'ice_thickness', 'xcoord', and 'ycoord'.
        Returns:
            pd.DataFrame: The DataFrame with zero ice thickness values replaced by valid thickness values.
        """
        
        # Find the true terminus - point with minimum distance on main flowline
        main_flow_cat = 0
        main_flowline = df[df['cat'] == main_flow_cat]
        
        if not main_flowline.empty:
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            true_terminus_fid = terminus_row['fid']
        else:
            true_terminus_fid = None

        # Only replace zeros that are NOT at the true terminus
        if true_terminus_fid is not None:
            zero_mask = (df['ice_thickness'] == 0) & (df['fid'] != true_terminus_fid)
        else:
            zero_mask = (df['ice_thickness'] == 0)
            
        if not zero_mask.any():
            return df  # Nothing to replace.
            
        # Split the DataFrame into zero and non-zero thickness points.
        df_zero = df[zero_mask].copy()
        df_nonzero = df[df['ice_thickness'] != 0].copy()
        
        # Replace using prox_id if available.
        thickness_map = df.set_index('fid')['ice_thickness']
        df_zero['prox_thickness'] = df_zero['prox_id'].map(thickness_map)
        valid_prox = df_zero['prox_thickness'].notna() & (df_zero['prox_thickness'] > 0)
        df_zero.loc[valid_prox, 'ice_thickness'] = df_zero.loc[valid_prox, 'prox_thickness']
        
        # For remaining zeros, use vectorized nearest neighbor search.
        still_zero = (df_zero['ice_thickness'] == 0)
        if still_zero.any():
            zero_coords = df_zero.loc[still_zero, ['xcoord', 'ycoord']].to_numpy()
            nonzero_coords = df_nonzero[['xcoord', 'ycoord']].to_numpy()
            nonzero_thickness = df_nonzero['ice_thickness'].to_numpy()
        
            # Compute pairwise Euclidean distances.
            diff = zero_coords[:, np.newaxis, :] - nonzero_coords[np.newaxis, :, :]
            dists = np.sqrt(np.sum(diff**2, axis=2))
            nearest_idx = np.argmin(dists, axis=1)
            df_zero.loc[still_zero, 'ice_thickness'] = nonzero_thickness[nearest_idx]
            
        df_zero.drop(columns=['prox_thickness'], inplace=True)
        df.update(df_zero[['ice_thickness']])
    
        return df
    
    def validate_driving_stress(self, df):
        """
        Validate computed ice thickness values by calculating driving stress.

        This function:
        - Estimates the local surface slope using differences in 'xcoord', 'ycoord', and 'ice_surface'.
        - Computes driving stress using the formula: rho * g * ice_thickness * sin(slope).
        - Flags points as valid if their driving stress is between 50 kPa and 200 kPa.
        - Returns the updated DataFrame (with temporary columns removed), the percentage of valid points, and the list of invalid point IDs.
        
        Parameters:
            df (pd.DataFrame): DataFrame containing 'ice_thickness', 'xcoord', 'ycoord', 'ice_surface', and 'fid'.

        Returns:
            tuple: A tuple containing:
                - (pd.DataFrame): The updated DataFrame.
                - (float): The percentage of points with valid driving stress.
                - (list): A list of point IDs (fid) for which driving stress is invalid.
        """

        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Calculate surface slope (vectorized)
        dx = df['xcoord'].diff().fillna(0)  
        dy = df['ycoord'].diff().fillna(0)  
        dz = df['ice_surface'].diff().fillna(0)
        d = np.sqrt(dx**2 + dy**2 + 1e-6)  
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate driving stress
        driving_stress = rho * g * df['ice_thickness'] * np.sin(surface_slope)

        # Validate driving stress
        df['stress_valid'] = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        invalid_points = df.loc[~df['stress_valid'], 'fid'].tolist()  
        valid_points = df['stress_valid'].sum()
        total_points = len(df)
        valid_percentage = (valid_points / total_points) * 100

        # Clean up temporary columns
        df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')

        return df, valid_percentage, invalid_points


    def extant_ice_thickness(self, df, glacier_polygons, dem):
        """
        Recalculate ice thickness for points inside extant glacier polygons using DEM-derived slope and a shear stress–based formula.

        This function:
        - Uses a spatial index to identify which points in the DataFrame fall inside glacier polygons.
        - Computes a slope raster from the DEM.
        - Samples the DEM-derived slope for points inside the glacier polygons.
        - Computes ice thickness at those points using a VOLTA equation based on the input shear stress.
        - Computes bedrock elevation as the difference between DEM elevation ('rvalue1') and the calculated ice thickness.
        - Updates the input DataFrame with new columns for 'ice_thickness' and 'bedrock_elevation' ensuring numerical consistency.

        Parameters:
            df (pd.DataFrame): A DataFrame with columns including 'fid', 'xcoord', 'ycoord', 'rvalue1', 'shear_stress', and 'ice_thickness'.
            glacier_polygons (QgsVectorLayer): A polygon layer representing the extant glacier boundaries.
            dem (QgsRasterLayer): The DEM raster layer used for calculating slopes.

        Returns:
            pd.DataFrame: The updated DataFrame with recalculated 'ice_thickness' and 'bedrock_elevation' for points inside glacier polygons.

        Raises:
            QgsProcessingException: If the DEM is invalid or if any required data are missing.
        """

        # Constants
        rho = 910  # Ice density (kg/m^3)
        g = 9.81  # Gravitational acceleration (m/s^2)
        min_slope_degrees = 4  # Minimum slope threshold (in degrees)

        # Compute slope from input DEM 
        slope_raster_path = "/vsimem/slope.tif"
        processing.run("qgis:slope", {
            'INPUT': dem,
            'Z_FACTOR': 1.0,
            'OUTPUT': slope_raster_path
        })
        slope_raster = QgsRasterLayer(slope_raster_path, "Slope Raster")

        # Build a Spatial Index for polygon containment check
        spatial_index = QgsSpatialIndex()
        poly_dict = {}  
        for polygon in glacier_polygons.getFeatures():
            poly_id = polygon.id()
            poly_dict[poly_id] = polygon.geometry()
            spatial_index.addFeature(polygon)

        # Convert DataFrame to QGIS points
        df["point_geom"] = df.apply(lambda row: QgsGeometry.fromPointXY(QgsPointXY(row["xcoord"], row["ycoord"])), axis=1)

        # Find points inside any defined glacier
        inside_glacier_mask = np.array([
            any(poly_dict[poly_id].contains(row["point_geom"])
                for poly_id in spatial_index.intersects(row["point_geom"].boundingBox()))
            for _, row in df.iterrows()])
        
        # Only process points inside glaciers
        inside_df = df[inside_glacier_mask].copy()

        # Extract slope values of point locations
        inside_df["slope"] = inside_df["point_geom"].apply(
            lambda p: max(slope_raster.dataProvider().sample(p.asPoint(), 1)[0], min_slope_degrees))

        # Compute ice thickness using VOLTA equation 
        slope_radians = np.radians(inside_df["slope"])
        pgtan_alpha = rho * g * np.tan(slope_radians)

        inside_df["ice_thickness"] = np.clip(inside_df["shear_stress"] 
                                             / pgtan_alpha, 0, inside_df["rvalue1"])
        
        # Initialize `bedrock_elevation` for all points 
        if "bedrock_elevation" not in df.columns:
            df["bedrock_elevation"] = np.nan  
        
        # Compute bedrock elevation
        inside_df["bedrock_elevation"] = inside_df["rvalue1"] - inside_df["ice_thickness"]

        # Merge processed data back into DataFrame
        df.update(inside_df[["ice_thickness", "bedrock_elevation"]])

        # Ensure `bedrock_elevation` is numeric and non-null 
        df["bedrock_elevation"] = pd.to_numeric(df["bedrock_elevation"], errors="coerce").fillna(df["rvalue1"])

        # Remove temporary geometry column
        df.drop(columns=["point_geom"])

        return df

    def load_dataframe_to_qgis(self, dataframe, crs, project_instance, layer_name='DataFrameLayer', feedback=None):
        """
        Convert a Pandas DataFrame into a QGIS memory vector layer with point geometry.

        This function:
        - Converts numeric columns in the DataFrame as needed.
        - Creates attribute fields (QgsFields) corresponding to the DataFrame columns.
        - Creates a memory vector layer with Point geometry using the provided CRS, based on 'xcoord' and 'ycoord' values.
        - Inserts each row of the DataFrame as a feature in the new layer.
        - Adds the memory layer to the current QGIS project.

        Parameters:
            dataframe (pd.DataFrame): The DataFrame to load; must include 'xcoord' and 'ycoord' columns.
            crs (QgsCoordinateReferenceSystem): The CRS to be applied to the new layer.
            project_instance (QgsProject): The current QGIS project.
            layer_name (str, optional): The name for the created memory layer (default is 'DataFrameLayer').
            feedback (QgsProcessingFeedback, optional): For progress reporting.

        Returns:
            None
        """

        # Preprocess DataFrame: Ensure all numeric columns are properly converted
        for column in dataframe.columns:
            if dataframe[column].dtype == 'object':  # If it's an object (string), try converting
                dataframe[column] = pd.to_numeric(dataframe[column], errors='coerce')

        # Create a QgsFields object to define the attribute fields
        fields = QgsFields()
        for column in dataframe.columns:
            field = QgsField(column, QVariant.Double)
            fields.append(field)

        # Create a memory vector layer
        vector_layer = QgsVectorLayer('Point?crs={}'.format(crs.authid()), layer_name, 'memory')
        vector_layer.dataProvider().addAttributes(fields)
        vector_layer.updateFields()
        
        # Add features to the memory vector layer
        features = []
        total_features = len(dataframe)
        current_feature = 0

        # Iterate over each row in the DataFrame
        for row in dataframe.itertuples(index=False):
            feature = QgsFeature(fields)
            x_coord = float(row.xcoord)
            y_coord = float(row.ycoord)
            geometry = QgsGeometry.fromPointXY(QgsPointXY(x_coord, y_coord))
            feature.setGeometry(geometry)

            # Set attributes for each field
            for column in dataframe.columns:
                value = getattr(row, column)                
                value = float(value) if isinstance(value, (int, float, str)) else None
                feature.setAttribute(column, value)

            features.append(feature)

            # Update progress
            current_feature += 1
            progress_percentage = int(current_feature / total_features * 100)
            if feedback:
                feedback.setProgress(progress_percentage)

            # Check for user cancellation
            if feedback and feedback.isCanceled():
                break

        vector_layer.dataProvider().addFeatures(features)

        # Add the memory vector layer to the map
        QgsProject.instance().addMapLayer(vector_layer)

    def postProcessAlgorithm(self, context, feedback):
        """
        Display a completion message after processing and perform any necessary post-processing tasks.

        This function:
        - Creates and displays a QMessageBox with a completion message.
        - Sets the processing progress to 100% and updates the progress text.
        - Returns a dictionary indicating the status of post-processing.

        Parameters:
            context (QgsProcessingContext): The QGIS processing context.
            feedback (QgsProcessingFeedback): The feedback object for progress updates.

        Returns:
            dict: A dictionary reflecting the post-processing completion status.
        """

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("2D FL Ice Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec_()
        
        return super().postProcessAlgorithm(context, feedback)
    

