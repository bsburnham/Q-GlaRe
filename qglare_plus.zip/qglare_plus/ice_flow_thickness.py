"""
/*****************************************************************************
*                                                                            *
*   This file is part of QGlaRe+.                                            *
*                                                                            *
*   QGlaRe+ is free software:                                                *
*   you can redistribute it and/or modify it under the terms of the          *
*   GNU General Public License as published by the Free Software Foundation, *
*   either version 3 of the License, or (at your option) any later version.  *
*                                                                            *
*   QGlaRe+ is distributed in the hope that it will be useful,               *
*   but WITHOUT ANY WARRANTY; without even the implied warranty              *
*   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
*   See the GNU General Public License for more details.                     *
*                                                                            *
*   You should have received a copy of the GNU General Public License        *
*   along with QGlaRe+. If not, see <https://www.gnu.org/licenses/>.         *
*                                                                            *
*****************************************************************************/

ice_flow_thickness  —  2D flowline ice-thickness tool
=====================================================

Name : 2D FL Ice Thickness
Group : QGlaRe+
"""

__authors__ = 'Brian S. Burnham and Alexis Kaselouris'
__date__ = '2025-05-29'

import os, time, math, traceback, processing
from .qglare_base import QGlaReAlgorithmMixin
import numpy as np
import pandas as pd
from qgis.PyQt.QtCore import QVariant, QMetaType, QUrl
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication 
from qgis.core import (Qgis,
                       QgsField,
                       QgsFields,
                       QgsProject,
                       QgsFeature,
                       QgsPointXY,
                       QgsWkbTypes,
                       QgsGeometry,
                       QgsMessageLog,
                       QgsProcessing,
                       QgsVectorLayer,
                       QgsRasterLayer,
                       QgsSpatialIndex,
                       QgsProcessingException,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterBoolean,
                       QgsProcessingParameterNumber,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterVectorLayer,
                       QgsProcessingUtils)

# QGIS version compatibility: GeometryType moved to Qgis enum in 3.30
try:
    _LINE_GEOMETRY = Qgis.GeometryType.Line
except AttributeError:                          # QGIS < 3.30
    _LINE_GEOMETRY = QgsWkbTypes.GeometryType.LineGeometry

# QGIS version compatibility: QgsField(name, QVariant.Type) deprecated in 3.38 -
# QMetaType.Type is the replacement (QVariant.Type is removed in Qt6 / QGIS 4).
_FIELD_DOUBLE = QMetaType.Type.Double if Qgis.QGIS_VERSION_INT >= 33800 else QVariant.Double

# QGIS version compatibility: ProcessingSourceType moved to Qgis enum in 3.36
try:
    _SOURCE_RASTER = Qgis.ProcessingSourceType.Raster
    _SOURCE_VECTOR_LINE = Qgis.ProcessingSourceType.VectorLine
    _SOURCE_VECTOR_POLYGON = Qgis.ProcessingSourceType.VectorPolygon
except AttributeError:                          # QGIS < 3.36
    _SOURCE_RASTER = QgsProcessing.SourceType.TypeRaster
    _SOURCE_VECTOR_LINE = QgsProcessing.SourceType.TypeVectorLine
    _SOURCE_VECTOR_POLYGON = QgsProcessing.SourceType.TypeVectorPolygon

class IceFlowThickness(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
    """Reconstruct glacier ice thickness along flowlines.

    Marches an equilibrium ice-surface profile (Nye 1952; Benn and Hulton 2010,
    adapted by Pellitero et al. 2015) up each flowline from the terminus, taking
    bed elevation from the DEM and a user-supplied basal shear stress. Extant
    glacier thickness is estimated from the VOLTA relation (James and Carrivick
    2016).

    References:
        Nye, J.F., 1952. The mechanics of glacier flow. Journal of Glaciology
            2, 82–93.
        Benn, D.I., Hulton, N.R.J., 2010. An Excel spreadsheet program for
            reconstructing the surface profile of former mountain glaciers and
            ice caps. Computers & Geosciences 36, 605–610.
        James, W.H.M., Carrivick, J.L., 2016. Automated modelling of
            spatially-distributed glacier ice thickness and volume. Computers &
            Geosciences 92, 90–103.
    """

    N_STEPS = 9
    _log_tag = '2D FL Ice Thickness Processing Log'

    user_interval = 'user_interval'
    input_dem = 'InputDEM'
    shear_stress = 'specify_shear_stress'
    input_flowline = 'input_flowline'
    extant_glacier = 'use_glacier_polygons'
    extant_glacier_polygon = 'extant_glacier_polygons'


    def name(self):
        """Internal algorithm id used by QGIS."""

        return 'Ice Flow Thickness Extant'

    def displayName(self):
        """Name shown in the QGIS toolbox."""

        return '1. 2D FL Ice Thickness'

    def group(self):
        """Toolbox group this algorithm sits under."""

        return '\u200aQ-GlaRe'

    def groupId(self):
        """Unique id of the toolbox group."""

        return '1_q-glare'
        
    def tr(self, text):
        """Translate a string through Qt's localisation."""

        return QCoreApplication.translate("1 Ice Flow Thickness", text)
    
    def setProgressText(self, text):
        """Print progress text when running outside the QGIS console."""

        print(text)
     
    def shortHelpString(self):
        """Help-panel text for the toolbox, with the tool icon as an HTML header."""

        # Add the tool icon to the top of the help text (rendered as HTML).
        icon_url = QUrl.fromLocalFile(
            os.path.join(os.path.dirname(__file__), 'icons', 'ice_thick.png')).toString()
        header = ('<img src="%s" width="28" height="27"/>&nbsp;&nbsp;'
                  '<b>Ice flow thickness</b>\n\n' % icon_url)

        return header + self.tr(
            "A tool to reconstruct glacier ice thickness. Points are generated "
            "along a flowline at regular user-specified intervals. An ice "
            "thickness value is attributed to each point.\n\n"
            "If extant glaciers are present, this tool will estimate the associated ice thickness "
            "of given extant glacier outlines. \n\n"
            "This tool is based on the equilibrium ice surface profile model developed by "
            "Nye (1952a, b) and adapted by Benn and Hulton (2010) to work with glacier "
            "basal topography and shear stress as inputs. Extant glacier thickness estimation is "
            "adapted from VOLTA model (James & Carrivick, 2016). \n\n"
            "A vector point file is created from the specified input data. \n\n"
            "<b>References:</b>\n"
            "  - Nye, J.F., 1952a. The Mechanics of Glacier Flow. Journal of "
            "Glaciology 2, pp. 82-93.\n"
            "  - Nye, J.F., 1952b. A Method of Calculating the Thicknesses of the "
            "Ice-Sheets. Nature 169, pp. 529-530.\n"
            "  - Benn, D.I., Hulton, N.R.J., 2010. An ExcelTM spreadsheet program "
            "for reconstructing the surface profile of former mountain glaciers "
            "and ice caps. Computers & Geosciences 36, pp. 605-610."
            "  - James, W.H.M., Carrivick, J.L., 2016. Automated modelling "
            "of spatially-distributed glacier ice thickness and volume. "
            "Computers & Geosciences 92, 90-103.")

    def createInstance(self):
        """Return a fresh instance for QGIS to run."""
        return IceFlowThickness()

    def createCustomParametersWidget(self, parent=None):
        """
        Build the tool dialog with the icon at the top and the inputs grouped into
        collapsible sections. Falls back to the standard dialog if it cannot be built.
        """
        try:
            from .grouped_dialog import build_grouped_dialog, truthy
            DialogCls = build_grouped_dialog(
                os.path.dirname(__file__), "ice_thick.png", "Ice flow thickness",
                sections=[
                    ("Inputs", False, [
                        "InputDEM", "input_flowline", "specify_shear_stress",
                        "user_interval", "use_glacier_polygons", "extant_glacier_polygons"]),
                ],
                conditionals=[
                    ("extant_glacier_polygons", "use_glacier_polygons", truthy),
                ])
            return DialogCls(self, parent=parent)
        except Exception:
            return None
    
    def icon(self):
        """Toolbox icon for this algorithm."""
        icons_path = os.path.join(os.path.dirname(__file__), 'icons')
        icon_file = os.path.join(icons_path, 'ice_thick.png') 

        return QIcon(icon_file)

    def initAlgorithm(self, config=None):
        """Define the input parameters: DEM, flowline, shear stress, interval, extant outlines."""

        self.addParameter(QgsProcessingParameterRasterLayer(
        self.input_dem, 
        self.tr("\nSelect present day topography DSM/DTM raster"), 
        [_SOURCE_RASTER]))
        
        self.addParameter(QgsProcessingParameterVectorLayer(
        self.input_flowline, 
        self.tr("\nSelect flowline(s) (vector polyline file)"), 
        [_SOURCE_VECTOR_LINE]))
        
        self.addParameter(QgsProcessingParameterNumber(
        self.shear_stress, 
        self.tr("\nSpecify shear stress in Pascals (100,000 as default)"), 
        QgsProcessingParameterNumber.Type.Integer, minValue=0, defaultValue=100000))

        self.addParameter(QgsProcessingParameterNumber(
        self.user_interval, 
        self.tr("\nSpecify the distance between calculated ice thickness points along the " 
                "flowline in map units. Leave blank or 0 to use input DEM resolution)"), 
        QgsProcessingParameterNumber.Type.Integer, defaultValue=None))

        self.addParameter(QgsProcessingParameterBoolean(
        self.extant_glacier, 
        self.tr("\nEstimate extant glacier(s) ice thickness"),
        defaultValue=False,
        optional=True))

        self.addParameter(QgsProcessingParameterVectorLayer(
        self.extant_glacier_polygon, 
        self.tr("\nSelect extant glacier(s) outline (vector polygon file)"), 
        [_SOURCE_VECTOR_POLYGON],
        optional=True))
        
    def processAlgorithm(self, parameters, context, model_feedback):
        """Run the reconstruction: sample the flowline, march the ice surface, validate driving stress, load the points."""
        feedback = QgsProcessingMultiStepFeedback(self.N_STEPS, model_feedback)

        try:
            self._init_logger('ice_flow_thickness', feedback)

            # Pre-process and validate inputs
            dem, flowline, shear, user_interval = self.preprocess_inputs(parameters, context, feedback)

            # Check extant glacier polygon early, before heavy processing begins
            use_glacier_polygons = self.parameterAsBoolean(parameters, self.extant_glacier, context)
            if use_glacier_polygons:
                glacier_polygons = self.parameterAsVectorLayer(parameters, self.extant_glacier_polygon, context)
                if glacier_polygons is None or not glacier_polygons.isValid():
                    raise QgsProcessingException(
                        "Extant glacier outlines layer is required but could not be retrieved or is not valid. "
                        "Please select a valid polygon layer before running."
                    )

            # Log initialisation and processing start
            overall_start = time.time()
            self.log_initialization(feedback, dem, user_interval, shear, flowline=flowline)
            self._log_run_header({
                'DEM':                   f"{dem.name()} ({dem.source()})",
                'Flowline':               flowline.name(),
                'Shear Stress (kPa)':     shear,
                'Resolution (map units)': f"{user_interval:.1f}",
                'CRS':                    dem.crs().authid() if dem.crs().isValid() else 'Unknown CRS',
            })
            self._log_layer_crs([
                ('DEM',      dem),
                ('Flowline', flowline),
            ])

            # Process flowline: snap, add ID, break into points, and sample raster values
            sampled_layer = self.process_flowline(flowline, user_interval, dem, context, feedback)
            feedback.setCurrentStep(4)
            if feedback.isCanceled():
                return {}

            # Create temporary layer and dataframe from sampled output
            raster_sampled_layer = self.create_temp_layer_from_output(sampled_layer, "Raster Sampled Points Layer", feedback)
            flowline_points_df = self.create_dataframe(raster_sampled_layer, None, feedback, user_shear=shear, include_geometry=True)
            self.log_initialization(feedback, dem, user_interval, shear, stage="data_prep")
            self.log_processing_duration("Data processed for calculation", overall_start)

            # Spatial linking: tributary and centreline association
            prox_id_df = self.link_flowline_points(flowline_points_df, dem, user_interval, shear, feedback)

            # Estimate ice thickness and surface elevation
            reconstructed_df = self.ice_reconstruction(prox_id_df, shear, feedback=feedback)
            self.log_initialization(feedback, dem, user_interval, shear, stage="ice_calculation")

            # Validate driving stress estimates
            validated_df, valid_percentage, invalid_points = self.validate_driving_stress(reconstructed_df)
            self.log_initialization(feedback, dem, user_interval, shear, stage="validation",
                                    valid_percentage=valid_percentage, invalid_points=invalid_points)

            # Process extant glacier polygons if requested
            validated_df = self.process_extant_glaciers(parameters, context, dem, validated_df, feedback)

            # Load final dataframe to QGIS
            self.load_results(validated_df, dem, context, feedback)
            self.log_initialization(feedback, dem, user_interval, shear, stage="load_qgis")
            self.log_processing_duration("Ice flow thickness points loaded into QGIS", overall_start)

            self.log_final_results(feedback, dem.crs().authid() if dem.crs().isValid() else "Unknown CRS", overall_start)
            self._log_success(feedback)
            return {"Status": "Complete"}

        except QgsProcessingException:
            raise
        except Exception:
            self._log(traceback.format_exc(), level='error')
            raise QgsProcessingException(
                "An error occurred. See log file"
                + (f": {self._log_path}" if self._log_path else ".")
            )
    
    def preprocess_inputs(self, parameters, context, feedback):
        """Read and validate the DEM, flowline, shear stress and interval.

        Falls back to the DEM resolution when no interval is given, reprojects
        the flowline to the DEM CRS, and checks the DEM is projected (metres,
        not degrees).
        """

        # Get DEM layer and CRS information
        dem = self.parameterAsRasterLayer(parameters, self.input_dem, context)
        if dem is None or not dem.isValid():
            raise QgsProcessingException(
                "The input DEM layer could not be retrieved or is not valid. "
                "Please select a valid raster layer."
            )

        # Retrieve flowline vector layer and shear stress
        flowline = self.parameterAsVectorLayer(parameters, self.input_flowline, context)
        if flowline is None or not flowline.isValid():
            raise QgsProcessingException(
                "The input flowline layer could not be retrieved or is not valid. "
                "Please select a valid vector layer."
            )
        shear = self.parameterAsInt(parameters, self.shear_stress, context)

        # Determine user interval, falling back to DEM resolution if needed
        user_interval = self.parameterAsInt(parameters, self.user_interval, context)
        dem_resolution = min(dem.rasterUnitsPerPixelX(), dem.rasterUnitsPerPixelY())
        if user_interval is None or user_interval == 0:
            user_interval = dem_resolution
    
        # Clean flowline - remove any empty geometries
        flowline = self.remove_empty_geometries(flowline, context)

        # Validate CRS first so that subsequent checks (e.g. flowline length) use
        # projected metres rather than the original units (which may be degrees).
        flowline = self.validate_layer_crs(flowline, dem.crs(), context, feedback)
        self.validate_projected_crs(dem, feedback)

        # Validate input layers (after reprojection so lengths are in map units)
        self.validate_flowline_layer(flowline, feedback=feedback)
        self.validate_dem_input(dem)

        return dem, flowline, shear, user_interval

    def process_flowline(self, flowline, user_interval, dem, context, feedback):
        """Split the flowline into points and sample the DEM at each.

        Snaps the geometry, adds an id, breaks the line every ``user_interval``,
        then samples the DEM. Returns the sampled point layer.
        """

        outputs = {}

        # Snap geometries to ensure connectivity
        snap_params = {
            'INPUT': flowline,
            'REFERENCE_LAYER': flowline,
            'TOLERANCE': 1.0,
            'BEHAVIOR': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SnapGeometries'] = self._run_algorithm(
            'native:snapgeometries', snap_params, context, feedback,
            output_key='OUTPUT', step_name='Snap flowline geometries'
        )
        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Add auto-incremental field
        autoinc_params = {
            'FIELD_NAME': 'cat',
            'GROUP_FIELDS': None,
            'INPUT': outputs['SnapGeometries']['OUTPUT'],
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': '',
            'SORT_NULLS_FIRST': False,
            'START': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AddAutoincrementalField'] = self._run_algorithm(
            'native:addautoincrementalfield', autoinc_params, context, feedback,
            output_key='OUTPUT', step_name='Add incremental field to flowline'
        )
        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Break the line into points
        points_params = {
            'DISTANCE': user_interval,
            'END_OFFSET': 0,
            'INPUT': outputs['AddAutoincrementalField']['OUTPUT'],
            'START_OFFSET': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BreakTheLineIntoPoints'] = self._run_algorithm(
            'native:pointsalonglines', points_params, context, feedback,
            output_key='OUTPUT', step_name='Break flowline into points'
        )
        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Sample raster values along the line
        raster_params = {
            'COLUMN_PREFIX': 'rvalue',
            'INPUT': outputs['BreakTheLineIntoPoints']['OUTPUT'],
            'RASTERCOPY': dem,
            'OUTPUT': f'/vsimem/temp_raster_sampling_{id(self)}'
        }
        outputs['RasterSampling'] = self._run_algorithm(
            'native:rastersampling', raster_params, context, feedback,
            output_key='OUTPUT', step_name='Sample DEM values along flowline'
        )
        self._check_layer_features(
            outputs['RasterSampling']['OUTPUT'], context,
            'Sample DEM values along flowline',
            "No sampled points were produced from the flowline. "
            "Check that the flowline lies within the DEM extent."
        )

        return outputs['RasterSampling']['OUTPUT'] 

    def link_flowline_points(self, df, dem, user_interval, shear, feedback):
        """Add a 'prox_id' column linking each point to its downstream neighbour (flow-based cost)."""

        start_time = time.time()
        prox_id_df = self.calculate_prox_id_flow_based(df, feedback)
        self.log_initialization(feedback, dem, user_interval, shear, stage="tributary_centreline")
        self.log_processing_duration("Spatially linked tributary branches and centreline", start_time)
        return prox_id_df

    def process_extant_glaciers(self, parameters, context, dem, df, feedback):
        """Recompute thickness inside extant glacier outlines, if the user supplied any."""

        use_glacier_polygons = self.parameterAsBoolean(parameters, self.extant_glacier, context)
        if use_glacier_polygons:
            glacier_polygons = self.parameterAsVectorLayer(parameters, self.extant_glacier_polygon, context)
            if not glacier_polygons:
                raise QgsProcessingException(
                    "No valid polygon layer was provided. "
                    "Please provide a valid polygon for extant glacier outlines.")
            glacier_polygons = self.validate_layer_crs(glacier_polygons, dem.crs(), context, feedback)
            feedback.pushInfo("Processing extant glaciers...\n")
            df = self.extant_ice_thickness(df, glacier_polygons, dem, context, feedback)
            feedback.pushInfo("Ice thickness adjusted for extant glaciers.\n")
        return df

    def load_results(self, df, dem, context, feedback):
        """Load the finished points into QGIS as a memory layer in the DEM CRS."""

        start_time = time.time()
        self.load_dataframe_to_qgis(
            df, dem.crs(), context, layer_name="2D FL Ice Thickness",
            feedback=feedback, group_name="Q-GlaRe Ice Thickness Points"
        )
        self.log_processing_duration("Ice flow thickness points loaded into QGIS", start_time)
    
    def log_initialization(self, feedback, dem, user_interval, shear,
                           flowline=None, stage=None, valid_percentage=None, invalid_points=None):
        """Write initialisation details, or a stage-specific progress message when ``stage`` is given."""

        if stage is None:
            # Log initialisation details
            feedback.pushInfo("-------------------------------------------------------------")
            feedback.pushInfo("Initialising 2D FL Ice Thickness Calculation")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.pushInfo("Input Parameters:")
            feedback.pushInfo(f"  - DEM: {dem.name()}")
            if flowline is not None:
                feedback.pushInfo(f"  - Flowline: {flowline.name()}")
            feedback.pushInfo(f"  - Resolution (map units): {user_interval:.2f}")
            feedback.pushInfo(f"  - Shear value: {shear}")
            feedback.pushInfo("-------------------------------------------------------------\n")
            feedback.setProgressText("Pre-processing input data...\n")
        elif stage == "input_processed":
            feedback.pushInfo("Input data pre-processing complete.\n")
        elif stage == "data_prep":
            feedback.setProgressText("Preparing data for calculation...\n")
        elif stage == "tributary_centreline":
            feedback.setProgressText("Spatially linking tributary branches and centreline...\n")
        elif stage == "ice_calculation":
            feedback.setProgressText("Calculating ice surface and thickness...\n")
        elif stage == "validation":
            feedback.setProgressText("Validating ice surface and thickness calculations...\n")
            if valid_percentage is not None:
                if valid_percentage < 95:
                    feedback.pushWarning(
                        f"Driving stress validation failed: Only {valid_percentage:.2f}% of points are within the acceptable range."
                    )
                    feedback.pushWarning(f"Invalid driving stress points (fid): {invalid_points}\n")
                    feedback.setProgressText("Validation incomplete: Issues found with some points.\n")
                else:
                    feedback.pushInfo("Validation complete.\n")
        elif stage == "load_qgis":
            feedback.setProgressText("Loading data into QGIS...\n")
   
    def validate_flowline_layer(self, input_layer, feedback):
        """Check the flowline is a valid, non-empty line layer; warn on very short lines."""
        
        # Check layer validity
        if not input_layer or not input_layer.isValid():
            raise QgsProcessingException("The input flowline layer is invalid or empty.")
        
        # Check geometry type
        if input_layer.geometryType() != _LINE_GEOMETRY:
            raise QgsProcessingException(
                "Invalid geometry type: Flowline must be a line layer.\n\n"
                "Please select a polyline/linestring layer, not points or polygons.\n"
            )
        
        # Check feature count
        if input_layer.featureCount() == 0:
            raise QgsProcessingException(
                "Empty layer: The flowline layer contains no features.\n\n"
                "Please provide a valid flowline with at least one feature.\n"
            )
        
        # Optional: Warn about very short flowlines
        min_length = 10  # Minimum reasonable length in map units
        short_count = 0
        
        for feature in input_layer.getFeatures():
            geom = feature.geometry()
            if geom and not geom.isEmpty() and geom.length() < min_length:
                short_count += 1
        
        if short_count > 0:
            feedback.pushWarning(
                f"Warning: {short_count} flowline(s) are very short (< {min_length} units).\n"
                "This may cause issues with point generation.\n"
            )

    def remove_empty_geometries(self, layer, context):
        """Return a copy of ``layer`` with empty or null geometries dropped."""
        
        # Filter valid geometries
        valid_features = []
        for f in layer.getFeatures():
            if f.geometry() and not f.geometry().isEmpty():
                valid_features.append(f)
        
        # Create clean layer, preserving the original layer name
        clean = QgsVectorLayer(
            f"LineString?crs={layer.crs().authid()}",
            layer.name(),
            "memory"
        )
        clean.dataProvider().addAttributes(layer.fields())
        clean.updateFields()
        clean.dataProvider().addFeatures(valid_features)
        
        return clean
    
    def validate_dem_input(self, input_raster):
        """Reject the raster if it looks like a hillshade rather than a DEM (by name, or a 0-255 range with low spread)."""

        # Check if the raster is valid
        if not input_raster or not input_raster.isValid():
            raise QgsProcessingException(
                "Invalid input: The selected raster layer is missing or invalid.\n\n"
                "Please ensure you have selected a valid DEM.\n"
            )

        # Check filename for "hillshade" or similar keywords
        hillshade_keywords = ["hillshade", "hillShade", "HillShade", "Hillshade", "HILLSHADE"]
        raster_name = input_raster.name().lower()  # Case-insensitive check
        if any(keyword in raster_name for keyword in hillshade_keywords):
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be a valid DEM. \n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

        # Get raster statistics
        provider = input_raster.dataProvider()
        stats = provider.bandStatistics(1)

        # Check if the value range suggests a Hillshade (e.g., 0–255)
        if stats.minimumValue >= 0 and stats.maximumValue <= 255 and stats.stdDev < 50:
            raise QgsProcessingException(
                "Invalid input: The selected raster layer may not be a valid DEM. \n\n"
                "Please ensure you have selected a valid elevation dataset.\n"
            )

    def create_temp_layer_from_output(self, output_path, layer_name, feedback=None):
        """Load a vector layer from ``output_path`` and add 'xcoord'/'ycoord' fields from each point."""

        # Load the layer from the output path
        temp_layer = QgsVectorLayer(output_path, layer_name, "ogr")

        if not temp_layer.isValid():
            raise ValueError(f"Failed to create layer: {layer_name} from path: {output_path}")

        # Add xcoord and ycoord fields
        temp_layer.dataProvider().addAttributes([QgsField('xcoord', _FIELD_DOUBLE), QgsField('ycoord', _FIELD_DOUBLE)])
        temp_layer.updateFields()  

        # Prepare bulk updates for features
        xcoord_idx = temp_layer.fields().indexOf('xcoord')
        ycoord_idx = temp_layer.fields().indexOf('ycoord')
        features = temp_layer.getFeatures()
        updates = {}

        for feature in features:
            geom = feature.geometry().asPoint()
            updates[feature.id()] = {xcoord_idx: geom.x(), ycoord_idx: geom.y()}

        # Perform the bulk update
        temp_layer.dataProvider().changeAttributeValues(updates)

        return temp_layer
    
    def ice_reconstruction(self, df, shear=None, feedback=None):
        """Reconstruct ice surface and thickness along every flowline.

        Marches the main flowline from the terminus, solving the equilibrium
        profile point by point, then reconstructs each tributary once its
        confluence point has a surface. Thickness is the reconstructed surface
        minus the bed ('rvalue1'), floored at zero, with the terminus forced to
        zero.

        Args:
            df: flowline points with columns 'cat', 'xcoord', 'ycoord',
                'rvalue1' (bed elevation), 'prox_id', 'fid', 'distance',
                'shear_stress'.
            shear: constant basal shear stress in Pa; if None, each point's own
                'shear_stress' is used.

        Returns:
            The frame with added 'ice_surface' and 'ice_thickness' columns.
        """

        # Constants
        rho = 910  # Ice density (kg/m3)
        g = 9.81   # Gravitational acceleration (m/s2)

        # helper function to compute the next ice surface using the quadratic model.
        def compute_next_surface(prev_surface, r_prev, r_curr, d, local_shear):
            """Next surface from the quadratic equilibrium profile; fall back to the bed if there is no real root."""

            b = -(r_prev + r_curr)
            c = prev_surface * (r_curr - (prev_surface - r_prev)) - (2 * d * local_shear) / (rho * g)
            disc = b**2 - 4 * c
            if disc >= 0:
                return (-b + np.sqrt(disc)) / 2
            else:
                return r_curr

        # helper function to process a single flowline segment.
        def process_flowline_segment(segment_df, initial_surface=None):
            """March one flowline segment from its first point, returning {fid: ice_surface}.

            Uses ``initial_surface`` for the first point when given, otherwise
            the segment's first bed value ('rvalue1').
            """

            surface_map = {}
            seg = segment_df.sort_index().reset_index(drop=True)
            first = seg.iloc[0]
            init_surf = initial_surface if initial_surface is not None else first['rvalue1']
            surface_map[first['fid']] = init_surf
            prev_surface = init_surf
            # Process remaining points sequentially.
            for i in range(1, len(seg)):
                curr = seg.iloc[i]
                prev = seg.iloc[i - 1]
                dx = curr['xcoord'] - prev['xcoord']
                dy = curr['ycoord'] - prev['ycoord']
                d = np.sqrt(dx**2 + dy**2)
                local_shear = shear if shear is not None else curr['shear_stress']
                new_surface = compute_next_surface(prev_surface, prev['rvalue1'], curr['rvalue1'], d, local_shear)
                surface_map[curr['fid']] = new_surface
                prev_surface = new_surface
            return surface_map

        surface_dict = {}

        # Process main flowline
        main_mask = df['prox_id'].isna()
        main_flowline = df[main_mask].copy()
        if not main_flowline.empty:
            main_surfaces = process_flowline_segment(main_flowline)
            surface_dict.update(main_surfaces)

        # Process tributaries in network order (multi-pass), not digitised (cat) order.
        # A tributary can only inherit its confluence surface once the flowline it
        # drains into has itself been reconstructed, so each pass processes every
        # tributary whose downstream link (prox_id) is already in surface_dict.
        tributaries = df[~main_mask].copy()
        pending = {cat: group.copy().reset_index(drop=True)
                   for cat, group in tributaries.groupby('cat')}
        while pending:
            ready = [cat for cat, group in pending.items()
                     if group.iloc[0]['prox_id'] in surface_dict]
            if not ready:
                # No remaining tributary links to a reconstructed flowline.
                # Fall back to bed elevation, warned if so.
                for cat, group in pending.items():
                    msg = (f"Tributary cat={cat}: downstream link (fid "
                           f"{group.iloc[0]['prox_id']}) was never reconstructed - "
                           "starting at bed elevation (zero ice thickness). Check the "
                           "flowline digitising direction and network connectivity.")
                    self._log(msg, level='warning')
                    if feedback is not None:
                        feedback.pushWarning(msg + "\n")
                    surface_dict.update(process_flowline_segment(
                        group, initial_surface=group.iloc[0]['rvalue1']))
                break
            for cat in ready:
                group = pending.pop(cat)
                surface_dict.update(process_flowline_segment(
                    group, initial_surface=surface_dict[group.iloc[0]['prox_id']]))

        # Map the computed surfaces back to the DataFrame.
        df['ice_surface'] = df['fid'].map(surface_dict)
        df['ice_thickness'] = np.maximum(df['ice_surface'] - df['rvalue1'], 0)
        
        # Locate and replace zero ice thickness values using nearest neighbour approach
        df = self.replace_zero_thickness_with_nearest_neighbor(df)

        # Ensure terminus has zero thickness
        main_flow_cat = self._find_main_flow_cat(df)
        main_flowline = df[df['cat'] == main_flow_cat]

        if not main_flowline.empty:
            # Find terminus (minimum distance point on main flowline)
            terminus_row = main_flowline.loc[main_flowline['distance'].idxmin()]
            terminus_idx = terminus_row.name  # Get the DataFrame index
            
            # Force terminus to zero thickness
            df.at[terminus_idx, 'ice_thickness'] = 0
            df.at[terminus_idx, 'ice_surface'] = df.at[terminus_idx, 'rvalue1']
        
        return df
        
    def validate_driving_stress(self, df):
        """Flag points whose driving stress falls outside 50-200 kPa.

        Driving stress is rho*g*H*sin(alpha), with the surface slope taken from
        successive 'ice_surface' values along the line.

        Args:
            df: points with 'ice_thickness', 'xcoord', 'ycoord',
                'ice_surface', 'fid'.

        Returns:
            (frame, valid_percentage, invalid_fids), with the temporary check
            columns removed.
        """

        # Constants
        rho = 910  # Ice density (kg/m³)
        g = 9.81  # Gravitational acceleration (m/s²)
        stress_min = 50e3  # Driving stress minimum (Pa)
        stress_max = 200e3  # Driving stress maximum (Pa)

        # Calculate surface slope (vectorized)
        dx = df['xcoord'].diff().fillna(0)  
        dy = df['ycoord'].diff().fillna(0)  
        dz = df['ice_surface'].diff().fillna(0)
        d = np.sqrt(dx**2 + dy**2 + 1e-6)  
        surface_slope = np.arctan(np.abs(dz / d))

        # Calculate driving stress
        driving_stress = rho * g * df['ice_thickness'] * np.sin(surface_slope)

        # Validate driving stress
        df['stress_valid'] = (driving_stress >= stress_min) & (driving_stress <= stress_max)
        invalid_points = df.loc[~df['stress_valid'], 'fid'].tolist()
        valid_points = df['stress_valid'].sum()
        total_points = len(df)
        df = df.drop(columns=['stress_valid', 'Shape_Leng', 'OBJECTID', 'Id', 'angle'], errors='ignore')
        if total_points == 0:
            return df, 0.0, []
        valid_percentage = (valid_points / total_points) * 100

        # Clean up temporary columns
        return df, valid_percentage, invalid_points


    def extant_ice_thickness(self, df, glacier_polygons, dem, context, feedback):
        """Recompute thickness for points inside extant glacier outlines from the VOLTA slope relation.

        For each point inside a polygon, samples the DEM slope and sets
        H = tau / (rho*g*tan(alpha)), capped at the bed elevation, then sets
        bedrock elevation to bed minus H. Points outside the outlines are left
        as they are.

        Args:
            df: points with 'fid', 'xcoord', 'ycoord', 'rvalue1',
                'shear_stress', 'ice_thickness'.
            glacier_polygons: extant glacier outlines.
            dem: DEM used for the slope raster.

        Returns:
            The frame with updated 'ice_thickness' and 'bedrock_elevation'.
        """

        # Constants
        rho = 910  # Ice density (kg/m^3)
        g = 9.81  # Gravitational acceleration (m/s^2)
        min_slope_degrees = 4  # Minimum slope threshold (in degrees)

        # Compute slope from input DEM
        slope_raster_path = f"/vsimem/slope_{id(self)}.tif"
        self._run_algorithm(
            'native:slope',
            {'INPUT': dem, 'Z_FACTOR': 1.0, 'OUTPUT': slope_raster_path},
            context, feedback,
            output_key='OUTPUT', step_name='Compute slope raster'
        )
        slope_raster = QgsRasterLayer(slope_raster_path, "Slope Raster")
        if not slope_raster.isValid():
            raise QgsProcessingException(
                "Failed to load the computed slope raster. "
                "Check that the input DEM is valid and accessible."
            )

        # Build a Spatial Index for polygon containment check
        spatial_index = QgsSpatialIndex()
        poly_dict = {}  
        for polygon in glacier_polygons.getFeatures():
            poly_id = polygon.id()
            poly_dict[poly_id] = polygon.geometry()
            spatial_index.addFeature(polygon)

        # Convert DataFrame to QGIS points
        df["point_geom"] = df.apply(lambda row: QgsGeometry.fromPointXY(QgsPointXY(row["xcoord"], row["ycoord"])), axis=1)

        # Find points inside any defined glacier
        inside_glacier_mask = np.array([
            any(poly_dict[poly_id].contains(row["point_geom"])
                for poly_id in spatial_index.intersects(row["point_geom"].boundingBox()))
            for _, row in df.iterrows()])
        
        # Only process points inside glaciers
        inside_df = df[inside_glacier_mask].copy()

        # Extract slope values of point locations
        def _sample_slope(p):
            value, ok = slope_raster.dataProvider().sample(p.asPoint(), 1)
            return max(value if ok else min_slope_degrees, min_slope_degrees)
        inside_df["slope"] = inside_df["point_geom"].apply(_sample_slope)

        # Compute ice thickness using VOLTA equation 
        slope_radians = np.radians(inside_df["slope"])
        pgtan_alpha = rho * g * np.tan(slope_radians)

        inside_df["ice_thickness"] = np.clip(inside_df["shear_stress"] 
                                             / pgtan_alpha, 0, inside_df["rvalue1"])
        
        # Initialise `bedrock_elevation` for all points 
        if "bedrock_elevation" not in df.columns:
            df["bedrock_elevation"] = np.nan  
        
        # Compute bedrock elevation
        inside_df["bedrock_elevation"] = inside_df["rvalue1"] - inside_df["ice_thickness"]

        # Merge processed data back into DataFrame
        df.update(inside_df[["ice_thickness", "bedrock_elevation"]])

        # Ensure `bedrock_elevation` is numeric and non-null 
        df["bedrock_elevation"] = pd.to_numeric(df["bedrock_elevation"], errors="coerce").fillna(df["rvalue1"])

        # Remove temporary geometry column
        df = df.drop(columns=["point_geom"])

        return df

    def postProcessAlgorithm(self, context, feedback):
        """Show a completion dialog once processing finishes."""

        # Display completion message using a custom dialog
        msg_box = QMessageBox()
        feedback.setProgress(100)
        msg_box.setStyleSheet("QLabel{min-width: 200px;}")  
        msg_box.setWindowTitle("2D FL Ice Thickness Calculation")
        msg_box.setText("Processing Complete!\n\nPlease check the Log for details.")
        msg_box.exec()
        
        return super().postProcessAlgorithm(context, feedback)
    

