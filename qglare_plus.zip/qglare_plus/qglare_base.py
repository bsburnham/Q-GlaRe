"""
Shared base mixin for all QGlaRe+ processing algorithms.

Provides:
  - _init_logger()         : create a per-run log file next to the QGIS project
                             (falls back to ~/qglare_plus_logs/ if no project is saved)
  - _log_run_header()      : write a formatted block of user input parameters to the log
  - _run_algorithm()       : drop-in replacement for processing.run() that validates output,
                             times each step, and catches exceptions
  - _check_layer_features(): count features in a vector output and raise if zero
  - _log()                 : convenience wrapper around the file logger
"""

import os
import time as _time
import logging
import traceback
import uuid
from datetime import datetime

import processing
import numpy as np
import pandas as pd
from qgis.PyQt.QtCore import QVariant
from qgis.core import (Qgis, QgsProject, QgsProcessingException,
                        QgsProcessingUtils, QgsApplication,
                        QgsMessageLog,
                        QgsField, QgsFields, QgsFeature,
                        QgsGeometry, QgsPointXY, QgsVectorLayer,
                        QgsRasterLayer, QgsUnitTypes,
                        QgsProcessingFeedback,
                        QgsProcessingLayerPostProcessorInterface)

import platform as _platform

from .qglare_utils import QGlaReUtils

try:
    from osgeo import gdal as _gdal
    _GDAL_VERSION = _gdal.__version__
except ImportError:
    _GDAL_VERSION = 'unavailable'

# QGIS version compatibility: DistanceUnit moved to Qgis enum in 3.30
try:
    _DISTANCE_METERS = Qgis.DistanceUnit.Meters
except AttributeError:                          # QGIS < 3.30
    _DISTANCE_METERS = QgsUnitTypes.DistanceMeters

LOG_FOLDER_NAME = 'qglare_plus_logs'
MAX_LOG_FILES = 20


class _ChildFeedback(QgsProcessingFeedback):
    """Feedback for child processing.run() calls.

    Forwards isCanceled() from the parent so cancellation still works, but
    swallows all log messages so child algorithm output does not appear in
    the user-facing QGIS Processing console.
    """
    def __init__(self, parent):
        super().__init__()
        self._parent = parent

    def isCanceled(self):
        return self._parent.isCanceled()


class _GroupPostProcessor(QgsProcessingLayerPostProcessorInterface):
    """Move a loaded output layer into a named layer-tree group.

    Backward-compatible grouping for QGIS < 3.32, where LayerDetails.groupName
    is absent. Runs at load completion on the GUI thread, so layer-tree access
    is safe.
    """
    _keep = []

    @classmethod
    def create(cls, group_name):
        pp = cls(group_name)
        cls._keep.append(pp)   # the framework keeps only a weak reference
        return pp

    def __init__(self, group_name):
        super().__init__()
        self._group_name = group_name

    def postProcessLayer(self, layer, context, feedback):
        try:
            root = QgsProject.instance().layerTreeRoot()
            node = root.findLayer(layer.id())
            if node is None:
                return
            group = root.findGroup(self._group_name) or root.insertGroup(0, self._group_name)
            group.insertChildNode(0, node.clone())
            parent = node.parent()
            if parent is not None:
                parent.removeChildNode(node)
        except Exception:
            pass


class QGlaReAlgorithmMixin(QGlaReUtils):
    """
    Mixin for QgsProcessingAlgorithm subclasses.

    Usage
    -----
    class MyAlgorithm(QGlaReAlgorithmMixin, QgsProcessingAlgorithm):
        def processAlgorithm(self, parameters, context, feedback):
            self._init_logger('my_algorithm', feedback)
            self._log_run_header({'DEM': 'my_dem', 'Resolution': 25})
            ...
            result = self._run_algorithm(
                'gdal:translate', params, context, feedback,
                output_key='OUTPUT', step_name='Finalize raster'
            )
    """

    _logger = None
    _log_path = None
    _run_id = None
    _run_start = None
    _log_tag = 'QGlaRe+'

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def _set_layer_group(self, details, group_name):
        """Assign a loaded output layer to a layer-tree group, backward-compatibly.

        Uses LayerDetails.groupName on QGIS >= 3.32; on older QGIS attaches a
        post-processor that moves the layer into the group once it loads.
        """
        try:
            details.groupName = group_name          # QGIS >= 3.32
        except (AttributeError, TypeError):
            details.setPostProcessor(_GroupPostProcessor.create(group_name))

    def _init_logger(self, algorithm_name, feedback=None):
        """Create a timestamped per-run log file and return its path.

        Writes it to <project folder>/qglare_plus_logs/, or ~/qglare_plus_logs/
        when the project is unsaved, with a header of QGIS, GDAL and SAGA versions
        and the OS.
        """
        project_file = QgsProject.instance().fileName()
        if project_file:
            log_dir = os.path.join(os.path.dirname(project_file), LOG_FOLDER_NAME)
        else:
            log_dir = os.path.join(os.path.expanduser('~'), LOG_FOLDER_NAME)

        os.makedirs(log_dir, exist_ok=True)
        self._rotate_logs(log_dir, algorithm_name)

        self._run_id = uuid.uuid4().hex[:8]
        self._run_start = _time.time()
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self._log_path = os.path.join(log_dir, f'{algorithm_name}_{timestamp}.log')

        # Use a unique logger name per run to avoid duplicate handlers
        # when the same algorithm is run multiple times in one QGIS session.
        logger_name = f'qglare_plus.{algorithm_name}.{timestamp}.{self._run_id}'
        self._logger = logging.getLogger(logger_name)
        self._logger.setLevel(logging.DEBUG)
        self._logger.propagate = False

        handler = logging.FileHandler(self._log_path, encoding='utf-8')
        handler.setFormatter(
            logging.Formatter('%(asctime)s [%(levelname)s] %(message)s',
                              datefmt='%H:%M:%S')
        )
        self._logger.addHandler(handler)

        # Plugin version
        try:
            from . import __version__ as _plugin_version
        except ImportError:
            _plugin_version = 'unknown'

        # SAGA version
        try:
            _saga_provider = QgsApplication.processingRegistry().providerById('sagang')
            _saga_version = (
                _saga_provider.versionInfo()
                if _saga_provider and hasattr(_saga_provider, 'versionInfo')
                else 'unavailable'
            )
        except Exception:
            _saga_version = 'unavailable'

        # Header
        self._logger.info(f"QGlaRe+ {_plugin_version} | Algorithm: {algorithm_name} | Run ID: {self._run_id}")
        self._logger.info(f"QGIS version       : {Qgis.QGIS_VERSION}")
        self._logger.info(f"GDAL version       : {_GDAL_VERSION}")
        self._logger.info(f"SAGA version       : {_saga_version}")
        self._logger.info(f"OS                 : {_platform.platform()}")
        self._logger.info(f"Project file       : {project_file or '(unsaved)'}")
        self._logger.info("-" * 60)

        if feedback:
            feedback.pushInfo(f"Log file: {self._log_path}\n")

        return self._log_path

    def _log_run_header(self, params):
        """Write the run parameters block to the log as aligned label/value lines."""
        self._log("=" * 60)
        self._log("RUN PARAMETERS")
        self._log("=" * 60)
        for label, value in params.items():
            self._log(f"  {label:<28}{value}")
        self._log("=" * 60)

    def _log(self, msg, level='info'):
        """Write *msg* to the run log file at the given level (info/warning/error)."""
        if self._logger:
            getattr(self._logger, level)(msg)

    def _run_algorithm(self, algorithm, params, context, feedback,
                       output_key='OUTPUT', step_name=''):
        """Run a child processing algorithm, timing it and validating its output.

        Wraps processing.run(): logs the step and elapsed time, re-raises failures
        as QgsProcessingException with the log path, and errors if the expected
        output key is missing or empty.
        """
        label = step_name or algorithm
        self._log(f"START  | {label} | algorithm={algorithm}")
        t0 = _time.time()

        try:
            result = processing.run(
                algorithm, params,
                context=context, feedback=_ChildFeedback(feedback), is_child_algorithm=True
            )
        except Exception as e:
            tb = traceback.format_exc()
            self._log(
                f"FAILED | {label} | algorithm={algorithm} | {_time.time()-t0:.1f}s\n{tb}",
                level='error'
            )
            raise QgsProcessingException(
                "An error occurred. See log file."
                + (f"\n{self._log_path}" if self._log_path else "")
            )

        if result is None or output_key not in result or not result[output_key]:
            self._log(
                f"NO OUTPUT | {label} | algorithm={algorithm} | expected key='{output_key}'",
                level='error'
            )
            raise QgsProcessingException(
                f"Processing step produced no result: {label}."
                + (f"\nSee log file: {self._log_path}" if self._log_path else "")
            )

        self._log(f"OK     | {label} | {_time.time()-t0:.1f}s")
        return result

    def _check_layer_features(self, layer_or_id, context, step_name,
                               zero_message=None):
        """Count features in a vector output and raise if the layer has none.

        Accepts a layer or a layer-id string; ``zero_message`` overrides the
        default error text.
        """
        if isinstance(layer_or_id, str):
            layer = QgsProcessingUtils.mapLayerFromString(layer_or_id, context)
        else:
            layer = layer_or_id

        if layer is None or not layer.isValid():
            self._log(f"COUNT  | {step_name} | could not retrieve layer to count",
                      level='warning')
            return

        count = layer.featureCount()
        self._log(f"COUNT  | {step_name} | {count:,} features")

        if count == 0:
            msg = zero_message or f"No features were produced at step: {step_name}."
            raise QgsProcessingException(
                msg + (f"\nSee log file: {self._log_path}" if self._log_path else "")
            )

    def _log_layer_crs(self, layers):
        """Log the CRS of each (label, layer) input pair."""
        self._log("--- Input Layer CRS ---")
        for label, layer in layers:
            if layer is None:
                self._log(f"  {label:<28}(None)")
                continue
            crs = layer.crs()
            if crs.isValid():
                geo_or_proj = "geographic" if crs.isGeographic() else "projected"
                self._log(f"  {label:<28}{crs.authid()} | {crs.description()} | {geo_or_proj}")
            else:
                self._log(f"  {label:<28}(invalid CRS)")
        self._log("-" * 60)

    def _log_crs_context(self, layer, level='info'):
        """
        Write a detailed CRS snapshot for *layer* to the run log.

        Records the authority code, description, linear units, whether the CRS is
        geographic, and - for a compound / 3D CRS such as a DEM with a vertical height
        component - the horizontal component's authority code and description (the usual
        reason a layer's authid() comes back empty), plus the layer extent.

        Called before raising a CRS validation error so a failed run still records the
        exact CRS that was rejected: validation runs before the normal per-layer CRS
        logging (_log_layer_crs), and QgsProcessingException is re-raised upstream
        without logging.
        """
        try:
            name = layer.name() if layer else "Unknown layer"
            crs = layer.crs() if layer else None
            if crs is None or not crs.isValid():
                self._log(f"CRS context | layer='{name}' | (invalid or undefined CRS)", level=level)
                return

            parts = [
                f"layer='{name}'",
                f"authid='{crs.authid()}'",
                f"description='{crs.description()}'",
                f"geographic={crs.isGeographic()}",
                f"units={QgsUnitTypes.encodeUnit(crs.mapUnits())}",
            ]

            horizontal = self._horizontal_crs(crs)
            if horizontal is not None and horizontal.authid() != crs.authid():
                # Compound / 3D CRS: report the horizontal component validation uses.
                parts.append(f"horizontal_authid='{horizontal.authid()}'")
                parts.append(f"horizontal_description='{horizontal.description()}'")

            try:
                extent = layer.extent()
                parts.append(
                    f"extent=X[{extent.xMinimum():.2f},{extent.xMaximum():.2f}] "
                    f"Y[{extent.yMinimum():.2f},{extent.yMaximum():.2f}]"
                )
            except Exception:
                pass

            self._log("CRS context | " + " | ".join(parts), level=level)
        except Exception:
            # Diagnostic logging must never mask the real validation error.
            pass

    def _crs_error(self, layer, message):
        """
        Log the CRS context for *layer* and the failure *message* at error level, then
        return a QgsProcessingException(message) for the caller to raise.

        Centralises CRS-rejection logging so every failed check leaves a diagnosable
        trace in the run log (see _log_crs_context for why this is needed). Use as:
        ``raise self._crs_error(layer, "...")``.
        """
        self._log_crs_context(layer, level='error')
        self._log(f"CRS validation failed:\n{message}", level='error')
        return QgsProcessingException(message)

    def validate_layer_crs(self, layer, target_crs, context, feedback):
        """Ensure a layer matches the target CRS, reprojecting it if it does not.

        Compares horizontal CRS components, so a compound-CRS DEM is not treated
        as mismatched against plain-UTM vectors, and returns the original or the
        reprojected layer.
        """

        if not layer or not layer.isValid():
            raise self._crs_error(layer, "Invalid input layer.")

        layer_name = layer.name() if layer else "Unknown layer"

        # Compare against the horizontal component so a compound-CRS DEM (UTM + vertical
        # height) isn't treated as mismatched against plain-UTM vector layers.
        layer_authid = self._horizontal_crs(layer.crs()).authid()
        target_horizontal = self._horizontal_crs(target_crs)
        target_authid = target_horizontal.authid()

        # Check if CRS matches
        if layer_authid == target_authid:
            return layer  # CRS matches, return original

        # CRS mismatch - auto-reproject (to the horizontal CRS, dropping any vertical
        # component so downstream 2D processing gets a clean single-authority CRS).
        self._log(
            f"CRS mismatch | '{layer_name}' is in {layer_authid or 'unknown'}, "
            f"expected {target_authid or 'unknown'} - auto-reprojecting",
            level='warning'
        )
        feedback.pushWarning(
            f"CRS mismatch: '{layer_name}' is in {layer_authid}, "
            f"expecting {target_authid}.\n"
            f"Automatically reprojecting '{layer_name}' to {target_authid}\n"
        )
        target_crs = target_horizontal

        # Reproject using QGIS processing
        reproject_params = {
            'INPUT': layer,
            'TARGET_CRS': target_crs,
            'OUTPUT': 'memory:'
        }

        result = self._run_algorithm(
            'native:reprojectlayer', reproject_params, context, feedback,
            output_key='OUTPUT', step_name=f"Reproject layer '{layer_name}'"
        )

        reprojected_layer = result['OUTPUT']
        if isinstance(reprojected_layer, str):
            reprojected_layer = QgsProcessingUtils.mapLayerFromString(reprojected_layer, context)
        feedback.pushInfo(f"Successfully reprojected '{layer_name}' to {target_crs.authid()}.\n")

        return reprojected_layer

    def validate_projected_crs(self, layer, feedback):
        """Reject a layer unless it uses a recognised, metric, projected CRS.

        Checks the CRS is defined, carries an EPSG-style authority code (not
        USER:), is not geographic, uses metres, and that the coordinates are not
        actually degrees. Validates against the horizontal component so a DEM with
        a vertical CRS still passes.
        """

        if not layer or not layer.isValid():
            raise self._crs_error(layer, "Invalid input layer.")

        layer_crs = layer.crs()
        layer_name = layer.name() if layer else "Unknown layer"
        is_raster = isinstance(layer, QgsRasterLayer)
        reproject_instruction = "Raster -> Projections -> Warp (Reproject)" if is_raster else "Vector -> Data Management Tools -> Reproject Layer"

        # Check 1: CRS is defined and valid
        if not layer_crs or not layer_crs.isValid():
            raise self._crs_error(layer,
                f"Missing CRS: The input layer '{layer_name}' has no coordinate reference system defined.\n\n"
                "This algorithm requires that all input data have a valid projected CRS assigned.\n\n"
                "Please assign a projected coordinate system to your layer.\n"
                f"{reproject_instruction}\n"
            )

        # Validate against the horizontal component so a compound / 3D CRS (e.g. a DEM
        # with a projected horizontal CRS plus a vertical CRS such as EPSG:5703 NAVD88
        # height) is accepted: the combined CRS has no single registered EPSG code, so
        # its authid() is "", but the horizontal component carries the projected
        # authority code and the linear units we care about.
        check_crs = self._horizontal_crs(layer_crs)

        # Check 1b: CRS must have a recognised authority code (e.g. EPSG:27700, not USER:100001)
        auth_id = check_crs.authid()
        if not auth_id or auth_id.upper().startswith('USER:'):
            raise self._crs_error(layer,
                f"Unrecognised CRS: The layer '{layer_name}' has a custom or unregistered "
                f"coordinate reference system ({auth_id or 'unknown'}).\n\n"
                "QGIS processing algorithms require a standard recognised CRS (e.g. an EPSG code). "
                "Custom CRS definitions can cause intermediate processing steps to fail silently.\n\n"
                "To fix:\n"
                "1. Identify the correct CRS for your data (e.g. EPSG:27700 for British National Grid).\n"
                "2. Right-click the layer → Set CRS → Set Layer CRS - if the data coordinates are already correct.\n"
                "3. Or use Reproject Layer / Warp (Reproject) if the coordinates also need transforming.\n"
            )

        # Check 2: CRS is not geographic (lat/long)
        if check_crs.isGeographic():
            raise self._crs_error(layer,
                f"Invalid CRS: The layer '{layer_name}' uses a geographic coordinate system ({check_crs.authid()}).\n\n"
                "This algorithm requires projected coordinates in meters (e.g., UTM).\n"
                "Geographic coordinates (latitude/longitude in degrees) will produce incorrect results.\n\n"
                "Please reproject your data to an appropriate projected coordinate system.\n"
                f"{reproject_instruction}\n"
            )

        # Check 3: Linear unit must be metres
        if check_crs.mapUnits() != _DISTANCE_METERS:
            unit_name = QgsUnitTypes.encodeUnit(check_crs.mapUnits())
            raise self._crs_error(layer,
                f"Unsupported CRS units: The layer '{layer_name}' uses {unit_name} as its "
                "linear unit.\n\n"
                "This algorithm requires a projected CRS with metres as the distance unit "
                "(e.g. UTM).\n"
                "Please reproject to a metric projected CRS.\n"
                f"{reproject_instruction}\n"
            )

        # Check 4: Coordinate values don't look like degrees despite projected CRS
        extent = layer.extent()
        if (abs(extent.xMinimum()) < 360 and abs(extent.xMaximum()) < 360 and
                abs(extent.yMinimum()) < 90 and abs(extent.yMaximum()) < 90):

            export_note = "" if is_raster else "Or: Right-click layer -> Export -> Save Features As (with CRS transformation)\n"

            raise self._crs_error(layer,
                f"CRS mismatch detected: The layer '{layer_name}' is set to projected CRS ({check_crs.authid()}), "
                "but the coordinates appear to be in geographic format (lat/long).\n\n"
                f"Extent: X[{extent.xMinimum():.2f}, {extent.xMaximum():.2f}], "
                f"Y[{extent.yMinimum():.2f}, {extent.yMaximum():.2f}]\n\n"
                "This occurs when the CRS is assigned without transforming the coordinate values.\n\n"
                "To fix:\n"
                f"{reproject_instruction}\n"
                f"{export_note}"
                "Choose an appropriate projected CRS (e.g., UTM zone)\n"
                "Verify output coordinates are large numbers (e.g., 273000), not degrees (e.g., -119.5)\n\n"
                "Note: 'Set Layer CRS' does not transform coordinates. You must reproject the data.\n"
            )

    def log_processing_duration(self, process_name, start_time):
        """Log the elapsed time for a step to the QGIS message log."""
        duration = _time.time() - start_time
        QgsMessageLog.logMessage(
            f"{process_name} completed in {duration:.4f} seconds",
            self._log_tag, level=3
        )

    def log_final_results(self, feedback, crs_string, start_time=None):
        """Log the closing summary and mark processing complete.

        ``start_time`` is optional; omit it for algorithms that do not track one.
        """
        QgsMessageLog.logMessage(
            f"All data calculated in projection: {crs_string}",
            self._log_tag, level=3
        )
        QgsMessageLog.logMessage(
            "-----------------------------------------END PROCESS-----------------------------------------\n",
            self._log_tag, level=0
        )
        if start_time is not None:
            duration = _time.time() - start_time
            feedback.pushInfo(f"All data processed in: {duration:.4f} seconds.\n")
        feedback.pushInfo(f"All data processed and projected in: {crs_string}\n")
        feedback.setProgress(100)
        feedback.setProgressText("Processing Complete!\n")

    def _log_success(self, feedback=None):
        """Log a SUCCESS outcome line and total run duration."""
        elapsed = _time.time() - self._run_start if self._run_start else 0.0
        msg = f"SUCCESS | total: {elapsed:.1f}s"
        self._log(msg)
        self._log("=" * 60)
        if feedback:
            feedback.pushInfo(f"Run complete ({elapsed:.1f}s). Log: {self._log_path}\n")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _rotate_logs(self, log_dir, algorithm_name):
        """Delete the oldest log files so at most MAX_LOG_FILES remain."""
        try:
            files = sorted([
                os.path.join(log_dir, f)
                for f in os.listdir(log_dir)
                if f.startswith(algorithm_name + '_') and f.endswith('.log')
            ])
            while len(files) >= MAX_LOG_FILES:
                os.remove(files.pop(0))
        except Exception:
            pass  # Never let log rotation break the algorithm
